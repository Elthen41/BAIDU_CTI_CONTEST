// CUDA output and prediction kernels.
//
// Implement the final inference output path:
// - head_linear_kernel can live in gemm_kernels.cu, but this file should own
//   post-processing around the head output.
// - clamp logits into [-15, 15].
// - apply sigmoid.
// - gather probabilities and logids by pred_mask.
// - write compact prediction buffers for final predict.txt generation.
//
// Goal:
// - Avoid per-batch CPU synchronization caused by cpu().tolist().
// - Preserve prediction count and logid order exactly.
//
// Reference ideas:
// - LeetCUDA/kernels/sigmoid
// - LeetCUDA/kernels/elementwise
// - LeetCUDA/kernels/hgemv

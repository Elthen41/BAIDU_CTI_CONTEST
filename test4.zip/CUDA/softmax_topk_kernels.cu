// CUDA softmax and top-k kernels for SMoE gate.
//
// Implement gate post-processing:
// - Input logits: [N, 8] fp16/fp32 from gate_linear.
// - Compute logsumexp or softmax denominator over 8 experts.
// - Select top-2 experts per token.
// - Output topk_idx: [N, 2] int32.
// - Output topk_score: [N, 2] fp16/fp32.
//
// Because expert count is fixed at 8, this can be one warp or one small block
// per token. Keep tie-breaking deterministic so predictions stay stable.
//
// Reference ideas:
// - LeetCUDA/kernels/softmax
// - LeetCUDA/kernels/reduce

// CUDA sparse Mixture-of-Experts kernels.
//
// Implement the routed SMoE path:
// - smoe_route_count_kernel:
//   Count how many token routes go to each of 8 experts.
// - smoe_route_prefix_kernel:
//   Build expert offsets/capacity metadata.
// - smoe_route_pack_kernel:
//   Pack x[N,512] into x_route[expert, position, 512].
//   Also write route_score and route_token/route_pos metadata.
// - smoe_grouped_fc1_relu_kernel:
//   Per-expert fc1 [512 -> 1024] plus bias and ReLU.
// - smoe_grouped_fc2_kernel:
//   Per-expert fc2 [1024 -> 512] plus bias.
// - smoe_route_reduce_kernel:
//   Gather two routed expert outputs per token, multiply by gate scores,
//   and write moe_out[N,512].
//
// Optimization path:
// - Start with correctness-first kernels.
// - Replace expert fc kernels with Tensor Core/MMA variants.
// - Fuse fc2 + route_reduce after correctness is stable.
//
// Avoid fp16 atomic accumulation as the main output path.
//
// Reference ideas:
// - LeetCUDA/kernels/hgemm
// - LeetCUDA/kernels/relu
// - LeetCUDA/kernels/reduce
// - LeetCUDA/kernels/swizzle

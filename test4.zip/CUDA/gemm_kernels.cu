// CUDA fp16 GEMM/GEMV kernels for all Linear layers.
//
// Implement GEMM kernels needed by the full inference path:
// - rep_linear: [N, 14336] x [14336, 512] -> [N, 512]
// - qkv_linear per Transformer layer: [N, 512] x [512, 1536] -> [N, 1536]
// - out_linear per Transformer layer: [N, 512] x [512, 512] -> [N, 512]
// - gate_linear per Transformer layer: [N, 512] x [512, 8] -> [N, 8]
// - SMoE fc1 per expert: [M_e, 512] x [512, 1024] -> [M_e, 1024]
// - SMoE fc2 per expert: [M_e, 1024] x [1024, 512] -> [M_e, 512]
// - head_linear: [N, 512] x [512, 1] -> [N, 1]
//
// Start with correctness-first tiled fp16 kernels. Then specialize hot shapes
// with shared-memory tiling and Tensor Core/MMA.
//
// Reference ideas:
// - LeetCUDA/kernels/hgemm
// - LeetCUDA/kernels/hgemv
// - LeetCUDA/kernels/swizzle

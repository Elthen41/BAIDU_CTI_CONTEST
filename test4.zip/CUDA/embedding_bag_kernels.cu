// CUDA RepEncoder embedding-bag kernels.
//
// Implement the feature side of the model:
// - Clamp feature ids into [0, vocab_size).
// - For each of 28 slots, read values/offsets and sum embedding vectors.
// - Write slot outputs into the fused representation [N, 28 * 512].
// - Provide a correctness-first per-slot kernel.
// - Provide an optimized fused 28-slot kernel to reduce launch overhead.
// - Use vectorized loads/stores where possible because emb_dim is fixed at 512.
//
// Reference ideas:
// - LeetCUDA/kernels/embedding
// - LeetCUDA/kernels/reduce
//
// Expected inputs:
// - embedding_weight: [vocab_size, 512] fp16
// - slot_values[28]: variable-length int64/int32 ids
// - slot_offsets[28]: [N + 1] offsets per slot
//
// Expected output:
// - fused_embeddings: [N, 14336] fp16

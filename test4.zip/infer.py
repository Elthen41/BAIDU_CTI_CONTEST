import math
import argparse
import os
import shutil
import stat
import sys
from pathlib import Path
from collections import defaultdict


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_LIBRARIES = (SCRIPT_DIR / "libraries").resolve()
TORCH_EXTENSIONS_DIR = (SCRIPT_DIR / ".torch_extensions").resolve()


def _env_positive_int(name, default):
    value = os.environ.get(name, str(default))
    try:
        parsed = int(value)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer, got {value!r}") from exc
    if parsed <= 0:
        raise RuntimeError(f"{name} must be positive, got {parsed}")
    return parsed


USE_CUSTOM_CUDA_NORM = os.environ.get("USE_CUSTOM_CUDA_NORM", "1") != "0"
CHECK_CUSTOM_CUDA_NORM = os.environ.get("CHECK_CUSTOM_CUDA_NORM", "0") == "1"
USE_CUSTOM_CUDA_ATTENTION = os.environ.get("USE_CUSTOM_CUDA_ATTENTION", "1") != "0"
USE_TILED_CUDA_ATTENTION = os.environ.get("USE_TILED_CUDA_ATTENTION", "1") != "0"
USE_MMA_CUDA_ATTENTION = os.environ.get("USE_MMA_CUDA_ATTENTION", "1") != "0"
USE_MODEL_HALF = os.environ.get("USE_MODEL_HALF", "1") != "0"
USE_DENSE_ALL_SMOE = os.environ.get("USE_DENSE_ALL_SMOE", "1") != "0"
ATTENTION_TILED_BR = _env_positive_int("ATTENTION_TILED_BR", 8)
ATTENTION_TILED_BC = _env_positive_int("ATTENTION_TILED_BC", 64)
ATTENTION_TILED_THREADS = _env_positive_int("ATTENTION_TILED_THREADS", 128)
ATTENTION_MMA_BR = 16

if PROJECT_LIBRARIES.exists():
    sys.path.insert(0, str(PROJECT_LIBRARIES))

os.environ.setdefault("TORCH_EXTENSIONS_DIR", str(TORCH_EXTENSIONS_DIR))

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.cpp_extension import load
from tqdm import tqdm


_LAYER_NORM_EXT = None
_ATTENTION_EXT = None
_ATTENTION_KERNEL = None


def _configure_ninja():
    if shutil.which("ninja") is not None:
        return

    candidates = [
        PROJECT_LIBRARIES / "bin" / "ninja",
        PROJECT_LIBRARIES / "ninja" / "data" / "bin" / "ninja",
    ]

    try:
        import ninja
        bin_dir = getattr(ninja, "BIN_DIR", None)
        if bin_dir is not None:
            candidates.append(Path(bin_dir) / "ninja")
    except ImportError:
        pass

    if PROJECT_LIBRARIES.exists():
        candidates.extend(path for path in PROJECT_LIBRARIES.rglob("ninja") if path.is_file())

    seen = set()
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)

        if candidate.exists():
            mode = candidate.stat().st_mode
            if not mode & stat.S_IXUSR:
                candidate.chmod(mode | stat.S_IXUSR)
            os.environ["PATH"] = str(candidate.parent) + os.pathsep + os.environ.get("PATH", "")
            if shutil.which("ninja") is not None:
                print(f"[INFO] using local ninja: {candidate}")
                return

    raise RuntimeError(
        "Ninja is required to build the custom CUDA LayerNorm extension. "
        "Install it with: python -m pip install --target ./libraries --upgrade ninja"
    )


def _configure_cuda_arch():
    if "TORCH_CUDA_ARCH_LIST" in os.environ or not torch.cuda.is_available():
        return

    major, minor = torch.cuda.get_device_capability()
    os.environ["TORCH_CUDA_ARCH_LIST"] = f"{major}.{minor}"
    print(f"[INFO] using TORCH_CUDA_ARCH_LIST={os.environ['TORCH_CUDA_ARCH_LIST']}")


def _attention_tiled_cuda_flags():
    config = {
        "ATTENTION_TILED_BR": ATTENTION_TILED_BR,
        "ATTENTION_TILED_BC": ATTENTION_TILED_BC,
        "ATTENTION_TILED_THREADS": ATTENTION_TILED_THREADS,
    }
    summary = ", ".join(f"{key}={value}" for key, value in config.items())
    print(f"[INFO] using tiled attention compile config: {summary}")
    return [f"-D{key}={value}" for key, value in config.items()]


def _resolve_cuda_src():
    env_cuda_src = os.environ.get("CUDA_NORM_SRC")
    candidates = []
    if env_cuda_src:
        candidates.append(Path(env_cuda_src))

    candidates.extend([
        SCRIPT_DIR / "CUDA" / "norm_kernels.cu",
        SCRIPT_DIR / "norm_kernels.cu",
        Path.cwd() / "CUDA" / "norm_kernels.cu",
        Path.cwd() / "norm_kernels.cu",
        Path.home() / "code" / "CUDA" / "norm_kernels.cu",
        Path.home() / "code" / "norm_kernels.cu",
    ])

    seen = set()
    checked = []
    for path in candidates:
        path = path.expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        else:
            path = path.resolve()

        if path in seen:
            continue
        seen.add(path)
        checked.append(path)

        if path.exists():
            return path

    raise FileNotFoundError(
        "Custom CUDA source norm_kernels.cu not found. Checked:\n"
        + "\n".join(f"  - {path}" for path in checked)
    )


def _resolve_attention_cuda_src():
    env_cuda_src = os.environ.get("CUDA_ATTENTION_SRC")
    candidates = []
    if env_cuda_src:
        candidates.append(Path(env_cuda_src))

    candidates.extend([
        SCRIPT_DIR / "CUDA" / "attention_kernels.cu",
        Path.cwd() / "CUDA" / "attention_kernels.cu",
        Path.home() / "code" / "CUDA" / "attention_kernels.cu",
    ])

    seen = set()
    checked = []
    for path in candidates:
        path = path.expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        else:
            path = path.resolve()

        if path in seen:
            continue
        seen.add(path)
        checked.append(path)

        if path.exists():
            return path

    raise FileNotFoundError(
        "Custom CUDA source attention_kernels.cu not found. Checked:\n"
        + "\n".join(f"  - {path}" for path in checked)
    )


def _get_layernorm_ext():
    global _LAYER_NORM_EXT
    if _LAYER_NORM_EXT is not None:
        return _LAYER_NORM_EXT

    cuda_src = _resolve_cuda_src()

    _configure_ninja()
    _configure_cuda_arch()
    _LAYER_NORM_EXT = load(
        name="layernorm_512_ext",
        sources=[str(cuda_src)],
        extra_cflags=["-O3"],
        extra_cuda_cflags=["-O3"],
        verbose=os.environ.get("CUDA_EXT_VERBOSE") == "1",
    )
    return _LAYER_NORM_EXT


def _get_attention_ext():
    global _ATTENTION_EXT
    if _ATTENTION_EXT is not None:
        return _ATTENTION_EXT

    cuda_src = _resolve_attention_cuda_src()

    _configure_ninja()
    _configure_cuda_arch()
    _ATTENTION_EXT = load(
        name="varlen_attention_ext",
        sources=[str(cuda_src)],
        extra_cflags=["-O3"],
        extra_cuda_cflags=["-O3"] + _attention_tiled_cuda_flags(),
        verbose=os.environ.get("CUDA_EXT_VERBOSE") == "1",
    )
    return _ATTENTION_EXT


def _get_attention_kernel():
    global _ATTENTION_KERNEL
    if _ATTENTION_KERNEL is not None:
        return _ATTENTION_KERNEL

    ext = _get_attention_ext()
    if (
        USE_MMA_CUDA_ATTENTION
        and USE_TILED_CUDA_ATTENTION
        and hasattr(ext, "varlen_causal_attention_mma_qk_pv")
    ):
        _ATTENTION_KERNEL = (ext.varlen_causal_attention_mma_qk_pv, "mma-qk-pv")
    elif (
        USE_MMA_CUDA_ATTENTION
        and USE_TILED_CUDA_ATTENTION
        and hasattr(ext, "varlen_causal_attention_mma_qk")
    ):
        _ATTENTION_KERNEL = (ext.varlen_causal_attention_mma_qk, "mma-qk")
    elif USE_TILED_CUDA_ATTENTION and hasattr(ext, "varlen_causal_attention_tiled_compact"):
        _ATTENTION_KERNEL = (ext.varlen_causal_attention_tiled_compact, "compact")
    elif USE_TILED_CUDA_ATTENTION and hasattr(ext, "varlen_causal_attention_tiled"):
        _ATTENTION_KERNEL = (ext.varlen_causal_attention_tiled, "tiled")
    else:
        _ATTENTION_KERNEL = (ext.varlen_causal_attention, "one-query")
    return _ATTENTION_KERNEL


# ============================================================
# 数据加载（来自 train/dataset.py）
# ============================================================

def _detect_has_clk(file_path):
    """检测 CSV 文件是否包含 clk 列（5列 vs 4列格式）。
    5列格式: logid,userid,adid,clk,timestamp,sign:slot...
    4列格式: logid,userid,adid,timestamp,sign:slot...
    通过第5个字段是否包含 ':' 来判断：有 ':' 说明已经是 sign:slot，即无 clk 列。
    """
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(',')
            if len(parts) >= 5:
                return ':' not in parts[4]
            return False
    return False


def load_sample_files(sample_files_list):
    """加载 CSV sample 文件，返回 item_dict 和 user_seq。
    自动检测每个文件是 5列（含clk）还是 4列（无clk）格式。
    """
    sample_files = sorted([Path(f) for f in sample_files_list])
    print(f'[INFO] loading {len(sample_files)} files: {[str(f) for f in sample_files]}')

    item_dict = {}
    user_logs = defaultdict(list)

    for sample_file in tqdm(sample_files, desc='Loading sample files'):
        has_clk = _detect_has_clk(sample_file)
        min_parts = 5 if has_clk else 4
        print(f'  {sample_file.name}: has_clk={has_clk}')

        with open(sample_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split(',')
                if len(parts) < min_parts:
                    continue

                logid = int(parts[0])
                userid = int(parts[1])
                adid = int(parts[2])

                if has_clk:
                    clk = int(parts[3])
                    timestamp = int(parts[4])
                    feat_start = 5
                else:
                    clk = 0
                    timestamp = int(parts[3])
                    feat_start = 4

                signs = []
                slots = []
                for pair in parts[feat_start:]:
                    if ':' in pair:
                        s, sl = pair.split(':', 1)
                        signs.append(int(s))
                        slots.append(int(sl))

                item_dict[logid] = {
                    'logid': logid,
                    'userid': userid,
                    'adid': adid,
                    'clk': clk,
                    'timestamp': timestamp,
                    'signs': np.array(signs, dtype=np.int64),
                    'slots': np.array(slots, dtype=np.int64),
                }
                user_logs[userid].append((timestamp, logid))

    user_seq = {}
    for userid, logs in user_logs.items():
        logs.sort(key=lambda x: x[0])
        user_seq[userid] = [logid for _, logid in logs]

    print(f'[INFO] loaded {len(item_dict)} records, {len(user_seq)} users')
    return item_dict, user_seq


def load_logids_from_file(file_path):
    """快速读取一个 sample 文件中的所有 logid"""
    logids = set()
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            comma = line.index(',')
            logids.add(int(line[:comma]))
    return logids


class CTRUserDataset(Dataset):
    """按用户组织的 CTR 数据集"""

    def __init__(self, item_dict, user_seq=None, max_feasign_per_slot=None, pred_logids=None):
        super().__init__()
        self.item_dict = item_dict
        self.user_seq = user_seq if user_seq else {}
        self.max_feasign_per_slot = max_feasign_per_slot
        self.pred_logids = pred_logids if pred_logids is not None else set()

        self.user_items = defaultdict(list)
        for logid, rec in item_dict.items():
            userid = rec['userid']
            feasign = defaultdict(list)
            for slot, sign in zip(rec['slots'].tolist(), rec['signs'].tolist()):
                feasign[slot].append(sign)
            if max_feasign_per_slot is not None:
                feasign = {slot: signs[:max_feasign_per_slot[slot]]
                           if max_feasign_per_slot.get(slot, -1) != -1 else signs
                           for slot, signs in feasign.items()}
            feasign = dict(feasign)
            label = rec['clk']
            self.user_items[userid].append((logid, feasign, label))

        self.user_ids = sorted(self.user_items.keys())
        self.num_users = len(self.user_ids)
        self.total_samples = len(item_dict)

        all_signs = set()
        for rec in item_dict.values():
            all_signs.update(rec['signs'].tolist())
        self.max_slot_id = 28
        self.max_sign_id = max(all_signs) if all_signs else 0

    def __len__(self):
        return self.num_users

    def __getitem__(self, index):
        userid = self.user_ids[index]
        items = self.user_items[userid]

        if self.user_seq and userid in self.user_seq:
            seq_order = {logid: i for i, logid in enumerate(self.user_seq[userid])}
            items.sort(key=lambda x: seq_order.get(x[0], x[0]))
        else:
            items.sort(key=lambda x: x[0])

        feasigns = []
        labels = []
        logids = []
        for logid, feasign, label in items:
            logids.append(logid)
            feasigns.append(feasign)
            labels.append(label)

        return {
            'userid': userid,
            'logids': logids,
            'feasigns': feasigns,
            'labels': labels,
            'pred_mask': [1 if logid in self.pred_logids else 0 for logid in logids],
        }


def make_attention_tile_starts(user_offsets, br=ATTENTION_TILED_BR):
    if torch.is_tensor(user_offsets):
        offsets = user_offsets.detach().cpu().tolist()
        device = user_offsets.device
    else:
        offsets = list(user_offsets)
        device = None

    starts = []
    for start, end in zip(offsets[:-1], offsets[1:]):
        starts.extend(range(int(start), int(end), br))
    starts.reverse()
    return torch.tensor(starts, dtype=torch.long, device=device)


def ensure_attention_tile_starts(batch):
    changed = False
    if (
        isinstance(batch, dict)
        and "user_offsets" in batch
        and "attention_tile_starts" not in batch
    ):
        batch["attention_tile_starts"] = make_attention_tile_starts(batch["user_offsets"])
        changed = True
    if (
        isinstance(batch, dict)
        and "user_offsets" in batch
        and "attention_tile_starts_mma" not in batch
    ):
        batch["attention_tile_starts_mma"] = make_attention_tile_starts(batch["user_offsets"], br=ATTENTION_MMA_BR)
        changed = True
    return changed


def make_collate_fn(max_slot_id):
    def collate_user_batch(batch):
        all_userids = []
        all_logids = []
        all_labels = []
        all_pred_masks = []
        all_feasigns = []
        user_offsets = [0]

        for item in batch:
            for i, logid in enumerate(item['logids']):
                all_userids.append(item['userid'])
                all_logids.append(logid)
                all_labels.append(item['labels'][i])
                all_pred_masks.append(item['pred_mask'][i])
                all_feasigns.append(item['feasigns'][i])
            user_offsets.append(len(all_labels))

        slot_data = {}
        for slot in range(1, max_slot_id + 1):
            values = []
            offsets = [0]
            for feasign in all_feasigns:
                if slot in feasign:
                    values.extend(feasign[slot])
                offsets.append(len(values))
            slot_data[slot] = (
                torch.tensor(values, dtype=torch.long),
                torch.tensor(offsets, dtype=torch.long),
            )

        user_offsets_tensor = torch.tensor(user_offsets, dtype=torch.long)
        result = {
            'userid': torch.tensor(all_userids, dtype=torch.long),
            'logid': torch.tensor(all_logids, dtype=torch.long),
            'label': torch.tensor(all_labels, dtype=torch.float32),
            'pred_mask': torch.tensor(all_pred_masks, dtype=torch.bool),
            'user_offsets': user_offsets_tensor,
            'attention_tile_starts': make_attention_tile_starts(user_offsets_tensor),
            'attention_tile_starts_mma': make_attention_tile_starts(user_offsets_tensor, br=ATTENTION_MMA_BR),
        }
        result.update(slot_data)
        return result

    return collate_user_batch


# ============================================================
# 模型定义（来自 main.py）
# ============================================================

def move_batch_to_device(batch, device):
    if isinstance(batch, dict):
        return {k: move_batch_to_device(v, device) for k, v in batch.items()}
    elif isinstance(batch, (list, tuple)):
        return [move_batch_to_device(x, device) for x in batch]
    elif torch.is_tensor(batch):
        return batch.to(device)
    else:
        return batch


class RepEncoder(nn.Module):
    def __init__(self, vocab_size, emb_dim, padding_idx=0, slot_num=0, d_model=0):
        super().__init__()
        self.emb = nn.Embedding(num_embeddings=vocab_size, embedding_dim=emb_dim, padding_idx=padding_idx)
        self.emb_dim = emb_dim
        self.slot_num = slot_num
        self.input_norm = nn.LayerNorm(slot_num * emb_dim)
        self.linear = nn.Linear(in_features=slot_num * emb_dim, out_features=d_model)

    def forward(self, batch):
        pooled_embs = []
        max_idx = self.emb.num_embeddings - 1
        for i in range(self.slot_num):
            values, offsets = batch[i + 1]
            offsets = offsets.to(values.device)
            values = values.clamp(0, max_idx)  # 超出 vocab_size 的 sign id 截断，避免越界
            sign_emb = self.emb(values)
            res = torch.segment_reduce(sign_emb, reduce='sum', offsets=offsets, initial=0)
            pooled_embs.append(res)
        fused_embs = torch.cat(pooled_embs, dim=1)
        norm_emb = self.input_norm(fused_embs)
        rep_emb = self.linear(norm_emb)
        return rep_emb


def scaled_dot_product(q, k, v, extension):
    custom_attention_candidate = (
        USE_CUSTOM_CUDA_ATTENTION
        and extension is not None
        and "user_offsets" in extension
        and q.is_cuda
        and q.dim() == 4
        and q.size(0) == 1
        and q.size(-1) == 64
    )
    if custom_attention_candidate:
        if q.dtype != torch.float16 or k.dtype != torch.float16 or v.dtype != torch.float16:
            raise RuntimeError("custom CUDA attention is half-only; q/k/v must be float16")

        ext = _get_attention_ext()
        user_offsets = extension["user_offsets"].contiguous()
        tile_starts = extension.get("attention_tile_starts")
        tile_starts_mma = extension.get("attention_tile_starts_mma")
        if (
            USE_MMA_CUDA_ATTENTION
            and USE_TILED_CUDA_ATTENTION
            and tile_starts_mma is not None
            and hasattr(ext, "varlen_causal_attention_mma_qk_pv")
        ):
            return ext.varlen_causal_attention_mma_qk_pv(
                q.contiguous(),
                k.contiguous(),
                v.contiguous(),
                user_offsets,
                tile_starts_mma.contiguous(),
            )

        if (
            USE_MMA_CUDA_ATTENTION
            and USE_TILED_CUDA_ATTENTION
            and tile_starts_mma is not None
            and hasattr(ext, "varlen_causal_attention_mma_qk")
        ):
            return ext.varlen_causal_attention_mma_qk(
                q.contiguous(),
                k.contiguous(),
                v.contiguous(),
                user_offsets,
                tile_starts_mma.contiguous(),
            )

        if (
            USE_TILED_CUDA_ATTENTION
            and tile_starts is not None
            and hasattr(ext, "varlen_causal_attention_tiled_compact")
        ):
            return ext.varlen_causal_attention_tiled_compact(
                q.contiguous(),
                k.contiguous(),
                v.contiguous(),
                user_offsets,
                tile_starts.contiguous(),
            )

        if USE_TILED_CUDA_ATTENTION and hasattr(ext, "varlen_causal_attention_tiled"):
            return ext.varlen_causal_attention_tiled(
                q.contiguous(),
                k.contiguous(),
                v.contiguous(),
                user_offsets,
            )

        return ext.varlen_causal_attention(
            q.contiguous(),
            k.contiguous(),
            v.contiguous(),
            user_offsets,
        )

    d = q.size(-1)
    scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(d)
    if extension is not None and "mask" in extension:
        mask = extension["mask"]
        scores = scores.masked_fill(mask == 0, float("-inf"))
    attn = torch.softmax(scores, dim=-1)
    out = torch.matmul(attn, v)
    return out


class Expert(nn.Module):
    def __init__(self, d_model, dim_ff):
        super().__init__()
        self.fc1 = nn.Linear(d_model, dim_ff)
        self.fc2 = nn.Linear(dim_ff, d_model)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))


class TopKGate(nn.Module):
    def __init__(self, d_model, num_experts, k=2, noisy_gating=True):
        super().__init__()
        self.w_g = nn.Linear(d_model, num_experts)
        self.num_experts = num_experts
        self.k = k
        self.noisy_gating = noisy_gating

    def forward(self, x):
        # x: [B,S,D]
        logits = self.w_g(x)  # [B,S,E]

        if self.noisy_gating and self.training:
            logits = logits + torch.randn_like(logits) * 0.1

        if self.training:
            probs = torch.softmax(logits, dim=-1)  # [B,S,E]
            topk_score, topk_idx = torch.topk(probs, self.k, dim=-1)  # [B,S,k]
            return topk_idx, topk_score, probs

        topk_logits, topk_idx = torch.topk(logits, self.k, dim=-1)
        log_z = torch.logsumexp(logits, dim=-1, keepdim=True)
        topk_score = torch.exp(topk_logits - log_z)
        return topk_idx, topk_score, None

class SMoE(nn.Module):
    def __init__(self, d_model, dim_ff, num_experts, k=2):
        super().__init__()
        self.num_experts = num_experts
        self.k = k

        self.experts = nn.ModuleList([
            Expert(d_model, dim_ff) for _ in range(num_experts)
        ])

        self.gate = TopKGate(d_model, num_experts, k=k)

    def prepare_dense_all(self):
        w1 = torch.stack(
            [expert.fc1.weight.detach().t().contiguous() for expert in self.experts],
            dim=0,
        )
        b1 = torch.stack(
            [expert.fc1.bias.detach() for expert in self.experts],
            dim=0,
        )
        w2 = torch.stack(
            [expert.fc2.weight.detach().t().contiguous() for expert in self.experts],
            dim=0,
        )
        b2 = torch.stack(
            [expert.fc2.bias.detach() for expert in self.experts],
            dim=0,
        )

        self.register_buffer("_dense_all_w1", w1, persistent=False)
        self.register_buffer("_dense_all_b1", b1, persistent=False)
        self.register_buffer("_dense_all_w2", w2, persistent=False)
        self.register_buffer("_dense_all_b2", b2, persistent=False)

    def _forward_dense_all(self, x, topk_idx, topk_score):
        B, S, D = x.shape
        x_flat = x.reshape(-1, D)
        n_tokens = x_flat.shape[0]

        h = torch.baddbmm(
            self._dense_all_b1[:, None, :].expand(-1, n_tokens, -1),
            x_flat.unsqueeze(0).expand(self.num_experts, -1, -1),
            self._dense_all_w1,
        )
        h = F.relu(h)

        y = torch.baddbmm(
            self._dense_all_b2[:, None, :].expand(-1, n_tokens, -1),
            h,
            self._dense_all_w2,
        )
        y = y.permute(1, 0, 2).contiguous()

        selected = y.gather(
            1,
            topk_idx.reshape(n_tokens, self.k).unsqueeze(-1).expand(-1, -1, D),
        )
        out = (
            selected * topk_score.reshape(n_tokens, self.k).unsqueeze(-1)
        ).sum(dim=1)
        return out.reshape(B, S, D)

    def forward(self, x):
        # x: [B,S,D]
        B, S, D = x.shape

        topk_idx, topk_score, probs = self.gate(x)

        if (
            USE_DENSE_ALL_SMOE
            and not self.training
            and hasattr(self, "_dense_all_w1")
        ):
            if not hasattr(self, "_printed_dense_all"):
                print("[INFO] SMoE using dense-all path")
                self._printed_dense_all = True
            out = self._forward_dense_all(x, topk_idx, topk_score)
            return out, x.new_zeros(())

        out = torch.zeros_like(x)

        # flatten
        x_flat = x.reshape(-1, D)                # [B*S, D]
        idx_flat = topk_idx.reshape(-1, self.k)  # [B*S, k]
        score_flat = topk_score.reshape(-1, self.k)
        out_flat = out.reshape(-1, D)

        for i in range(self.num_experts):
            # 找到被路由到 expert i 的 token
            mask = (idx_flat == i)  # [B*S, k]

            # 哪些 token 命中了 expert i
            token_idx, k_idx = mask.nonzero(as_tuple=True)
            if token_idx.numel() == 0:
                continue

            selected_x = x_flat[token_idx]  # [N, D]

            expert_out = self.experts[i](selected_x)  # [N, D]

            weight = score_flat[token_idx, k_idx].unsqueeze(-1)

            out_flat[token_idx] += expert_out * weight

        if self.training:
            importance = probs.sum(dim=(0,1))  # [E]
            moe_loss = (importance.std() / (importance.mean() + 1e-6))
        else:
            moe_loss = x.new_zeros(())

        return out, moe_loss


class CustomLayerNorm512(nn.Module):
    """LayerNorm(512) replacement backed by CUDA/norm_kernels.cu."""

    def __init__(self, normalized_shape=512, eps=1e-5, elementwise_affine=True):
        super().__init__()
        if isinstance(normalized_shape, int):
            normalized_shape = (normalized_shape,)
        else:
            normalized_shape = tuple(normalized_shape)

        if normalized_shape != (512,):
            raise ValueError(f"CustomLayerNorm512 only supports normalized_shape=(512,), got {normalized_shape}")

        self.normalized_shape = normalized_shape
        self.eps = eps
        self.elementwise_affine = elementwise_affine

        if elementwise_affine:
            self.weight = nn.Parameter(torch.ones(512))
            self.bias = nn.Parameter(torch.zeros(512))
        else:
            self.register_parameter("weight", None)
            self.register_parameter("bias", None)

    def forward(self, x):
        if (
            USE_CUSTOM_CUDA_NORM
            and x.is_cuda
            and self.elementwise_affine
            and self.weight is not None
            and self.bias is not None
        ):
            if x.dtype != torch.float16 or self.weight.dtype != torch.float16 or self.bias.dtype != torch.float16:
                raise RuntimeError("custom CUDA LayerNorm is half-only; x/weight/bias must be float16")
            return _get_layernorm_ext().layernorm_512(
                x.contiguous(),
                self.weight.contiguous(),
                self.bias.contiguous(),
                self.eps,
            )

        return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)

    def add_layernorm(self, residual, x):
        return self.add_layernorm_with_residual(residual, x)[1]

    def add_layernorm_with_residual(self, residual, x):
        if (
            USE_CUSTOM_CUDA_NORM
            and residual.is_cuda
            and x.is_cuda
            and self.elementwise_affine
            and self.weight is not None
            and self.bias is not None
        ):
            if (
                residual.dtype != torch.float16
                or x.dtype != torch.float16
                or self.weight.dtype != torch.float16
                or self.bias.dtype != torch.float16
            ):
                raise RuntimeError("custom CUDA AddLayerNorm is half-only; residual/x/weight/bias must be float16")
            residual_out, norm_out = _get_layernorm_ext().add_layernorm_512_with_residual(
                residual.contiguous(),
                x.contiguous(),
                self.weight.contiguous(),
                self.bias.contiguous(),
                self.eps,
            )
            return residual_out, norm_out

        residual_out = residual + x
        norm_out = F.layer_norm(residual_out, self.normalized_shape, self.weight, self.bias, self.eps)
        return residual_out, norm_out


class TransformerEncoder(nn.Module):
    def __init__(self, d_model, n_heads, num_layers, dim_ff, act="relu",
                 attention_fn=scaled_dot_product):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.num_layers = num_layers
        assert d_model % n_heads == 0

        self.qkv_proj = nn.ModuleList([nn.Linear(d_model, 3 * d_model) for _ in range(num_layers)])
        self.out_proj = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(num_layers)])
        self.ffn1 = nn.ModuleList([nn.Linear(d_model, dim_ff) for _ in range(num_layers)])
        self.ffn2 = nn.ModuleList([nn.Linear(dim_ff, d_model) for _ in range(num_layers)])
        norm_cls = CustomLayerNorm512 if USE_CUSTOM_CUDA_NORM and d_model == 512 else nn.LayerNorm
        self.norm1 = nn.ModuleList([norm_cls(d_model) for _ in range(num_layers)])
        self.norm2 = nn.ModuleList([norm_cls(d_model) for _ in range(num_layers)])
        self.act = getattr(F, act)
        self.attention_fn = attention_fn
        self.moe = nn.ModuleList([
            SMoE(d_model, dim_ff, num_experts=8, k=2)
            for _ in range(num_layers)
        ])

    def prepare_dense_all_smoe(self):
        for moe in self.moe:
            moe.prepare_dense_all()

    def forward(self, x, extension):
        x = x.unsqueeze(0)
        B, S, D = x.shape

        moe_loss_total = 0.0
        for i in range(self.num_layers):
            residual = x
            x = self.norm1[i](x)
            qkv = self.qkv_proj[i](x)
            qkv = qkv.view(B, S, self.n_heads, 3 * self.head_dim)
            qkv = qkv.permute(0, 2, 1, 3)
            q, k, v = torch.split(qkv, self.head_dim, dim=-1)
            attn_out = self.attention_fn(q, k, v, extension)
            attn_out = attn_out.permute(0, 2, 1, 3).reshape(B, S, D)
            attn_proj = self.out_proj[i](attn_out)
            if hasattr(self.norm2[i], "add_layernorm_with_residual"):
                residual, x = self.norm2[i].add_layernorm_with_residual(residual, attn_proj)
            else:
                residual = residual + attn_proj
                x = self.norm2[i](residual)

            moe_out, moe_loss = self.moe[i](x)

            x = residual + moe_out

            moe_loss_total = moe_loss_total + moe_loss

        return x, moe_loss_total


class CTRModel(nn.Module):
    def __init__(self, rep_encoder, seq_encoder, d_model):
        super().__init__()
        self.rep_encoder = rep_encoder
        self.seq_encoder = seq_encoder
        self.d_model = d_model
        self.linear = nn.Linear(d_model, 1)

    def get_sequence_causal_mask(self, seq_info):
        # seq_info = tensor([0, 2, 5, 6])
        lengths = seq_info[1:] - seq_info[:-1]
        lengths = lengths.view(-1)
        # lengths = [2, 3, 1]
        indices = torch.cumsum(torch.ones_like(lengths), dim=0) - 1
        # 等价于 indices = torch.arange(len(lengths), device=lengths.device)
        # indices = [0, 1, 2]
        result = torch.repeat_interleave(indices, lengths)
        # result = [0, 0, 1, 1, 1, 2]
        a = result.view(1, -1) - result.view(-1, 1)
        # a = [
        #     [0-0, 0-0, 1-0, 1-0, 1-0, 2-0],
        #     [0-0, 0-0, 1-0, 1-0, 1-0, 2-0],
        #     [0-1, 0-1, 1-1, 1-1, 1-1, 2-1],
        #     ...
        #     ]
        # a == 0
        # 表示两个位置属于同一个用户
        out_mask = torch.tril((a == 0).to(torch.int32)).bool()
        return out_mask
        # [
        # [T, F, F, F, F, F],
        # [T, T, F, F, F, F],
        # [F, F, T, F, F, F],
        # [F, F, T, T, F, F],
        # [F, F, T, T, T, F],
        # [F, F, F, F, F, T],
        # ]

    def forward(self, batch):
        seq_input = self.rep_encoder(batch)
        seq_mask = None if USE_CUSTOM_CUDA_ATTENTION else self.get_sequence_causal_mask(batch["user_offsets"])
        extension = {"user_offsets": batch["user_offsets"]}
        if "attention_tile_starts" in batch:
            extension["attention_tile_starts"] = batch["attention_tile_starts"]
        if "attention_tile_starts_mma" in batch:
            extension["attention_tile_starts_mma"] = batch["attention_tile_starts_mma"]
        if seq_mask is not None:
            extension["mask"] = seq_mask.unsqueeze(0).unsqueeze(0)
        encoder_output, moe_loss = self.seq_encoder(
            x=seq_input,
            extension=extension,
        )
        encoder_output_dim = encoder_output.shape[-1]
        encoder_output = encoder_output.reshape(1, -1, encoder_output_dim).squeeze(0)
        pred = self.linear(encoder_output)
        pred_logits = torch.clamp(pred, min=-15.0, max=15.0)
        return pred_logits, moe_loss


def _warmup_custom_layernorm(device, dtype=torch.float16):
    if not USE_CUSTOM_CUDA_NORM:
        return

    dev = torch.device(device)
    if dev.type != "cuda":
        return

    ext = _get_layernorm_ext()
    with torch.no_grad():
        x = torch.randn((1, 512), device=dev, dtype=dtype)
        residual = torch.randn((1, 512), device=dev, dtype=dtype)
        weight = torch.ones((512,), device=dev, dtype=dtype)
        bias = torch.zeros((512,), device=dev, dtype=dtype)
        ext.layernorm_512(x, weight, bias, 1e-5)
        ext.add_layernorm_512(residual, x, weight, bias, 1e-5)
        ext.add_layernorm_512_with_residual(residual, x, weight, bias, 1e-5)
    torch.cuda.synchronize(dev)


def _warmup_custom_attention(device, dtype=torch.float16):
    if not USE_CUSTOM_CUDA_ATTENTION:
        return

    dev = torch.device(device)
    if dev.type != "cuda":
        return

    with torch.no_grad():
        q = torch.randn((1, 8, 8, 64), device=dev, dtype=dtype)
        k = torch.randn_like(q)
        v = torch.randn_like(q)
        offsets = torch.tensor([0, 3, 8], device=dev, dtype=torch.long)
        tile_starts = make_attention_tile_starts(offsets)
        tile_starts_mma = make_attention_tile_starts(offsets, br=ATTENTION_MMA_BR)
        attention_kernel, attention_kernel_name = _get_attention_kernel()
        if attention_kernel_name in ("mma-qk", "mma-qk-pv"):
            attention_kernel(q, k, v, offsets, tile_starts_mma)
        elif attention_kernel_name == "compact":
            attention_kernel(q, k, v, offsets, tile_starts)
        else:
            attention_kernel(q, k, v, offsets)
    torch.cuda.synchronize(dev)


def _check_custom_layernorm(model, device):
    if not CHECK_CUSTOM_CUDA_NORM or not USE_CUSTOM_CUDA_NORM:
        return

    dev = torch.device(device)
    if dev.type != "cuda":
        print("[WARNING] CHECK_CUSTOM_CUDA_NORM skipped because device is not CUDA")
        return

    norm = model.seq_encoder.norm1[0]
    if not isinstance(norm, CustomLayerNorm512):
        print(f"[WARNING] CHECK_CUSTOM_CUDA_NORM skipped because norm1[0] is {type(norm)}")
        return

    with torch.no_grad():
        dtype = norm.weight.dtype
        x = torch.randn((1, 1024, 512), device=dev, dtype=dtype)
        custom = norm(x)
        reference = F.layer_norm(x, (512,), norm.weight, norm.bias, norm.eps)
        diff = (custom.float() - reference.float()).abs()
        print(
            "[INFO] custom LayerNorm check: "
            f"max_abs_err={diff.max().item():.6e}, "
            f"mean_abs_err={diff.mean().item():.6e}"
        )

        residual = torch.randn_like(x)
        custom_add = norm.add_layernorm(residual, x)
        reference_add = F.layer_norm(residual + x, (512,), norm.weight, norm.bias, norm.eps)
        add_diff = (custom_add.float() - reference_add.float()).abs()
        print(
            "[INFO] custom AddLayerNorm check: "
            f"max_abs_err={add_diff.max().item():.6e}, "
            f"mean_abs_err={add_diff.mean().item():.6e}"
        )

        custom_residual, custom_norm = norm.add_layernorm_with_residual(residual, x)
        reference_residual = residual + x
        residual_diff = (custom_residual.float() - reference_residual.float()).abs()
        norm_diff = (custom_norm.float() - reference_add.float()).abs()
        print(
            "[INFO] custom AddLayerNormWithResidual check: "
            f"residual_max_abs_err={residual_diff.max().item():.6e}, "
            f"norm_max_abs_err={norm_diff.max().item():.6e}"
        )


def _resolve_ckpt_path(ckpt_path=None):
    candidates = []

    if ckpt_path is not None:
        candidates.append(Path(ckpt_path))

    env_ckpt = os.environ.get("CKPT_PATH")
    if env_ckpt:
        candidates.append(Path(env_ckpt))

    candidates.extend([
        SCRIPT_DIR / "ckpt.pt",
        SCRIPT_DIR / "code" / "ckpt.pt",
        Path.cwd() / "ckpt.pt",
        Path.cwd() / "code" / "ckpt.pt",
        Path.home() / "code" / "ckpt.pt",
    ])

    seen = set()
    unique_candidates = []
    for path in candidates:
        path = path.expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        else:
            path = path.resolve()

        if path in seen:
            continue
        seen.add(path)
        unique_candidates.append(path)

        if path.exists():
            return path, unique_candidates

    return unique_candidates[0], unique_candidates


# ============================================================
# 模型加载入口
# ============================================================

def load_model(device='cuda:0', ckpt_path=None):
    """加载模型并返回，供 evaluation.py 调用。

    Args:
        device: 推理设备（默认 'cuda:0'）
        ckpt_path: checkpoint 文件路径，默认使用 infer.py 同目录下的 ckpt.pt

    Returns:
        (model, device) 元组
    """
    emb_dim = 512
    slot_num = 28
    vocab_size = 5000000
    d_model = 512
    n_heads = 8
    num_layers = 8
    dim_ff = 1024

    rep_encoder = RepEncoder(
        vocab_size=vocab_size,
        emb_dim=emb_dim,
        padding_idx=0,
        slot_num=slot_num,
        d_model=d_model,
    )
    seq_encoder = TransformerEncoder(
        d_model=d_model,
        n_heads=n_heads,
        num_layers=num_layers,
        dim_ff=dim_ff,
        act="relu",
    )
    model = CTRModel(rep_encoder, seq_encoder, d_model=d_model)

    dev = torch.device(device if torch.cuda.is_available() else "cpu")

    # 加载 checkpoint
    # 若需要加载自定义修改的权重，请修改 479-488行逻辑，强制使用你文件夹中的权重
    # 测评系统默认使用原始官方权重
    ckpt_path, ckpt_candidates = _resolve_ckpt_path(ckpt_path)
    if ckpt_path.exists():
        ckpt = torch.load(ckpt_path, map_location='cpu', weights_only=False)
        model.load_state_dict(ckpt['model_state_dict'])
        print(f"[INFO] Loaded checkpoint from {ckpt_path} (epoch={ckpt.get('epoch', '?')})")
    else:
        print(f"[WARNING] Checkpoint {ckpt_path} not found, using random weights")
        print("[WARNING] Checked checkpoint candidates:")
        for candidate in ckpt_candidates:
            print(f"  - {candidate}")

    model.to(dev)
    if USE_MODEL_HALF and dev.type == "cuda":
        model.half()
        print("[INFO] Converted model to float16")
    if USE_DENSE_ALL_SMOE:
        model.seq_encoder.prepare_dense_all_smoe()
        print("[INFO] Prepared dense-all SMoE weights")
    model.eval()
    model_dtype = next(model.parameters()).dtype
    _warmup_custom_layernorm(dev, dtype=model_dtype)
    _warmup_custom_attention(dev, dtype=model_dtype)
    _check_custom_layernorm(model, dev)
    print(f"[INFO] Model ready. Device: {dev}")
    if USE_CUSTOM_CUDA_NORM:
        print("[INFO] Using custom CUDA LayerNorm(512) for TransformerEncoder norm1/norm2")
    else:
        print("[INFO] Using PyTorch LayerNorm for TransformerEncoder norm1/norm2")
    if USE_CUSTOM_CUDA_ATTENTION:
        if dev.type == "cuda":
            _, attention_kernel_name = _get_attention_kernel()
            print(f"[INFO] Using custom CUDA varlen causal attention ({attention_kernel_name})")
        else:
            print("[INFO] Using custom CUDA varlen causal attention")

    return model, dev


# ============================================================
# 打分工具（与 evaluation.py 保持一致）
# ============================================================

def _read_predict(file_path):
    predictions = []
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                predictions.append(float(line))
    import numpy as np
    return np.array(predictions)


def _read_label(file_path):
    labels = []
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                parts = line.split(',')
                if len(parts) >= 4:
                    labels.append(float(parts[3]))
                else:
                    labels.append(float(line))
    import numpy as np
    return np.array(labels)


def _cal_score(predict_file, label_file, default_latency=0.0):
    import numpy as np
    from sklearn.metrics import roc_auc_score

    predictions = _read_predict(predict_file)
    labels = _read_label(label_file)

    unique_labels = np.unique(labels)
    if len(unique_labels) < 2:
        print('[WARNING] only one class present in labels, AUC is not defined, returning 0.5')
        auc = 0.5
    else:
        auc = roc_auc_score(labels, predictions)

    mean_pred = np.mean(predictions)
    mean_label = np.mean(labels)
    if mean_label == 0:
        pcoc = 1.0 if mean_pred == 0 else float('inf')
    else:
        pcoc = float(mean_pred / mean_label)

    latency = default_latency
    base_latency = 300
    score_latency = max(0.0, (base_latency - latency) / base_latency) if latency < base_latency else 0.0

    if pcoc < 0.85 or pcoc > 1.15:
        score_model = 0.0
    else:
        score_model = ((auc - 0.65) * 1000 + (0.15 - abs(pcoc - 1)) / 0.15 * 10) / 360

    score_all = score_latency * 70 + score_model * 30

    return {
        'auc': auc,
        'pcoc': pcoc,
        'latency': latency,
        'score_latency': score_latency,
        'score_model': score_model,
        'score_all': score_all,
    }


# ============================================================
# main：直接运行 infer.py 进行测试
# ============================================================

def main():
    import io
    import time
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--ckpt', type=str, default=None, help='checkpoint 文件路径，默认使用同目录下的 ckpt.pt')
    args = parser.parse_args()

    cur_path = Path(__file__).parent.absolute()
    ref_dir = cur_path / 'dataset'
    if not ref_dir.exists() and (cur_path / 'code' / 'dataset').exists():
        ref_dir = cur_path / 'code' / 'dataset'
    history_dir = ref_dir / 'history'
    input_file = ref_dir / 'test.csv'
    output_file = Path('predict.txt')
    label_file = ref_dir / 'label_data.txt'

    # ----- 数据加载，优先从缓存读取 -----
    MAX_SHARD_BYTES = 2 * 1024 * 1024 * 1024  # 2GB per shard
    batches_cache_dir = ref_dir / 'cached_batches'

    if batches_cache_dir.exists() and any(batches_cache_dir.glob('shard_*.pt')):
        print(f'[INFO] loading cached batch shards from {batches_cache_dir}')
        all_batches = []
        shard_files = sorted(batches_cache_dir.glob('shard_*.pt'),
                             key=lambda p: int(p.stem.split('_')[1]))
        for sf in shard_files:
            shard_batches = torch.load(sf, weights_only=False)
            all_batches.extend(shard_batches)
            print(f'[INFO] loaded {len(shard_batches)} batches from {sf.name}')
        print(f'[INFO] loaded {len(all_batches)} cached batches total from {len(shard_files)} shards')
    else:
        print('[INFO] start loading data from CSV')
        history_files = sorted(history_dir.glob('*.csv')) if history_dir.exists() else []
        all_files = history_files + [input_file]

        item_dict, user_seq = load_sample_files(sample_files_list=all_files)
        test_pred_logids = load_logids_from_file(input_file)
        print(f'[INFO] Test pred logids count: {len(test_pred_logids)}')

        max_feasign_per_slot = {1: 2}
        test_dataset = CTRUserDataset(
            item_dict, user_seq,
            max_feasign_per_slot=max_feasign_per_slot,
            pred_logids=test_pred_logids,
        )
        print(f'[INFO] num_users={test_dataset.num_users}, '
              f'total_samples={test_dataset.total_samples}, '
              f'pred_samples={len(test_pred_logids)}, '
              f'max_sign_id={test_dataset.max_sign_id}')

        test_loader = DataLoader(
            test_dataset,
            batch_size=50,
            shuffle=False,
            num_workers=0,
            collate_fn=make_collate_fn(test_dataset.max_slot_id),
        )

        # 收集 batches 并按分片缓存
        print('[INFO] collecting batches and saving sharded cache...')
        all_batches = [batch for batch in test_loader]

        batches_cache_dir.mkdir(parents=True, exist_ok=True)
        shard_idx = 0
        current_shard = []
        current_size = 0
        for batch in all_batches:
            buf = io.BytesIO()
            torch.save(batch, buf)
            batch_size_bytes = buf.tell()
            if current_shard and current_size + batch_size_bytes > MAX_SHARD_BYTES:
                shard_path = batches_cache_dir / f'shard_{shard_idx:04d}.pt'
                torch.save(current_shard, shard_path)
                print(f'[INFO] saved shard {shard_path.name}: {len(current_shard)} batches, '
                      f'~{current_size / 1024**3:.2f}GB')
                shard_idx += 1
                current_shard = []
                current_size = 0
            current_shard.append(batch)
            current_size += batch_size_bytes
        if current_shard:
            shard_path = batches_cache_dir / f'shard_{shard_idx:04d}.pt'
            torch.save(current_shard, shard_path)
            print(f'[INFO] saved shard {shard_path.name}: {len(current_shard)} batches, '
                  f'~{current_size / 1024**3:.2f}GB')
            shard_idx += 1
        print(f'[INFO] saved {len(all_batches)} batches to {shard_idx} shards in {batches_cache_dir}')

    added_tile_starts = sum(1 for batch in all_batches if ensure_attention_tile_starts(batch))
    if added_tile_starts:
        print(f'[INFO] added compact attention tile_starts to {added_tile_starts} cached batches')

    print('[INFO] data loading done')

    # ----- 加载模型 -----
    model, dev = load_model(ckpt_path=args.ckpt)

    # ----- 推理 -----
    print('*' * 20 + ' start inference ' + '*' * 20)
    all_logids = []
    all_probs = []
    time_sum = 0.0

    with torch.no_grad():
        for batch in tqdm(all_batches, desc="Inference"):
            batch = move_batch_to_device(batch, dev)
            pred_mask = batch["pred_mask"].bool()

            t_start = time.time()
            logits, moe_loss = model(batch)
            logits = logits.squeeze(-1)
            probs = torch.sigmoid(logits.float())
            time_sum += time.time() - t_start

            masked_logids = batch["logid"][pred_mask].cpu().tolist()
            masked_probs = probs[pred_mask].cpu().tolist()
            all_logids.extend(masked_logids)
            all_probs.extend(masked_probs)

    print(f'[INFO] inference time: {round(time_sum, 4)}s')
    print('*' * 20 + ' end inference ' + '*' * 20)

    # ----- 按 test.csv 顺序写预测文件 -----
    logid_to_prob = dict(zip(all_logids, all_probs))
    test_logids_in_order = []
    with open(input_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                test_logids_in_order.append(int(line.split(',')[0]))
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, 'w') as f:
        for logid in test_logids_in_order:
            f.write(f"{logid_to_prob[logid]}\n")
    print(f'[INFO] predictions written to {output_file}, total: {len(test_logids_in_order)}')

    # ----- 打分 -----
    if label_file.exists():
        result = _cal_score(output_file, label_file, default_latency=time_sum)
        print(f'[INFO] AUC:            {result["auc"]:.6f}')
        print(f'[INFO] PCOC:           {result["pcoc"]:.6f}')
        print(f'[INFO] Latency:        {result["latency"]:.4f}s')
        print(f'[INFO] score_latency:  {result["score_latency"]:.6f}')
        print(f'[INFO] score_model:    {result["score_model"]:.6f}')
        print(f'[INFO] score_all:      {result["score_all"]:.6f}')
        return result
    else:
        print(f'[WARNING] label file {label_file} not found, skipping scoring')
        return None


if __name__ == '__main__':
    main()

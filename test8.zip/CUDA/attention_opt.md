# Attention 后续优化计划

当前 attention 已有两个 CUDA 入口：

```text
varlen_causal_attention        one-query-per-block fallback
varlen_causal_attention_tiled  Br=8, Bc=64 tiled online-softmax 版本
```

后续只对照本仓库内 `LeetCUDA/kernels/flash-attn` 的实现继续改进。不能直接照搬 dense attention kernel，因为本项目 attention 有两个约束：

```text
q/k/v/out: [B=1, heads=8, S, head_dim=64], float16
user_offsets: 每个用户段内做 causal attention
不同用户之间不能互相 attend
softmax/m/l/O 状态需要 fp32
```

## 当前 tiled 版本和 LeetCUDA 的差距

参考文件：

```text
LeetCUDA/kernels/flash-attn/README.md
LeetCUDA/kernels/flash-attn/mma/basic/flash_attn_mma_share_qkv_F32F16F16F32.cu
LeetCUDA/kernels/flash-attn/cutlass/flash_attn_cute.cu
LeetCUDA/kernels/flash-attn/utils/utils.h
LeetCUDA/kernels/softmax/softmax.cu
LeetCUDA/kernels/hgemm/wmma/hgemm_wmma_stage.cu
```

当前实现的主要不足：

```text
1. Q @ K^T 仍用 CUDA core 标量循环，没有 Tensor Core MMA。
2. Br=8 太小，CTA 工作量偏少，K/V tile 复用不足。
3. O 累加时对每个 dim 重复计算 exp(score - m_new)，同一个 P[row,key] 被重复算 64 次。
4. row max / row denom 由少数线程串行扫 Bc，没有用 warp-level reduce。
5. Q/K/V gmem -> smem 是 half 标量加载，没有 128-bit vectorized load。
6. 没有 cp.async/double buffering，global memory latency 没有隐藏。
7. shared memory layout 没有 padding/swizzle，不适合后续 ldmatrix/MMA。
8. tile 调度仍有 early-return block，尚未使用 compact tile table。
```

## 优化顺序

### 1. 先做低风险 CUDA Core 版本优化

这一阶段不引入 MMA，只改当前 `varlen_causal_attention_tiled` 的实现。目标是用较小改动拿到收益，并为 MMA 版本清理结构。

#### 1.1 消除重复 exp

当前问题：

```cpp
for dim in 0..63:
    for key in k_tile:
        tile_acc += exp(score[row,key] - new_m[row]) * V[key,dim]
```

同一个 `exp(score[row,key] - new_m[row])` 会被 64 个 dim 重复计算。

改进：

```text
scores_shared[row,key] 先原地转成 p_shared[row,key]
p_shared[row,key] = exp(score[row,key] - new_m[row])
O 更新阶段只读 p_shared，不再重复 exp
```

预期收益：减少大量 SFU/exp 开销。该项优先级最高。

状态：已在 `varlen_causal_attention_tiled` 中落地。`scores_shared` 现在先从 score 转成 `p_shared=exp(score-new_m)`，后续 `O` 更新和 `l` 更新复用该值。

云端 A800 独立测试结果：

```text
len=226: tiled 1.227824 ms -> 0.783542 ms
len=401: tiled 2.917252 ms -> 2.326134 ms
correctness: max_abs_err <= 1.953e-03
```

#### 1.2 row max / denom 改成 warp reduce

当前 `tid < Br`，每个 row 一个线程串行扫 `Bc=64`。

改进方向参考：

```text
LeetCUDA/kernels/softmax/softmax.cu
LeetCUDA/kernels/flash-attn/utils/utils.h
```

计划：

```text
每个 query row 分配一个 warp 或半 warp
warp 内 reduce max
warp 内 reduce sum(exp)
只把每行 m/l/new_m 写入 shared
```

这样可减少 softmax tile 阶段的串行开销。

状态：已在 `varlen_causal_attention_tiled` 中落地。当前 `Br=8, threads=128`，每个 query row 使用 16 lanes 做 row max 和 denom reduce；`p_shared` 生成和 denom 求和在同一段 row-wise 循环中完成。

#### 1.3 调 Br / Bc / threads

当前参数：

```text
Br=8
Bc=64
threads=128
```

需要 benchmark 的候选：

```text
Br=8,  Bc=64,  threads=128  当前默认
Br=16, Bc=64,  threads=128
Br=32, Bc=64,  threads=128 或 256
Br=16, Bc=128, threads=256
```

已添加遍历脚本：

```bash
/opt/conda/envs/python35-paddle120-env/bin/python code/sweep_attention_params.py --iters 50
```

默认会分别跑 `bench_len=226` 和 `bench_len=401`，日志和 `summary.csv` 会写到：

```text
code/attention_sweep_runs/<timestamp>/
```

云端 A800 sweep 结果：

```text
Br=8,  Bc=64,  threads=128: len=226 0.836106 ms, len=401 2.000849 ms
Br=16, Bc=64,  threads=128: len=226 0.808075 ms, len=401 2.079351 ms
Br=32, Bc=64,  threads=128: len=226 1.020892 ms, len=401 2.241167 ms
Br=32, Bc=64,  threads=256: len=226 0.811628 ms, len=401 2.200706 ms
Br=16, Bc=128, threads=256: len=226 0.898460 ms, len=401 2.066316 ms
```

结论：

```text
len=226 最优: Br=16, Bc=64, threads=128
len=401 最优: Br=8,  Bc=64, threads=128
```

虽然 `Br=16` 在 `len=226` 上比默认 `Br=8` 快约 3.4%，但它在 `len=401` 上慢约 3.9%。真实 attention 工作量近似随用户长度平方增长，长用户对端到端耗时的影响更大，因此单一静态配置暂时保持：

```text
Br=8, Bc=64, threads=128
```

注意：用户长度分布 mean≈226、p90≈401，`Br` 过大可能导致短用户浪费，但 `Br=8` 对复用和并行度都偏保守。

#### 1.4 Q/K/V 使用 128-bit vectorized load

参考：

```text
LeetCUDA/kernels/flash-attn/utils/utils.h
LeetCUDA/kernels/hgemm/wmma/hgemm_wmma_stage.cu
```

可借鉴的宏/模式：

```cpp
INT4(value)
FLOAT4(value)
LDST128BITS(value)
```

本项目 head_dim 固定 64，half 一行 128 bytes，非常适合按 16 bytes 对齐加载。优先改 K/V tile load，其次 Q tile load。

状态：已在 `varlen_causal_attention_tiled` 的 gmem -> smem staging 中落地。当前 Q tile 和 K/V tile 都按 128-bit 复制，每次搬 8 个 half；shared memory 数组增加 16-byte 对齐。该项只改变加载路径，不改变 score/softmax/O 累加逻辑，等待云端 A800 验证收益。

### 2. 再做 Tensor Core MMA 版本

新增独立入口，例如：

```text
varlen_causal_attention_mma
```

不要直接替换 tiled CUDA-core 版本。先作为第三个 extension 函数单独 correctness/benchmark。

#### 2.1 先实现 QK MMA

参考：

```text
LeetCUDA/kernels/flash-attn/mma/basic/flash_attn_mma_share_qkv_F32F16F16F32.cu
```

目标：

```text
D=64
Br=16 或 32 起步
Bc=64
mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32
QK accumulator fp32
causal mask 和 user boundary 在 tile 内处理
```

不要一开始就做完整 LeetCUDA 的 `Br=64`。本项目是变长 causal，小段用户很多，先用较小 Br 降低边界处理复杂度。

状态：已添加独立入口：

```text
varlen_causal_attention_mma_qk(q, k, v, user_offsets, tile_starts)
```

第一版固定：

```text
Br=16
Bc=64
threads=128
compact tile scheduler
```

实现范围：

```text
QK: inline PTX ldmatrix + mma.sync.m16n8k16, fp16 x fp16 -> fp32
softmax: 复用当前 fp32 row max / denom reduce
P@V: 复用当前 CUDA-core fp32 accumulate
out: fp16
```

`code/test_cuda_attention.py` 现在会同时输出 `varlen_causal_attention_mma_qk` 的 correctness 和 benchmark。

云端 A800 验证结果：

```text
len=226:
one-query      1.643670 ms
tiled          0.701626 ms
compact        0.663273 ms
mma_qk         0.276989 ms
dense_torch    3.728755 ms

len=401:
one-query      4.786529 ms
tiled          2.005472 ms
compact        1.975185 ms
mma_qk         0.751366 ms
dense_torch   14.125153 ms
```

正确性：

```text
all tested cases passed
max_abs_err <= 1.953e-03
```

收益：

```text
len=226: mma_qk 比 compact 快约 2.39x
len=401: mma_qk 比 compact 快约 2.63x
```

结论：`QK MMA + CUDA-core P@V` 已经有明确收益。

`infer.py` 接入状态：

```text
默认启用 USE_MMA_CUDA_ATTENTION=1
优先使用 varlen_causal_attention_mma_qk_pv
如果扩展不包含 qk_pv 入口，则回退到 varlen_causal_attention_mma_qk
MMA tile_starts 固定按 Br=16 生成
```

回退方式：

```bash
USE_MMA_CUDA_ATTENTION=0 python infer.py
```

关闭后会回退到当前 compact tiled attention。

#### 2.2 再实现 P @ V MMA

难点：softmax 后的 `P` 是 fp32，Tensor Core 的 `P @ V` 通常需要 half/bf16 输入。

可选路径：

```text
路径 A: P 转 half，再用 MMA 做 P@V，速度更快，但误差要重新验证。
路径 B: QK 用 MMA，P@V 暂时保持 fp32 CUDA core，风险较低。
```

建议先做路径 B，确认 QK MMA 的收益和正确性后，再尝试路径 A。

当前状态：已开始尝试路径 A，并新增独立入口：

```text
varlen_causal_attention_mma_qk_pv(q, k, v, user_offsets, tile_starts)
```

第一版固定：

```text
Br=16
Bc=64
threads=128
compact tile scheduler
```

实现范围：

```text
QK: 继续使用 inline PTX ldmatrix + mma.sync.m16n8k16
softmax: 继续使用 fp32 row max / denom reduce
P: 将 exp(score-new_m) 写入 half p_shared[Br, Bc]
P@V: 使用 ldmatrix.x4 读取 P，ldmatrix.x2.trans 读取 V，mma.sync fp16 x fp16 -> fp32
O: fp32 online accumulation，最后除以 fp32 l 后写 fp16
```

该入口参考 LeetCUDA 的核心映射：

```text
LeetCUDA/kernels/flash-attn/mma/basic/flash_attn_mma_share_qkv_F32F16F16F32.cu
LeetCUDA/kernels/flash-attn/mma/swizzle/flash_attn_mma_tiling_qkv_swizzle_q_F32F16F16F32.cu
```

云端 A800 验证结果：

```text
len=226:
one-query      1.642886 ms
tiled          0.680186 ms
compact        0.663645 ms
mma_qk         0.276290 ms
mma_qk_pv      0.166712 ms
dense_torch    3.672384 ms

len=401:
one-query      5.290416 ms
tiled          2.010070 ms
compact        1.983029 ms
mma_qk         0.751153 ms
mma_qk_pv      0.435713 ms
dense_torch   14.112083 ms
```

正确性：

```text
all tested cases passed
max_abs_err <= 1.953e-03
```

收益：

```text
len=226: mma_qk_pv 比 mma_qk 快约 1.66x，比 compact 快约 3.98x
len=401: mma_qk_pv 比 mma_qk 快约 1.72x，比 compact 快约 4.55x
```

结论：`QK MMA + P@V MMA` correctness 已通过独立测试，且有明确收益。`infer.py` 默认路径已切到 `varlen_causal_attention_mma_qk_pv`，保留 `varlen_causal_attention_mma_qk` 作为扩展入口兼容回退。

#### 2.3 shared memory layout / ldmatrix

MMA 版本需要处理 shared memory layout：

```text
Q: [Br, 64]
K: [Bc, 64]，以 K^T 的访问方式进入 MMA
V: [Bc, 64]
```

可参考：

```text
LeetCUDA/kernels/flash-attn/mma/basic/flash_attn_mma_share_qkv_F32F16F16F32.cu
LeetCUDA/kernels/flash-attn/mma/swizzle/*
LeetCUDA/kernels/swizzle/hgemm_mma_swizzle.cu
```

第一版 MMA 可以先用 padding 降低 bank conflict，后续再做 swizzle。

### 3. 最后做 LeetCUDA 级别的高级优化

这些放在 MMA correctness 和独立 benchmark 稳定之后：

```text
cp.async gmem -> smem
K/V double buffering
shared QKV memory reuse
prefetch Q smem -> register
swizzle/padding 处理 bank conflict
compact q_tile scheduler，减少 early-return CTA
```

对应参考：

```text
LeetCUDA/kernels/flash-attn/mma/basic/flash_attn_mma_share_qkv_F32F16F16F32.cu
LeetCUDA/kernels/hgemm/wmma/hgemm_wmma_stage.cu
LeetCUDA/kernels/flash-attn/mma/swizzle/*
```

当前状态：

```text
已在 UseMmaQk 路径添加 K/V gmem -> smem 的 cp.async 预取
已在 UseMmaQk 路径添加 2-stage K/V shared memory double buffering
已在 UseMmaQk 路径添加 Q smem -> register fragment prefetch
影响入口: varlen_causal_attention_mma_qk 和 varlen_causal_attention_mma_qk_pv
未影响入口: varlen_causal_attention_tiled / tiled_compact CUDA-core fallback
```

实现方式：

```text
第 0 个 K/V tile 在 K 循环前预取到 stage 0
每轮循环开始 wait 当前 stage
随后立即把下一个 K/V tile cp.async 到另一个 stage
当前 QK/PV MMA 计算与下一块 K/V global load 重叠
Q tile 在 K 循环前用 ldmatrix.x4 一次性读到寄存器
后续所有 K tile 的 QK MMA 复用 Q fragment，不再重复从 shared 读取 Q
```

Q tile 的 global -> shared 仍然是同步 128-bit load；当前优化只把 Q shared -> register 的重复 ldmatrix 从 K tile 循环中移出。该优化会增加每线程约 16 个 32-bit Q fragment 寄存器，需要云端 benchmark 确认收益是否大于 occupancy/reg pressure 代价。

下一步可以根据云端结果决定是否继续做：

```text
Q tile cp.async
K/V swizzle + padding
Br=32/64 MMA 变体
```

## Scheduler 改进

当前 tiled kernel 使用反向 candidate 调度：

```text
grid.x = seq_len
candidate_query = seq_len - 1 - blockIdx.x
只有 local_query % Br == 0 的 block 真正工作
```

优点：实现简单，后段重 tile 会更早调度。

缺点：存在 early-return CTA。

已添加 compact tile table 路径：

```text
tile_starts: int64[num_tiles]
每个元素是一个全局 q_tile_start
按 user_offsets 在 Python 侧预构造
按 q_tile_start 反向排序，保持后段重 tile 优先
grid.x = tile_starts.numel()
```

新增 CUDA 入口：

```text
varlen_causal_attention_tiled_compact(q, k, v, user_offsets, tile_starts)
```

旧入口仍保留：

```text
varlen_causal_attention_tiled(q, k, v, user_offsets)
```

这样 benchmark 可以同时对照 candidate scheduler 和 compact scheduler。`infer.py` 在关闭 MMA 路径时会优先使用 compact 入口；如果 batch 里没有 `attention_tile_starts`，会回退到旧 tiled 入口。旧 cached batches 在加载后会自动补齐 `attention_tile_starts`，不需要删 cache 重建。

预期收益：减少空 CTA，并可按 causal 工作量调度长 tile。收益应在 `Br=16/32` 时更明显，因为 candidate scheduler 下 empty CTA 比例随 `Br` 增大而上升。

compact 后重新测试：

```bash
/opt/conda/envs/python35-paddle120-env/bin/python code/sweep_attention_params.py --iters 50
```

## 验收方式

每个新版本都必须保留旧入口作为 fallback，并通过独立 attention 测试：

```bash
python code/test_cuda_attention.py --bench-len 226 --iters 50
python code/test_cuda_attention.py --bench-len 401 --iters 50
```

正确性要求：

```text
相对 PyTorch fp16 reference，max_abs_err 目标 <= 3e-3
端到端 AUC/PCOC 不明显劣化
```

性能判断：

```text
必须分别优于当前 one-query fallback 和当前 tiled CUDA-core 版本
如果独立 attention 更快但端到端 latency 没收益，需要先 profile attention 占比
```

当前 A800 独立 baseline：

```text
len=226: one-query=1.633477 ms, tiled=0.783542 ms, dense_torch=3.672973 ms
len=401: one-query=5.178977 ms, tiled=2.326134 ms, dense_torch=14.127046 ms
```

## Cached Batch Profile 对参数选择的影响

`code/profile_cached.txt` 是 `code/profile_cached_batches.py` 在云端 cached batches 上的统计结果：

```text
scanned_batches=2039
batch_seq_len: count=2039, min=1221, p50=4425, p90=5948.8, p95=6395.9, p99=7294.44, max=10793, mean=4531.73
batch_user_count: count=2039, min=10, p50=20, p90=20, p95=20, p99=20, max=20, mean=20
user_seq_len: count=40770, min=100, p50=173, p90=401, p95=523, p99=857, max=3350, mean=226.64
varlen_causal / dense: 0.035922
dense / varlen_causal: 27.84x
```

注意：当前 `infer.py` 里的 `DataLoader(batch_size=50)` 只在重新从 CSV 构造 cache 时生效。如果 `cached_batches/shard_*.pt` 已存在，`infer.py` 会直接读取旧 cache，`batch_size=50` 不会改变已缓存 batch 的用户数。上面的 profile 显示实际 cached batch 基本是 20 个用户，而不是 50 个用户。

### 对 attention benchmark 的含义

当前独立 benchmark：

```bash
python code/test_cuda_attention.py --bench-len 226 --iters 50
python code/test_cuda_attention.py --bench-len 401 --iters 50
```

脚本默认 `--bench-users=20`，这正好匹配 profile 里的实际 cached batch：

```text
20 users * mean user_len 226 ~= batch_seq_len mean 4520
profile batch_seq_len mean ~= 4531.73
```

因此当前 `len=226/users=20` benchmark 是真实平均 batch 的合理近似。`len=401/users=20` 则是偏重的 p90 用户长度压力测试。

如果后续真的重新生成 `batch_size=50` 的 cache，则 attention benchmark 也应补测：

```bash
python code/test_cuda_attention.py --bench-users 50 --bench-len 226 --iters 50
python code/test_cuda_attention.py --bench-users 50 --bench-len 401 --iters 50
```

### 对 Br 的影响

`Br` 应主要根据 `user_seq_len` 选，而不是根据 `batch_seq_len` 选，因为 attention 的 causal 边界在用户段内：

```text
user_len p50=173
user_len mean=226.64
user_len p90=401
user_len p99=857
user_len max=3350
```

当前 `Br=8` 非常保守：

```text
mean user: ceil(226/8)  ~= 29 q_tiles
p90 user:  ceil(401/8)  ~= 51 q_tiles
p99 user:  ceil(857/8)  ~= 108 q_tiles
max user:  ceil(3350/8) ~= 419 q_tiles
```

因为最短用户长度也有 100，`Br=16` 或 `Br=32` 不会严重浪费短序列，值得测试：

```text
Br=16: mean user ~= 15 q_tiles, p90 ~= 26 q_tiles, p99 ~= 54 q_tiles
Br=32: mean user ~= 8 q_tiles,  p90 ~= 13 q_tiles, p99 ~= 27 q_tiles
```

建议下一轮优先测试：

```text
Br=16, Bc=64,  threads=128
Br=32, Bc=64,  threads=128/256
Br=16, Bc=128, threads=256
```

### 对 Bc 的影响

`Bc=64` 仍然是合理默认：

```text
mean user_len 226 -> 约 4 个 K/V tile
p90  user_len 401 -> 约 7 个 K/V tile
p99  user_len 857 -> 约 14 个 K/V tile
```

`Bc=128` 可以减少 K/V tile 循环次数，但会增大 `scores_shared[Br, Bc]`、softmax reduce 和 P@V 单 tile 工作量。它可能对 p90/p99 长用户有利，但需要和 `Br` 一起实测。

### 对 scheduler 的影响

当前 tiled kernel 的 launch：

```text
grid.x = seq_len
grid.y = heads
只有 local_query % Br == 0 的 block 真正工作
```

对于 `Br=8`，大约只有 1/8 的 candidate blocks 是 active；`Br=16/32` 时 active 比例更低。profile 的平均 batch seq_len 约 4532，因此每层每个 batch 约启动：

```text
Br=8:  grid blocks ~= 4532 * 8 heads = 36256 candidate blocks
       active blocks ~= sum(ceil(user_len/8)) * 8 heads ~= 4600
```

如果增大 `Br`，compact tile scheduler 的价值会上升。也就是说：

```text
Br=8 可以先继续用当前 candidate scheduler
Br=16/32 最好同时评估 compact tile table，否则 empty CTA overhead 可能抵消部分收益
```

### 对长尾用户的影响

`user_seq_len max=3350`，p99=857，长尾用户会显著贡献 causal attention 的 `L*(L+1)/2` 工作量。后续可以考虑 hybrid policy：

```text
短/中用户: Br=16 或 Br=32 CUDA-core tiled
长用户: MMA tiled kernel
```

但第一阶段不建议直接做 hybrid。先用单一 `Br/Bc` 参数跑通 benchmark，再根据端到端收益决定是否拆分长短用户路径。

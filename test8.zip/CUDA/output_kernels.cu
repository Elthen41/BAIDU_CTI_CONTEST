// CUDA output kernels for the final CTR prediction head.
//
// This extension fuses:
//   encoder_output[pred_positions] [P,512]
//   -> head Linear(512 -> 1)
//   -> clamp [-15, 15]
//   -> sigmoid
//   -> compact logid/prob buffers
//
// It intentionally only computes the final head for tokens that need to be
// written to predict.txt.

#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cstdint>
#include <limits>
#include <vector>

namespace {

constexpr int kHiddenDim = 512;
constexpr int kThreads = 256;

void check_same_device(const torch::Tensor& a, const torch::Tensor& b, const char* a_name, const char* b_name) {
    TORCH_CHECK(a.device() == b.device(), a_name, " and ", b_name, " must be on the same CUDA device");
}

void check_inputs(
    const torch::Tensor& encoder_output,
    const torch::Tensor& weight,
    const torch::Tensor& bias,
    const torch::Tensor& logids,
    const torch::Tensor& pred_positions
) {
    TORCH_CHECK(encoder_output.is_cuda(), "encoder_output must be a CUDA tensor");
    TORCH_CHECK(weight.is_cuda(), "weight must be a CUDA tensor");
    TORCH_CHECK(bias.is_cuda(), "bias must be a CUDA tensor");
    TORCH_CHECK(logids.is_cuda(), "logids must be a CUDA tensor");
    TORCH_CHECK(pred_positions.is_cuda(), "pred_positions must be a CUDA tensor");

    check_same_device(encoder_output, weight, "encoder_output", "weight");
    check_same_device(encoder_output, bias, "encoder_output", "bias");
    check_same_device(encoder_output, logids, "encoder_output", "logids");
    check_same_device(encoder_output, pred_positions, "encoder_output", "pred_positions");

    TORCH_CHECK(encoder_output.scalar_type() == at::kHalf, "encoder_output must be float16");
    TORCH_CHECK(weight.scalar_type() == at::kHalf, "weight must be float16");
    TORCH_CHECK(bias.scalar_type() == at::kHalf, "bias must be float16");
    TORCH_CHECK(logids.scalar_type() == at::kLong, "logids must be int64");
    TORCH_CHECK(pred_positions.scalar_type() == at::kLong, "pred_positions must be int64");

    TORCH_CHECK(encoder_output.is_contiguous(), "encoder_output must be contiguous");
    TORCH_CHECK(weight.is_contiguous(), "weight must be contiguous");
    TORCH_CHECK(bias.is_contiguous(), "bias must be contiguous");
    TORCH_CHECK(logids.is_contiguous(), "logids must be contiguous");
    TORCH_CHECK(pred_positions.is_contiguous(), "pred_positions must be contiguous");

    TORCH_CHECK(encoder_output.dim() == 2, "encoder_output must have shape [S,512]");
    TORCH_CHECK(encoder_output.size(1) == kHiddenDim, "encoder_output must have shape [S,512]");
    TORCH_CHECK(weight.dim() == 2, "weight must have shape [1,512]");
    TORCH_CHECK(weight.size(0) == 1, "weight must have shape [1,512]");
    TORCH_CHECK(weight.size(1) == kHiddenDim, "weight must have shape [1,512]");
    TORCH_CHECK(bias.dim() == 1, "bias must have shape [1]");
    TORCH_CHECK(bias.size(0) == 1, "bias must have shape [1]");
    TORCH_CHECK(logids.dim() == 1, "logids must have shape [S]");
    TORCH_CHECK(logids.size(0) == encoder_output.size(0), "logids must have shape [S]");
    TORCH_CHECK(pred_positions.dim() == 1, "pred_positions must have shape [P]");
    TORCH_CHECK(
        pred_positions.size(0) <= static_cast<int64_t>(std::numeric_limits<int>::max()),
        "pred_positions has too many elements"
    );
}

__global__ void head_sigmoid_gather_positions_kernel(
    const __half* __restrict__ encoder_output,
    const __half* __restrict__ weight,
    const __half* __restrict__ bias,
    const int64_t* __restrict__ logids,
    const int64_t* __restrict__ pred_positions,
    int64_t* __restrict__ out_logids,
    float* __restrict__ out_probs,
    int64_t n_tokens,
    int64_t n_pred
) {
    const int64_t pred_idx = static_cast<int64_t>(blockIdx.x);
    if (pred_idx >= n_pred) {
        return;
    }

    const int tid = threadIdx.x;
    const int64_t token_idx = pred_positions[pred_idx];
    if (token_idx < 0 || token_idx >= n_tokens) {
        if (tid == 0) {
            out_logids[pred_idx] = 0;
            out_probs[pred_idx] = 0.0f;
        }
        return;
    }

    float sum = 0.0f;
    const int64_t token_base = token_idx * kHiddenDim;
    if (tid < kHiddenDim) {
        sum += __half2float(encoder_output[token_base + tid]) * __half2float(weight[tid]);
    }
    const int dim1 = tid + kThreads;
    if (dim1 < kHiddenDim) {
        sum += __half2float(encoder_output[token_base + dim1]) * __half2float(weight[dim1]);
    }

    __shared__ float partial[kThreads];
    partial[tid] = sum;
    __syncthreads();

    for (int stride = kThreads / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            partial[tid] += partial[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        float logit = __half2float(__float2half_rn(partial[0] + __half2float(bias[0])));
        logit = fminf(fmaxf(logit, -15.0f), 15.0f);
        out_logids[pred_idx] = logids[token_idx];
        out_probs[pred_idx] = 1.0f / (1.0f + expf(-logit));
    }
}

}  // namespace

std::vector<torch::Tensor> head_sigmoid_gather_positions(
    torch::Tensor encoder_output,
    torch::Tensor weight,
    torch::Tensor bias,
    torch::Tensor logids,
    torch::Tensor pred_positions
) {
    check_inputs(encoder_output, weight, bias, logids, pred_positions);

    const int64_t n_tokens = encoder_output.size(0);
    const int64_t n_pred = pred_positions.size(0);
    auto out_logids = torch::empty({n_pred}, logids.options());
    auto out_probs = torch::empty({n_pred}, encoder_output.options().dtype(torch::kFloat));

    if (n_pred == 0) {
        return {out_logids, out_probs};
    }

    head_sigmoid_gather_positions_kernel<<<static_cast<int>(n_pred), kThreads, 0, at::cuda::getCurrentCUDAStream()>>>(
        reinterpret_cast<const __half*>(encoder_output.data_ptr<c10::Half>()),
        reinterpret_cast<const __half*>(weight.data_ptr<c10::Half>()),
        reinterpret_cast<const __half*>(bias.data_ptr<c10::Half>()),
        logids.data_ptr<int64_t>(),
        pred_positions.data_ptr<int64_t>(),
        out_logids.data_ptr<int64_t>(),
        out_probs.data_ptr<float>(),
        n_tokens,
        n_pred
    );
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    return {out_logids, out_probs};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def(
        "head_sigmoid_gather_positions",
        &head_sigmoid_gather_positions,
        "Final head Linear(512->1) + sigmoid + pred position gather"
    );
}

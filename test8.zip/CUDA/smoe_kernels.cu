// CUDA routed sparse Mixture-of-Experts kernels.
//
// This file implements the first routed sparse SMoE path:
//   topk_idx/topk_score
//     -> route count + padded expert offsets
//     -> pack x[N,512] by expert into x_route[pool,512]
//     -> grouped fc1 + bias + ReLU
//     -> grouped fc2 + bias
//     -> explicit top-2 reduce back to out[N,512]
//
// Weight layout is the same TN-friendly layout used by dense_all_smoe:
//   w1: [8,1024,512], b1: [8,1024]
//   w2: [8,512,1024], b2: [8,512]
//
// The grouped GEMM microkernel follows the LeetCUDA SM80 HGEMM TN shape:
// 128x128 CTA tile, 8 warps, cp.async for full M tiles, ldmatrix, and
// mma.sync.m16n8k16 with fp32 accumulation.

#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>
#include <pybind11/stl.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>

#include <cstdint>
#include <limits>
#include <vector>

namespace {

constexpr int kNumExperts = 8;
constexpr int kHiddenDim = 512;
constexpr int kFfDim = 1024;
constexpr int kTopK = 2;

constexpr int kWarpSize = 32;
constexpr int kThreads = 256;
constexpr int kBlockM = 128;
constexpr int kBlockN = 128;
constexpr int kMmaM = 16;
constexpr int kMmaN = 8;
constexpr int kMmaK = 16;
constexpr int kWarpTileM = 4;
constexpr int kWarpTileN = 4;
constexpr int kPipelineStages = 2;

struct RouteMetadata {
    torch::Tensor x_route;
    torch::Tensor route_pos;
    torch::Tensor route_token;
    torch::Tensor route_slot;
    torch::Tensor route_score;
    torch::Tensor counts;
    torch::Tensor offsets;
    int64_t max_routes_per_expert;
};

int64_t ceil_div_int64(int64_t a, int64_t b) {
    return (a + b - 1) / b;
}

int64_t max_pool_routes_for_tokens(int64_t n_tokens) {
    if (n_tokens == 0) {
        return 0;
    }
    return n_tokens * kTopK + kNumExperts * (kBlockM - 1);
}

void check_half_cuda_contiguous(const torch::Tensor& tensor, const char* name) {
    TORCH_CHECK(tensor.is_cuda(), name, " must be a CUDA tensor");
    TORCH_CHECK(tensor.scalar_type() == at::kHalf, name, " must be float16");
    TORCH_CHECK(tensor.is_contiguous(), name, " must be contiguous");
}

void check_i32_cuda_contiguous(const torch::Tensor& tensor, const char* name) {
    TORCH_CHECK(tensor.is_cuda(), name, " must be a CUDA tensor");
    TORCH_CHECK(tensor.scalar_type() == at::kInt, name, " must be int32");
    TORCH_CHECK(tensor.is_contiguous(), name, " must be contiguous");
}

void check_topk_idx(const torch::Tensor& tensor, const char* name) {
    TORCH_CHECK(tensor.is_cuda(), name, " must be a CUDA tensor");
    TORCH_CHECK(tensor.is_contiguous(), name, " must be contiguous");
    TORCH_CHECK(
        tensor.scalar_type() == at::kLong || tensor.scalar_type() == at::kInt,
        name, " must be int64 or int32"
    );
}

void check_topk_score(const torch::Tensor& tensor, const char* name) {
    TORCH_CHECK(tensor.is_cuda(), name, " must be a CUDA tensor");
    TORCH_CHECK(tensor.is_contiguous(), name, " must be contiguous");
    TORCH_CHECK(
        tensor.scalar_type() == at::kHalf || tensor.scalar_type() == at::kFloat,
        name, " must be float16 or float32"
    );
}

void check_same_device(const torch::Tensor& a, const torch::Tensor& b, const char* a_name, const char* b_name) {
    TORCH_CHECK(a.device() == b.device(), a_name, " and ", b_name, " must be on the same CUDA device");
}

void check_n_tokens(int64_t n_tokens) {
    TORCH_CHECK(n_tokens >= 0, "n_tokens must be non-negative");
    TORCH_CHECK(n_tokens <= static_cast<int64_t>(std::numeric_limits<int>::max()) / kTopK,
        "n_tokens is too large");
    TORCH_CHECK(max_pool_routes_for_tokens(n_tokens) <= static_cast<int64_t>(std::numeric_limits<int32_t>::max()),
        "n_tokens creates a route pool that is too large for int32 metadata");
    TORCH_CHECK(ceil_div_int64(n_tokens * kTopK, kBlockM) <= 65535,
        "n_tokens creates too many CTA rows for this first implementation");
}

__device__ __forceinline__ uint32_t shared_addr(const void* ptr) {
    return static_cast<uint32_t>(__cvta_generic_to_shared(ptr));
}

__device__ __forceinline__ void cp_async_cg_16(uint32_t dst, const void* src) {
    asm volatile(
        "cp.async.cg.shared.global.L2::128B [%0], [%1], 16;\n"
        :
        : "r"(dst), "l"(src)
    );
}

__device__ __forceinline__ void cp_async_commit_group() {
    asm volatile("cp.async.commit_group;\n" ::);
}

__device__ __forceinline__ void cp_async_wait_all() {
    asm volatile("cp.async.wait_all;\n" ::);
}

__device__ __forceinline__ void ldmatrix_x4(
    uint32_t& r0,
    uint32_t& r1,
    uint32_t& r2,
    uint32_t& r3,
    uint32_t addr
) {
    asm volatile(
        "ldmatrix.sync.aligned.x4.m8n8.shared.b16 {%0, %1, %2, %3}, [%4];\n"
        : "=r"(r0), "=r"(r1), "=r"(r2), "=r"(r3)
        : "r"(addr)
    );
}

__device__ __forceinline__ void ldmatrix_x2(
    uint32_t& r0,
    uint32_t& r1,
    uint32_t addr
) {
    asm volatile(
        "ldmatrix.sync.aligned.x2.m8n8.shared.b16 {%0, %1}, [%2];\n"
        : "=r"(r0), "=r"(r1)
        : "r"(addr)
    );
}

__device__ __forceinline__ void hmma16816_f32(
    uint32_t& d0,
    uint32_t& d1,
    uint32_t& d2,
    uint32_t& d3,
    uint32_t a0,
    uint32_t a1,
    uint32_t a2,
    uint32_t a3,
    uint32_t b0,
    uint32_t b1,
    uint32_t c0,
    uint32_t c1,
    uint32_t c2,
    uint32_t c3
) {
    asm volatile(
        "mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 "
        "{%0, %1, %2, %3}, {%4, %5, %6, %7}, {%8, %9}, {%10, %11, %12, %13};\n"
        : "=r"(d0), "=r"(d1), "=r"(d2), "=r"(d3)
        : "r"(a0), "r"(a1), "r"(a2), "r"(a3),
          "r"(b0), "r"(b1),
          "r"(c0), "r"(c1), "r"(c2), "r"(c3)
    );
}

__device__ __forceinline__ float reg_as_float(uint32_t reg) {
    return __uint_as_float(reg);
}

__device__ __forceinline__ uint32_t pack_half2_bits(float lo, float hi) {
    union {
        __half2 h2;
        uint32_t u32;
    } packed;
    packed.h2 = __halves2half2(__float2half_rn(lo), __float2half_rn(hi));
    return packed.u32;
}

template <typename IndexT>
__global__ void smoe_route_count_kernel(
    const IndexT* __restrict__ topk_idx,
    int32_t* __restrict__ counts,
    int64_t n_tokens
) {
    const int64_t route_id = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const int64_t total_routes = n_tokens * kTopK;
    if (route_id >= total_routes) {
        return;
    }

    const int expert = static_cast<int>(topk_idx[route_id]);
    if (expert >= 0 && expert < kNumExperts) {
        atomicAdd(counts + expert, 1);
    }
}

__global__ void smoe_route_prefix_kernel(
    const int32_t* __restrict__ counts,
    int32_t* __restrict__ offsets,
    int32_t* __restrict__ cursors
) {
    if (threadIdx.x != 0 || blockIdx.x != 0) {
        return;
    }

    int32_t running = 0;
#pragma unroll
    for (int expert = 0; expert < kNumExperts; ++expert) {
        offsets[expert] = running;
        cursors[expert] = running;
        const int32_t count = counts[expert];
        const int32_t padded = ((count + kBlockM - 1) / kBlockM) * kBlockM;
        running += padded;
    }
    offsets[kNumExperts] = running;
}

template <typename IndexT, typename ScoreT>
__global__ void smoe_route_pack_kernel(
    const c10::Half* __restrict__ x,
    const IndexT* __restrict__ topk_idx,
    const ScoreT* __restrict__ topk_score,
    int32_t* __restrict__ cursors,
    c10::Half* __restrict__ x_route,
    int32_t* __restrict__ route_pos,
    int32_t* __restrict__ route_token,
    int32_t* __restrict__ route_slot,
    ScoreT* __restrict__ route_score,
    int64_t n_tokens
) {
    const int64_t route_id = blockIdx.x;
    const int token = static_cast<int>(route_id >> 1);
    const int slot = static_cast<int>(route_id & 1);
    if (route_id >= n_tokens * kTopK) {
        return;
    }

    const int expert = static_cast<int>(topk_idx[route_id]);
    if (expert < 0 || expert >= kNumExperts) {
        return;
    }

    __shared__ int32_t shared_pos;
    if (threadIdx.x == 0) {
        shared_pos = atomicAdd(cursors + expert, 1);
        const int32_t pos = shared_pos;
        route_pos[token * kTopK + slot] = pos;
        route_token[pos] = token;
        route_slot[pos] = slot;
        route_score[pos] = topk_score[route_id];
    }
    __syncthreads();
    const int32_t pos = shared_pos;

    const uint4* __restrict__ x_vec =
        reinterpret_cast<const uint4*>(x + static_cast<int64_t>(token) * kHiddenDim);
    uint4* __restrict__ route_vec =
        reinterpret_cast<uint4*>(x_route + static_cast<int64_t>(pos) * kHiddenDim);
    constexpr int kVecsPerRow = kHiddenDim / 8;
    for (int vec = threadIdx.x; vec < kVecsPerRow; vec += blockDim.x) {
        route_vec[vec] = x_vec[vec];
    }
}

template <int InDim, int OutDim>
__device__ __forceinline__ void load_grouped_tile_scalar(
    const c10::Half* __restrict__ input,
    const c10::Half* __restrict__ weight,
    const int32_t* __restrict__ counts,
    const int32_t* __restrict__ offsets,
    c10::Half* __restrict__ a_shared,
    c10::Half* __restrict__ b_shared,
    int expert,
    int local_m_tile_base,
    int n_tile_base,
    int k_base,
    int tid
) {
    const int expert_count = counts[expert];
    const int expert_offset = offsets[expert];

    for (int idx = tid; idx < kBlockM * kMmaK; idx += kThreads) {
        const int local_m = idx / kMmaK;
        const int local_k = idx - local_m * kMmaK;
        const int route_m = local_m_tile_base + local_m;
        const int global_k = k_base + local_k;

        c10::Half val = static_cast<c10::Half>(0.0f);
        if (route_m < expert_count) {
            const int64_t input_idx =
                (static_cast<int64_t>(expert_offset) + route_m) * InDim + global_k;
            val = input[input_idx];
        }
        a_shared[idx] = val;
    }

    for (int idx = tid; idx < kBlockN * kMmaK; idx += kThreads) {
        const int local_n = idx / kMmaK;
        const int local_k = idx - local_n * kMmaK;
        const int global_n = n_tile_base + local_n;
        const int global_k = k_base + local_k;

        const int64_t weight_idx =
            (static_cast<int64_t>(expert) * OutDim + global_n) * InDim + global_k;
        b_shared[idx] = weight[weight_idx];
    }
}

template <int InDim, int OutDim>
__device__ __forceinline__ void load_grouped_tile_cp_async(
    const c10::Half* __restrict__ input,
    const c10::Half* __restrict__ weight,
    const int32_t* __restrict__ offsets,
    c10::Half* __restrict__ a_shared,
    c10::Half* __restrict__ b_shared,
    int expert,
    int local_m_tile_base,
    int n_tile_base,
    int k_base,
    int tid
) {
    const int local_row = tid >> 1;
    const int local_k = (tid & 1) * 8;
    const int expert_offset = offsets[expert];
    const int route_m = local_m_tile_base + local_row;
    const int global_n = n_tile_base + local_row;
    const int global_k = k_base + local_k;

    const int64_t input_idx =
        (static_cast<int64_t>(expert_offset) + route_m) * InDim + global_k;
    const int64_t weight_idx =
        (static_cast<int64_t>(expert) * OutDim + global_n) * InDim + global_k;

    const uint32_t a_addr = shared_addr(a_shared + local_row * kMmaK + local_k);
    const uint32_t b_addr = shared_addr(b_shared + local_row * kMmaK + local_k);
    cp_async_cg_16(a_addr, input + input_idx);
    cp_async_cg_16(b_addr, weight + weight_idx);
}

__device__ __forceinline__ void compute_grouped_mma_stage(
    const c10::Half* __restrict__ a_shared,
    const c10::Half* __restrict__ b_shared,
    int warp_m,
    int warp_n,
    int lane,
    uint32_t (&acc)[kWarpTileM][kWarpTileN][4]
) {
    uint32_t a_frag[kWarpTileM][4];
    uint32_t b_frag[kWarpTileN][2];

#pragma unroll
    for (int i = 0; i < kWarpTileM; ++i) {
        const int warp_smem_a_m = warp_m * (kMmaM * kWarpTileM) + i * kMmaM;
        const int lane_smem_a_m = warp_smem_a_m + (lane & 15);
        const int lane_smem_a_k = (lane >= 16) ? 8 : 0;
        const uint32_t a_addr =
            shared_addr(a_shared + lane_smem_a_m * kMmaK + lane_smem_a_k);
        ldmatrix_x4(
            a_frag[i][0],
            a_frag[i][1],
            a_frag[i][2],
            a_frag[i][3],
            a_addr
        );
    }

#pragma unroll
    for (int j = 0; j < kWarpTileN; ++j) {
        const int warp_smem_b_n = warp_n * (kMmaN * kWarpTileN) + j * kMmaN;
        const int lane_smem_b_n = warp_smem_b_n + (lane & 7);
        const int lane_smem_b_k = ((lane >> 3) & 1) * 8;
        const uint32_t b_addr =
            shared_addr(b_shared + lane_smem_b_n * kMmaK + lane_smem_b_k);
        ldmatrix_x2(b_frag[j][0], b_frag[j][1], b_addr);
    }

#pragma unroll
    for (int i = 0; i < kWarpTileM; ++i) {
#pragma unroll
        for (int j = 0; j < kWarpTileN; ++j) {
            hmma16816_f32(
                acc[i][j][0],
                acc[i][j][1],
                acc[i][j][2],
                acc[i][j][3],
                a_frag[i][0],
                a_frag[i][1],
                a_frag[i][2],
                a_frag[i][3],
                b_frag[j][0],
                b_frag[j][1],
                acc[i][j][0],
                acc[i][j][1],
                acc[i][j][2],
                acc[i][j][3]
            );
        }
    }
}

template <int InDim, int OutDim, bool ApplyRelu>
__global__ __launch_bounds__(kThreads) void smoe_grouped_linear_mma_tn_kernel(
    const c10::Half* __restrict__ input,
    const c10::Half* __restrict__ weight,
    const c10::Half* __restrict__ bias,
    const int32_t* __restrict__ counts,
    const int32_t* __restrict__ offsets,
    c10::Half* __restrict__ output
) {
    static_assert(InDim % kMmaK == 0, "InDim must be divisible by 16");
    static_assert(OutDim % kBlockN == 0, "OutDim must be divisible by 128");

    __shared__ __align__(16) c10::Half a_shared[kPipelineStages * kBlockM * kMmaK];
    __shared__ __align__(16) c10::Half b_shared[kPipelineStages * kBlockN * kMmaK];

    const int tid = threadIdx.x;
    const int warp_id = tid / kWarpSize;
    const int lane = tid & (kWarpSize - 1);
    const int expert = blockIdx.z;
    const int local_m_tile_base = blockIdx.y * kBlockM;
    const int n_tile_base = blockIdx.x * kBlockN;

    const int expert_count = counts[expert];
    if (local_m_tile_base >= expert_count) {
        return;
    }
    const int expert_offset = offsets[expert];

    const int warp_m = warp_id & 1;
    const int warp_n = warp_id >> 1;

    uint32_t acc[kWarpTileM][kWarpTileN][4];
#pragma unroll
    for (int i = 0; i < kWarpTileM; ++i) {
#pragma unroll
        for (int j = 0; j < kWarpTileN; ++j) {
#pragma unroll
            for (int r = 0; r < 4; ++r) {
                acc[i][j][r] = 0;
            }
        }
    }

    const bool full_m_tile = (local_m_tile_base + kBlockM) <= expert_count;
    constexpr int kNumKTiles = InDim / kMmaK;
    constexpr int kStageStrideA = kBlockM * kMmaK;
    constexpr int kStageStrideB = kBlockN * kMmaK;

    if (full_m_tile) {
        load_grouped_tile_cp_async<InDim, OutDim>(
            input,
            weight,
            offsets,
            a_shared,
            b_shared,
            expert,
            local_m_tile_base,
            n_tile_base,
            0,
            tid
        );
        cp_async_commit_group();
        cp_async_wait_all();
        __syncthreads();

        for (int k_tile = 1; k_tile < kNumKTiles; ++k_tile) {
            const int compute_stage = (k_tile + 1) & 1;
            const int load_stage = k_tile & 1;

            load_grouped_tile_cp_async<InDim, OutDim>(
                input,
                weight,
                offsets,
                a_shared + load_stage * kStageStrideA,
                b_shared + load_stage * kStageStrideB,
                expert,
                local_m_tile_base,
                n_tile_base,
                k_tile * kMmaK,
                tid
            );
            cp_async_commit_group();

            compute_grouped_mma_stage(
                a_shared + compute_stage * kStageStrideA,
                b_shared + compute_stage * kStageStrideB,
                warp_m,
                warp_n,
                lane,
                acc
            );

            cp_async_wait_all();
            __syncthreads();
        }

        constexpr int last_stage = (kNumKTiles - 1) & 1;
        compute_grouped_mma_stage(
            a_shared + last_stage * kStageStrideA,
            b_shared + last_stage * kStageStrideB,
            warp_m,
            warp_n,
            lane,
            acc
        );
    } else {
        for (int k_base = 0; k_base < InDim; k_base += kMmaK) {
            load_grouped_tile_scalar<InDim, OutDim>(
                input,
                weight,
                counts,
                offsets,
                a_shared,
                b_shared,
                expert,
                local_m_tile_base,
                n_tile_base,
                k_base,
                tid
            );
            __syncthreads();

            compute_grouped_mma_stage(
                a_shared,
                b_shared,
                warp_m,
                warp_n,
                lane,
                acc
            );
            __syncthreads();
        }
    }

    const int row_base = local_m_tile_base + warp_m * (kMmaM * kWarpTileM);
    const int col_base = n_tile_base + warp_n * (kMmaN * kWarpTileN);
    const int frag_row0 = lane / 4;
    const int frag_row1 = frag_row0 + 8;
    const int frag_col_pair = (lane & 3) * 2;
    const int lane_group_base = lane & ~3;

#pragma unroll
    for (int i = 0; i < kWarpTileM; ++i) {
#pragma unroll
        for (int j = 0; j < kWarpTileN; ++j) {
            const int rows[2] = {
                row_base + i * kMmaM + frag_row0,
                row_base + i * kMmaM + frag_row1,
            };
            const int col = col_base + j * kMmaN + frag_col_pair;

#pragma unroll
            for (int row_slot = 0; row_slot < 2; ++row_slot) {
                const int route_m = rows[row_slot];
                float value0 = reg_as_float(acc[i][j][row_slot * 2 + 0])
                    + static_cast<float>(bias[expert * OutDim + col + 0]);
                float value1 = reg_as_float(acc[i][j][row_slot * 2 + 1])
                    + static_cast<float>(bias[expert * OutDim + col + 1]);
                if constexpr (ApplyRelu) {
                    value0 = fmaxf(value0, 0.0f);
                    value1 = fmaxf(value1, 0.0f);
                }

                const uint32_t packed = pack_half2_bits(value0, value1);
                uint4 vec;
                vec.x = __shfl_sync(0xffffffff, packed, lane_group_base + 0);
                vec.y = __shfl_sync(0xffffffff, packed, lane_group_base + 1);
                vec.z = __shfl_sync(0xffffffff, packed, lane_group_base + 2);
                vec.w = __shfl_sync(0xffffffff, packed, lane_group_base + 3);

                if ((lane & 3) == 0 && route_m < expert_count) {
                    const int64_t output_idx =
                        (static_cast<int64_t>(expert_offset) + route_m) * OutDim
                        + col_base + j * kMmaN;
                    *reinterpret_cast<uint4*>(output + output_idx) = vec;
                }
            }
        }
    }
}

template <typename ScoreT>
__global__ void smoe_route_reduce_kernel(
    const c10::Half* __restrict__ y_route,
    const int32_t* __restrict__ route_pos,
    const ScoreT* __restrict__ topk_score,
    c10::Half* __restrict__ out,
    int64_t n_tokens
) {
    const int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const int64_t total = n_tokens * kHiddenDim;
    if (idx >= total) {
        return;
    }

    const int64_t token = idx / kHiddenDim;
    const int dim = static_cast<int>(idx - token * kHiddenDim);

    float value = 0.0f;
    const int32_t pos0 = route_pos[token * kTopK + 0];
    const int32_t pos1 = route_pos[token * kTopK + 1];
    if (pos0 >= 0) {
        value += static_cast<float>(topk_score[token * kTopK + 0])
            * static_cast<float>(y_route[static_cast<int64_t>(pos0) * kHiddenDim + dim]);
    }
    if (pos1 >= 0) {
        value += static_cast<float>(topk_score[token * kTopK + 1])
            * static_cast<float>(y_route[static_cast<int64_t>(pos1) * kHiddenDim + dim]);
    }
    out[idx] = static_cast<c10::Half>(value);
}

template <typename ScoreT>
__global__ void smoe_route_reduce_residual_kernel(
    const c10::Half* __restrict__ y_route,
    const int32_t* __restrict__ route_pos,
    const ScoreT* __restrict__ topk_score,
    const c10::Half* __restrict__ residual,
    c10::Half* __restrict__ out,
    int64_t n_tokens
) {
    const int64_t idx = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const int64_t total = n_tokens * kHiddenDim;
    if (idx >= total) {
        return;
    }

    const int64_t token = idx / kHiddenDim;
    const int dim = static_cast<int>(idx - token * kHiddenDim);

    float value = static_cast<float>(residual[idx]);
    const int32_t pos0 = route_pos[token * kTopK + 0];
    const int32_t pos1 = route_pos[token * kTopK + 1];
    if (pos0 >= 0) {
        value += static_cast<float>(topk_score[token * kTopK + 0])
            * static_cast<float>(y_route[static_cast<int64_t>(pos0) * kHiddenDim + dim]);
    }
    if (pos1 >= 0) {
        value += static_cast<float>(topk_score[token * kTopK + 1])
            * static_cast<float>(y_route[static_cast<int64_t>(pos1) * kHiddenDim + dim]);
    }
    out[idx] = static_cast<c10::Half>(value);
}

template <typename IndexT>
void launch_route_count(
    const torch::Tensor& topk_idx,
    torch::Tensor& counts,
    int64_t n_tokens
) {
    const int64_t total_routes = n_tokens * kTopK;
    if (total_routes == 0) {
        return;
    }

    constexpr int kCountThreads = 256;
    const int blocks = static_cast<int>(ceil_div_int64(total_routes, kCountThreads));
    smoe_route_count_kernel<IndexT>
        <<<blocks, kCountThreads, 0, at::cuda::getCurrentCUDAStream()>>>(
            topk_idx.data_ptr<IndexT>(),
            counts.data_ptr<int32_t>(),
            n_tokens
        );
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

template <typename IndexT, typename ScoreT>
void launch_route_pack(
    const torch::Tensor& x,
    const torch::Tensor& topk_idx,
    const torch::Tensor& topk_score,
    torch::Tensor& cursors,
    torch::Tensor& x_route,
    torch::Tensor& route_pos,
    torch::Tensor& route_token,
    torch::Tensor& route_slot,
    torch::Tensor& route_score,
    int64_t n_tokens
) {
    const int64_t total_routes = n_tokens * kTopK;
    if (total_routes == 0) {
        return;
    }

    smoe_route_pack_kernel<IndexT, ScoreT>
        <<<static_cast<unsigned int>(total_routes), kThreads, 0, at::cuda::getCurrentCUDAStream()>>>(
            x.data_ptr<c10::Half>(),
            topk_idx.data_ptr<IndexT>(),
            topk_score.data_ptr<ScoreT>(),
            cursors.data_ptr<int32_t>(),
            x_route.data_ptr<c10::Half>(),
            route_pos.data_ptr<int32_t>(),
            route_token.data_ptr<int32_t>(),
            route_slot.data_ptr<int32_t>(),
            route_score.data_ptr<ScoreT>(),
            n_tokens
        );
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

template <int InDim, int OutDim, bool ApplyRelu>
void launch_grouped_linear(
    const torch::Tensor& input,
    const torch::Tensor& weight,
    const torch::Tensor& bias,
    const torch::Tensor& counts,
    const torch::Tensor& offsets,
    torch::Tensor& output,
    int64_t max_routes_per_expert
) {
    if (max_routes_per_expert == 0 || input.size(0) == 0) {
        return;
    }

    const dim3 block(kThreads);
    const dim3 grid(
        static_cast<unsigned int>(OutDim / kBlockN),
        static_cast<unsigned int>(ceil_div_int64(max_routes_per_expert, kBlockM)),
        kNumExperts
    );

    smoe_grouped_linear_mma_tn_kernel<InDim, OutDim, ApplyRelu>
        <<<grid, block, 0, at::cuda::getCurrentCUDAStream()>>>(
            input.data_ptr<c10::Half>(),
            weight.data_ptr<c10::Half>(),
            bias.data_ptr<c10::Half>(),
            counts.data_ptr<int32_t>(),
            offsets.data_ptr<int32_t>(),
            output.data_ptr<c10::Half>()
        );
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

template <typename ScoreT>
void launch_route_reduce(
    const torch::Tensor& y_route,
    const torch::Tensor& route_pos,
    const torch::Tensor& topk_score,
    torch::Tensor& out,
    int64_t n_tokens
) {
    if (n_tokens == 0) {
        return;
    }

    constexpr int kReduceThreads = 256;
    const int64_t total = n_tokens * kHiddenDim;
    const int blocks = static_cast<int>(ceil_div_int64(total, kReduceThreads));
    smoe_route_reduce_kernel<ScoreT>
        <<<blocks, kReduceThreads, 0, at::cuda::getCurrentCUDAStream()>>>(
            y_route.data_ptr<c10::Half>(),
            route_pos.data_ptr<int32_t>(),
            topk_score.data_ptr<ScoreT>(),
            out.data_ptr<c10::Half>(),
            n_tokens
        );
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

template <typename ScoreT>
void launch_route_reduce_with_residual(
    const torch::Tensor& y_route,
    const torch::Tensor& route_pos,
    const torch::Tensor& topk_score,
    const torch::Tensor& residual,
    torch::Tensor& out,
    int64_t n_tokens
) {
    if (n_tokens == 0) {
        return;
    }

    constexpr int kReduceThreads = 256;
    const int64_t total = n_tokens * kHiddenDim;
    const int blocks = static_cast<int>(ceil_div_int64(total, kReduceThreads));
    smoe_route_reduce_residual_kernel<ScoreT>
        <<<blocks, kReduceThreads, 0, at::cuda::getCurrentCUDAStream()>>>(
            y_route.data_ptr<c10::Half>(),
            route_pos.data_ptr<int32_t>(),
            topk_score.data_ptr<ScoreT>(),
            residual.data_ptr<c10::Half>(),
            out.data_ptr<c10::Half>(),
            n_tokens
        );
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void validate_route_inputs(
    const torch::Tensor& x,
    const torch::Tensor& topk_idx,
    const torch::Tensor& topk_score
) {
    check_half_cuda_contiguous(x, "x");
    check_topk_idx(topk_idx, "topk_idx");
    check_topk_score(topk_score, "topk_score");
    check_same_device(x, topk_idx, "x", "topk_idx");
    check_same_device(x, topk_score, "x", "topk_score");
    TORCH_CHECK(x.dim() == 2 && x.size(1) == kHiddenDim, "x must have shape [N,512]");
    TORCH_CHECK(topk_idx.dim() == 2, "topk_idx must have shape [N,2]");
    TORCH_CHECK(topk_idx.size(0) == x.size(0), "topk_idx must have shape [N,2]");
    TORCH_CHECK(topk_idx.size(1) == kTopK, "topk_idx must have shape [N,2]");
    TORCH_CHECK(topk_score.dim() == 2, "topk_score must have shape [N,2]");
    TORCH_CHECK(topk_score.size(0) == x.size(0), "topk_score must have shape [N,2]");
    TORCH_CHECK(topk_score.size(1) == kTopK, "topk_score must have shape [N,2]");
    check_n_tokens(x.size(0));
}

void validate_fc1_inputs(
    const torch::Tensor& x_route,
    const torch::Tensor& w1,
    const torch::Tensor& b1,
    const torch::Tensor& counts,
    const torch::Tensor& offsets
) {
    check_half_cuda_contiguous(x_route, "x_route");
    check_half_cuda_contiguous(w1, "w1");
    check_half_cuda_contiguous(b1, "b1");
    check_i32_cuda_contiguous(counts, "counts");
    check_i32_cuda_contiguous(offsets, "offsets");
    check_same_device(x_route, w1, "x_route", "w1");
    check_same_device(x_route, b1, "x_route", "b1");
    check_same_device(x_route, counts, "x_route", "counts");
    check_same_device(x_route, offsets, "x_route", "offsets");
    TORCH_CHECK(x_route.dim() == 2 && x_route.size(1) == kHiddenDim,
        "x_route must have shape [pool,512]");
    TORCH_CHECK(w1.dim() == 3 && w1.size(0) == kNumExperts && w1.size(1) == kFfDim && w1.size(2) == kHiddenDim,
        "w1 must have shape [8,1024,512]");
    TORCH_CHECK(b1.dim() == 2 && b1.size(0) == kNumExperts && b1.size(1) == kFfDim,
        "b1 must have shape [8,1024]");
    TORCH_CHECK(counts.numel() == kNumExperts, "counts must have shape [8]");
    TORCH_CHECK(offsets.numel() == kNumExperts + 1, "offsets must have shape [9]");
}

void validate_fc2_inputs(
    const torch::Tensor& h_route,
    const torch::Tensor& w2,
    const torch::Tensor& b2,
    const torch::Tensor& counts,
    const torch::Tensor& offsets
) {
    check_half_cuda_contiguous(h_route, "h_route");
    check_half_cuda_contiguous(w2, "w2");
    check_half_cuda_contiguous(b2, "b2");
    check_i32_cuda_contiguous(counts, "counts");
    check_i32_cuda_contiguous(offsets, "offsets");
    check_same_device(h_route, w2, "h_route", "w2");
    check_same_device(h_route, b2, "h_route", "b2");
    check_same_device(h_route, counts, "h_route", "counts");
    check_same_device(h_route, offsets, "h_route", "offsets");
    TORCH_CHECK(h_route.dim() == 2 && h_route.size(1) == kFfDim,
        "h_route must have shape [pool,1024]");
    TORCH_CHECK(w2.dim() == 3 && w2.size(0) == kNumExperts && w2.size(1) == kHiddenDim && w2.size(2) == kFfDim,
        "w2 must have shape [8,512,1024]");
    TORCH_CHECK(b2.dim() == 2 && b2.size(0) == kNumExperts && b2.size(1) == kHiddenDim,
        "b2 must have shape [8,512]");
    TORCH_CHECK(counts.numel() == kNumExperts, "counts must have shape [8]");
    TORCH_CHECK(offsets.numel() == kNumExperts + 1, "offsets must have shape [9]");
}

RouteMetadata build_route_metadata(
    torch::Tensor x,
    torch::Tensor topk_idx,
    torch::Tensor topk_score
) {
    validate_route_inputs(x, topk_idx, topk_score);

    const int64_t n_tokens = x.size(0);
    const int64_t max_pool_routes = max_pool_routes_for_tokens(n_tokens);
    const int64_t max_routes_per_expert = n_tokens * kTopK;

    auto int_opts = x.options().dtype(torch::kInt32);
    auto counts = torch::empty({kNumExperts}, int_opts);
    auto cursors = torch::empty({kNumExperts}, int_opts);
    auto offsets = torch::empty({kNumExperts + 1}, int_opts);
    auto route_pos = torch::empty({n_tokens, kTopK}, int_opts);
    auto route_token = torch::empty({max_pool_routes}, int_opts);
    auto route_slot = torch::empty({max_pool_routes}, int_opts);
    auto x_route = torch::empty({max_pool_routes, kHiddenDim}, x.options());
    auto route_score = torch::empty({max_pool_routes}, topk_score.options());

    auto stream = at::cuda::getCurrentCUDAStream();
    C10_CUDA_CHECK(cudaMemsetAsync(counts.data_ptr<int32_t>(), 0, counts.numel() * sizeof(int32_t), stream.stream()));
    C10_CUDA_CHECK(cudaMemsetAsync(route_pos.data_ptr<int32_t>(), 0xff, route_pos.numel() * sizeof(int32_t), stream.stream()));

    if (n_tokens == 0) {
        C10_CUDA_CHECK(cudaMemsetAsync(offsets.data_ptr<int32_t>(), 0, offsets.numel() * sizeof(int32_t), stream.stream()));
        return {x_route, route_pos, route_token, route_slot, route_score, counts, offsets, max_routes_per_expert};
    }

    if (topk_idx.scalar_type() == at::kLong) {
        launch_route_count<int64_t>(topk_idx, counts, n_tokens);
    } else {
        launch_route_count<int32_t>(topk_idx, counts, n_tokens);
    }

    smoe_route_prefix_kernel<<<1, 1, 0, stream>>>(
        counts.data_ptr<int32_t>(),
        offsets.data_ptr<int32_t>(),
        cursors.data_ptr<int32_t>()
    );
    C10_CUDA_KERNEL_LAUNCH_CHECK();

    if (topk_idx.scalar_type() == at::kLong && topk_score.scalar_type() == at::kHalf) {
        launch_route_pack<int64_t, c10::Half>(
            x, topk_idx, topk_score, cursors, x_route, route_pos,
            route_token, route_slot, route_score, n_tokens);
    } else if (topk_idx.scalar_type() == at::kLong && topk_score.scalar_type() == at::kFloat) {
        launch_route_pack<int64_t, float>(
            x, topk_idx, topk_score, cursors, x_route, route_pos,
            route_token, route_slot, route_score, n_tokens);
    } else if (topk_idx.scalar_type() == at::kInt && topk_score.scalar_type() == at::kHalf) {
        launch_route_pack<int32_t, c10::Half>(
            x, topk_idx, topk_score, cursors, x_route, route_pos,
            route_token, route_slot, route_score, n_tokens);
    } else {
        launch_route_pack<int32_t, float>(
            x, topk_idx, topk_score, cursors, x_route, route_pos,
            route_token, route_slot, route_score, n_tokens);
    }

    return {x_route, route_pos, route_token, route_slot, route_score, counts, offsets, max_routes_per_expert};
}

}  // namespace

torch::Tensor smoe_route_count(torch::Tensor topk_idx) {
    check_topk_idx(topk_idx, "topk_idx");
    TORCH_CHECK(topk_idx.dim() == 2 && topk_idx.size(1) == kTopK, "topk_idx must have shape [N,2]");
    const int64_t n_tokens = topk_idx.size(0);
    check_n_tokens(n_tokens);

    auto counts = torch::empty({kNumExperts}, topk_idx.options().dtype(torch::kInt32));
    C10_CUDA_CHECK(cudaMemsetAsync(
        counts.data_ptr<int32_t>(),
        0,
        counts.numel() * sizeof(int32_t),
        at::cuda::getCurrentCUDAStream().stream()
    ));

    if (topk_idx.scalar_type() == at::kLong) {
        launch_route_count<int64_t>(topk_idx, counts, n_tokens);
    } else {
        launch_route_count<int32_t>(topk_idx, counts, n_tokens);
    }
    return counts;
}

std::vector<torch::Tensor> smoe_route_pack(
    torch::Tensor x,
    torch::Tensor topk_idx,
    torch::Tensor topk_score
) {
    auto meta = build_route_metadata(x, topk_idx, topk_score);
    return {
        meta.x_route,
        meta.route_pos,
        meta.route_token,
        meta.route_slot,
        meta.route_score,
        meta.counts,
        meta.offsets,
    };
}

torch::Tensor smoe_grouped_fc1_relu(
    torch::Tensor x_route,
    torch::Tensor w1,
    torch::Tensor b1,
    torch::Tensor counts,
    torch::Tensor offsets,
    int64_t max_routes_per_expert
) {
    validate_fc1_inputs(x_route, w1, b1, counts, offsets);
    TORCH_CHECK(max_routes_per_expert >= 0, "max_routes_per_expert must be non-negative");
    TORCH_CHECK(ceil_div_int64(max_routes_per_expert, kBlockM) <= 65535,
        "max_routes_per_expert creates too many CTA rows");

    auto h_route = torch::empty({x_route.size(0), kFfDim}, x_route.options());
    launch_grouped_linear<kHiddenDim, kFfDim, true>(
        x_route,
        w1,
        b1,
        counts,
        offsets,
        h_route,
        max_routes_per_expert
    );
    return h_route;
}

torch::Tensor smoe_grouped_fc2(
    torch::Tensor h_route,
    torch::Tensor w2,
    torch::Tensor b2,
    torch::Tensor counts,
    torch::Tensor offsets,
    int64_t max_routes_per_expert
) {
    validate_fc2_inputs(h_route, w2, b2, counts, offsets);
    TORCH_CHECK(max_routes_per_expert >= 0, "max_routes_per_expert must be non-negative");
    TORCH_CHECK(ceil_div_int64(max_routes_per_expert, kBlockM) <= 65535,
        "max_routes_per_expert creates too many CTA rows");

    auto y_route = torch::empty({h_route.size(0), kHiddenDim}, h_route.options());
    launch_grouped_linear<kFfDim, kHiddenDim, false>(
        h_route,
        w2,
        b2,
        counts,
        offsets,
        y_route,
        max_routes_per_expert
    );
    return y_route;
}

torch::Tensor smoe_route_reduce(
    torch::Tensor y_route,
    torch::Tensor route_pos,
    torch::Tensor topk_score
) {
    check_half_cuda_contiguous(y_route, "y_route");
    check_i32_cuda_contiguous(route_pos, "route_pos");
    check_topk_score(topk_score, "topk_score");
    check_same_device(y_route, route_pos, "y_route", "route_pos");
    check_same_device(y_route, topk_score, "y_route", "topk_score");
    TORCH_CHECK(y_route.dim() == 2 && y_route.size(1) == kHiddenDim,
        "y_route must have shape [pool,512]");
    TORCH_CHECK(route_pos.dim() == 2 && route_pos.size(1) == kTopK,
        "route_pos must have shape [N,2]");
    TORCH_CHECK(topk_score.dim() == 2 && topk_score.size(0) == route_pos.size(0) && topk_score.size(1) == kTopK,
        "topk_score must have shape [N,2]");

    const int64_t n_tokens = route_pos.size(0);
    check_n_tokens(n_tokens);
    auto out = torch::empty({n_tokens, kHiddenDim}, y_route.options());
    if (n_tokens == 0) {
        return out;
    }

    if (topk_score.scalar_type() == at::kHalf) {
        launch_route_reduce<c10::Half>(y_route, route_pos, topk_score, out, n_tokens);
    } else {
        launch_route_reduce<float>(y_route, route_pos, topk_score, out, n_tokens);
    }
    return out;
}

torch::Tensor smoe_route_reduce_with_residual(
    torch::Tensor y_route,
    torch::Tensor route_pos,
    torch::Tensor topk_score,
    torch::Tensor residual
) {
    check_half_cuda_contiguous(y_route, "y_route");
    check_i32_cuda_contiguous(route_pos, "route_pos");
    check_topk_score(topk_score, "topk_score");
    check_half_cuda_contiguous(residual, "residual");
    check_same_device(y_route, route_pos, "y_route", "route_pos");
    check_same_device(y_route, topk_score, "y_route", "topk_score");
    check_same_device(y_route, residual, "y_route", "residual");
    TORCH_CHECK(y_route.dim() == 2 && y_route.size(1) == kHiddenDim,
        "y_route must have shape [pool,512]");
    TORCH_CHECK(route_pos.dim() == 2 && route_pos.size(1) == kTopK,
        "route_pos must have shape [N,2]");
    TORCH_CHECK(topk_score.dim() == 2 && topk_score.size(0) == route_pos.size(0) && topk_score.size(1) == kTopK,
        "topk_score must have shape [N,2]");

    const int64_t n_tokens = route_pos.size(0);
    check_n_tokens(n_tokens);
    TORCH_CHECK(residual.dim() == 2 && residual.size(0) == n_tokens && residual.size(1) == kHiddenDim,
        "residual must have shape [N,512]");

    auto out = torch::empty({n_tokens, kHiddenDim}, y_route.options());
    if (n_tokens == 0) {
        return out;
    }

    if (topk_score.scalar_type() == at::kHalf) {
        launch_route_reduce_with_residual<c10::Half>(y_route, route_pos, topk_score, residual, out, n_tokens);
    } else {
        launch_route_reduce_with_residual<float>(y_route, route_pos, topk_score, residual, out, n_tokens);
    }
    return out;
}

torch::Tensor smoe_forward(
    torch::Tensor x,
    torch::Tensor w1,
    torch::Tensor b1,
    torch::Tensor w2,
    torch::Tensor b2,
    torch::Tensor topk_idx,
    torch::Tensor topk_score
) {
    auto meta = build_route_metadata(x, topk_idx, topk_score);

    validate_fc1_inputs(meta.x_route, w1, b1, meta.counts, meta.offsets);

    auto h_route = torch::empty({meta.x_route.size(0), kFfDim}, x.options());
    validate_fc2_inputs(h_route, w2, b2, meta.counts, meta.offsets);

    auto y_route = torch::empty({meta.x_route.size(0), kHiddenDim}, x.options());
    auto out = torch::empty({x.size(0), kHiddenDim}, x.options());

    launch_grouped_linear<kHiddenDim, kFfDim, true>(
        meta.x_route,
        w1,
        b1,
        meta.counts,
        meta.offsets,
        h_route,
        meta.max_routes_per_expert
    );
    launch_grouped_linear<kFfDim, kHiddenDim, false>(
        h_route,
        w2,
        b2,
        meta.counts,
        meta.offsets,
        y_route,
        meta.max_routes_per_expert
    );

    if (x.size(0) == 0) {
        return out;
    }
    if (topk_score.scalar_type() == at::kHalf) {
        launch_route_reduce<c10::Half>(y_route, meta.route_pos, topk_score, out, x.size(0));
    } else {
        launch_route_reduce<float>(y_route, meta.route_pos, topk_score, out, x.size(0));
    }
    return out;
}

torch::Tensor smoe_forward_with_residual(
    torch::Tensor x,
    torch::Tensor residual,
    torch::Tensor w1,
    torch::Tensor b1,
    torch::Tensor w2,
    torch::Tensor b2,
    torch::Tensor topk_idx,
    torch::Tensor topk_score
) {
    check_half_cuda_contiguous(residual, "residual");
    check_same_device(x, residual, "x", "residual");
    TORCH_CHECK(residual.dim() == 2 && residual.size(0) == x.size(0) && residual.size(1) == kHiddenDim,
        "residual must have shape [N,512]");

    auto meta = build_route_metadata(x, topk_idx, topk_score);

    validate_fc1_inputs(meta.x_route, w1, b1, meta.counts, meta.offsets);

    auto h_route = torch::empty({meta.x_route.size(0), kFfDim}, x.options());
    validate_fc2_inputs(h_route, w2, b2, meta.counts, meta.offsets);

    auto y_route = torch::empty({meta.x_route.size(0), kHiddenDim}, x.options());
    auto out = torch::empty({x.size(0), kHiddenDim}, x.options());

    launch_grouped_linear<kHiddenDim, kFfDim, true>(
        meta.x_route,
        w1,
        b1,
        meta.counts,
        meta.offsets,
        h_route,
        meta.max_routes_per_expert
    );
    launch_grouped_linear<kFfDim, kHiddenDim, false>(
        h_route,
        w2,
        b2,
        meta.counts,
        meta.offsets,
        y_route,
        meta.max_routes_per_expert
    );

    if (x.size(0) == 0) {
        return out;
    }
    if (topk_score.scalar_type() == at::kHalf) {
        launch_route_reduce_with_residual<c10::Half>(
            y_route, meta.route_pos, topk_score, residual, out, x.size(0));
    } else {
        launch_route_reduce_with_residual<float>(
            y_route, meta.route_pos, topk_score, residual, out, x.size(0));
    }
    return out;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("smoe_route_count", &smoe_route_count, "Routed SMoE route count");
    m.def("smoe_route_pack", &smoe_route_pack, "Routed SMoE route pack");
    m.def("smoe_grouped_fc1_relu", &smoe_grouped_fc1_relu, "Routed SMoE grouped fc1 + bias + ReLU");
    m.def("smoe_grouped_fc2", &smoe_grouped_fc2, "Routed SMoE grouped fc2 + bias");
    m.def("smoe_route_reduce", &smoe_route_reduce, "Routed SMoE explicit top-2 reduce");
    m.def("smoe_route_reduce_with_residual", &smoe_route_reduce_with_residual,
        "Routed SMoE explicit top-2 reduce fused with residual add");
    m.def("smoe_forward", &smoe_forward, "Routed sparse SMoE forward");
    m.def("smoe_forward_with_residual", &smoe_forward_with_residual,
        "Routed sparse SMoE forward fused with residual add");
}

import math
import argparse
import builtins
import importlib
import os
import sys
from pathlib import Path
from collections import defaultdict


_STDOUT_PRINT = builtins.print
PRINT_LOGS = os.environ.get("CTI_PRINT", "0").lower() in {"1", "true", "yes", "on"}


def print(*args, **kwargs):
    if PRINT_LOGS or sys._getframe(1).f_code.co_name == "main":
        _STDOUT_PRINT(*args, **kwargs)


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_LIBRARIES = (SCRIPT_DIR / "libraries").resolve()
PARENT_LIBRARIES = (SCRIPT_DIR.parent / "libraries").resolve()
TORCH_EXTENSIONS_DIR = (SCRIPT_DIR / ".torch_extensions").resolve()
CMAKE_EXTENSIONS_DIR = (SCRIPT_DIR / "cmake_extensions").resolve()


def _env_positive_int(name, default):
    value = os.environ.get(name, str(default))
    try:
        parsed = int(value)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer, got {value!r}") from exc
    if parsed <= 0:
        raise RuntimeError(f"{name} must be positive, got {parsed}")
    return parsed


def _env_positive_float(name, default):
    value = os.environ.get(name, str(default))
    try:
        parsed = float(value)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be a float, got {value!r}") from exc
    if parsed <= 0.0:
        raise RuntimeError(f"{name} must be positive, got {parsed}")
    return parsed


USE_CUSTOM_CUDA_NORM = os.environ.get("USE_CUSTOM_CUDA_NORM", "1") != "0"
CHECK_CUSTOM_CUDA_NORM = os.environ.get("CHECK_CUSTOM_CUDA_NORM", "0") == "1"
USE_CUSTOM_CUDA_REP_NORM = os.environ.get("USE_CUSTOM_CUDA_REP_NORM", "1") != "0"
USE_REP_LAYERNORM_14336_VEC8 = os.environ.get("USE_REP_LAYERNORM_14336_VEC8", "1") != "0"
USE_CUSTOM_CUDA_ATTENTION = os.environ.get("USE_CUSTOM_CUDA_ATTENTION", "1") != "0"
USE_INTERLEAVED_QKV_ATTENTION = os.environ.get("USE_INTERLEAVED_QKV_ATTENTION", "1") != "0"
USE_INTERLEAVED_QKV_ATTENTION_TOKEN_MAJOR_OUT = os.environ.get("USE_INTERLEAVED_QKV_ATTENTION_TOKEN_MAJOR_OUT", "1") != "0"
USE_M64_SMOE = os.environ.get("USE_M64_SMOE", "0") != "0"
USE_CUTLASS_SMOE = os.environ.get("USE_CUTLASS_SMOE", "0") != "0"
USE_SIMPLE_W4A4_SMOE = os.environ.get("USE_SIMPLE_W4A4_SMOE", "1") != "0"
USE_SIMPLE_W4A4_FC1_SMOE = os.environ.get("USE_SIMPLE_W4A4_FC1_SMOE", "0") != "0"
USE_W4A16_SMOE = os.environ.get("USE_W4A16_SMOE", "0") != "0"
USE_CUDA_W4A16_SMOE = os.environ.get("USE_CUDA_W4A16_SMOE", "1") != "0"
USE_FRAG_DEQUANT_W4A16_SMOE = os.environ.get("USE_FRAG_DEQUANT_W4A16_SMOE", "0") != "0"
USE_LOP3_DEQUANT_W4A16_SMOE = os.environ.get("USE_LOP3_DEQUANT_W4A16_SMOE", "0") != "0"
USE_SIMT_FC2_W4A16_SMOE = os.environ.get("USE_SIMT_FC2_W4A16_SMOE", "0") != "0"
USE_HALF_SCALE_W4A16_SMOE = os.environ.get("USE_HALF_SCALE_W4A16_SMOE", "1") != "0"
REQUIRE_CUDA_W4A16_SMOE = os.environ.get("REQUIRE_CUDA_W4A16_SMOE", "1") == "1"
CHECK_W4A16_SMOE = os.environ.get("CHECK_W4A16_SMOE", "0") == "1"
PROFILE_INFERENCE_RANGE = os.environ.get("PROFILE_INFERENCE_RANGE", "0") == "1"
USE_CUDA_GRAPH_INFER = os.environ.get("USE_CUDA_GRAPH_INFER", "0") != "0"
CUDA_GRAPH_TOKEN_BUCKET = _env_positive_int("CUDA_GRAPH_TOKEN_BUCKET", 128)
CUDA_GRAPH_WARMUP_ITERS = _env_positive_int("CUDA_GRAPH_WARMUP_ITERS", 1)
CUDA_GRAPH_MAIN_BATCH_FASTPATH = False
ATTENTION_MMA_BR = 16
W4A16_GROUP_SIZE = _env_positive_int("W4A16_GROUP_SIZE", 128)
SIMPLE_W4A4_ACT_SCALE = _env_positive_float("SIMPLE_W4A4_ACT_SCALE", 1.0)
SIMPLE_W4A4_FC1_ACT_SCALE = _env_positive_float("SIMPLE_W4A4_FC1_ACT_SCALE", SIMPLE_W4A4_ACT_SCALE)
SIMPLE_W4A4_WEIGHT_SCALE = float(os.environ.get("SIMPLE_W4A4_WEIGHT_SCALE", "0"))
if SIMPLE_W4A4_WEIGHT_SCALE < 0.0:
    raise RuntimeError(f"SIMPLE_W4A4_WEIGHT_SCALE must be non-negative, got {SIMPLE_W4A4_WEIGHT_SCALE}")
SIMPLE_W4A4_FC1_OUTPUT_SCALE = _env_positive_float("SIMPLE_W4A4_FC1_OUTPUT_SCALE", 1.0)
SIMPLE_W4A4_FC2_OUTPUT_SCALE = _env_positive_float("SIMPLE_W4A4_FC2_OUTPUT_SCALE", 1.1)
if USE_SIMPLE_W4A4_FC1_SMOE and not USE_SIMPLE_W4A4_SMOE:
    raise RuntimeError("USE_SIMPLE_W4A4_FC1_SMOE=1 requires USE_SIMPLE_W4A4_SMOE=1")

if PROJECT_LIBRARIES.exists():
    sys.path.insert(0, str(PROJECT_LIBRARIES))
if PARENT_LIBRARIES.exists():
    sys.path.insert(0, str(PARENT_LIBRARIES))
if CMAKE_EXTENSIONS_DIR.exists():
    sys.path.insert(0, str(CMAKE_EXTENSIONS_DIR))

os.environ.setdefault("TORCH_EXTENSIONS_DIR", str(TORCH_EXTENSIONS_DIR))

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm


_LAYER_NORM_EXT = None
_ATTENTION_EXT = None
_ATTENTION_KERNEL = None
_INTERLEAVED_ATTENTION_KERNEL = None
_ROUTED_SMOE_EXT = None
_EMBEDDING_BAG_EXT = None
_GATE_TOPK_EXT = None
_OUTPUT_EXT = None


def _load_prebuilt_cuda_ext(name):
    if os.environ.get("USE_PREBUILT_CUDA_EXT", "1") == "0":
        raise RuntimeError("USE_PREBUILT_CUDA_EXT=0 is no longer supported; run build_env.sh first")
    if CMAKE_EXTENSIONS_DIR.exists():
        path = str(CMAKE_EXTENSIONS_DIR)
        if path not in sys.path:
            sys.path.insert(0, path)
    try:
        return importlib.import_module(name)
    except ImportError as exc:
        raise RuntimeError(
            f"prebuilt CUDA extension {name!r} was not importable from {CMAKE_EXTENSIONS_DIR}; "
            "run build_env.sh before infer.py"
        ) from exc


def _get_layernorm_ext():
    global _LAYER_NORM_EXT
    if _LAYER_NORM_EXT is not None:
        return _LAYER_NORM_EXT

    _LAYER_NORM_EXT = _load_prebuilt_cuda_ext("layernorm_512_ext")
    return _LAYER_NORM_EXT


def _get_attention_ext():
    global _ATTENTION_EXT
    if _ATTENTION_EXT is not None:
        return _ATTENTION_EXT

    _ATTENTION_EXT = _load_prebuilt_cuda_ext("varlen_attention_ext")
    return _ATTENTION_EXT


def _get_routed_smoe_ext():
    global _ROUTED_SMOE_EXT
    if _ROUTED_SMOE_EXT is not None:
        return _ROUTED_SMOE_EXT

    _ROUTED_SMOE_EXT = _load_prebuilt_cuda_ext("routed_smoe_ext")
    return _ROUTED_SMOE_EXT


def _get_embedding_bag_ext():
    global _EMBEDDING_BAG_EXT
    if _EMBEDDING_BAG_EXT is not None:
        return _EMBEDDING_BAG_EXT

    _EMBEDDING_BAG_EXT = _load_prebuilt_cuda_ext("embedding_bag_ext")
    return _EMBEDDING_BAG_EXT


def _get_gate_topk_ext():
    global _GATE_TOPK_EXT
    if _GATE_TOPK_EXT is not None:
        return _GATE_TOPK_EXT

    _GATE_TOPK_EXT = _load_prebuilt_cuda_ext("gate_topk_ext")
    return _GATE_TOPK_EXT


def _get_output_ext():
    global _OUTPUT_EXT
    if _OUTPUT_EXT is not None:
        return _OUTPUT_EXT

    _OUTPUT_EXT = _load_prebuilt_cuda_ext("output_ext")
    return _OUTPUT_EXT


def _get_attention_kernel():
    global _ATTENTION_KERNEL
    if _ATTENTION_KERNEL is not None:
        return _ATTENTION_KERNEL

    ext = _get_attention_ext()
    if not hasattr(ext, "varlen_causal_attention_mma_qk_pv_padded_shared_kv_meta"):
        raise RuntimeError("custom CUDA attention extension is missing shared-kv tile-meta kernel")
    _ATTENTION_KERNEL = (
        ext.varlen_causal_attention_mma_qk_pv_padded_shared_kv_meta,
        "mma-qk-pv-padded-shared-kv-meta",
    )
    return _ATTENTION_KERNEL


def _get_interleaved_attention_kernel():
    global _INTERLEAVED_ATTENTION_KERNEL
    if _INTERLEAVED_ATTENTION_KERNEL is not None:
        return _INTERLEAVED_ATTENTION_KERNEL

    ext = _get_attention_ext()
    kernel_name = "varlen_causal_attention_qkv_interleaved_mma_qk_pv_padded_shared_kv_meta"
    if not hasattr(ext, kernel_name):
        raise RuntimeError("custom CUDA attention extension is missing interleaved-qkv tile-meta kernel")
    out_layout = "token-major-out" if USE_INTERLEAVED_QKV_ATTENTION_TOKEN_MAJOR_OUT else "head-major-out"
    _INTERLEAVED_ATTENTION_KERNEL = (
        getattr(ext, kernel_name),
        f"interleaved-qkv-mma-qk-pv-padded-shared-kv-meta-{out_layout}",
    )
    return _INTERLEAVED_ATTENTION_KERNEL


# ============================================================
# 数据加载（来自 train/dataset.py）
# ============================================================

def _detect_has_clk(file_path):
    """检测 CSV 文件是否包含 clk 列（5列 vs 4列格式）。
    5列格式: logid,userid,adid,clk,timestamp,sign:slot...
    4列格式: logid,userid,adid,timestamp,sign:slot...
    通过第5个字段是否包含 ':' 来判断：有 ':' 说明已经是 sign:slot，即无 clk 列。
    """
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(',')
            if len(parts) >= 5:
                return ':' not in parts[4]
            return False
    return False


def load_sample_files(sample_files_list):
    """加载 CSV sample 文件，返回 item_dict 和 user_seq。
    自动检测每个文件是 5列（含clk）还是 4列（无clk）格式。
    """
    sample_files = sorted([Path(f) for f in sample_files_list])
    print(f'[INFO] loading {len(sample_files)} files: {[str(f) for f in sample_files]}')

    item_dict = {}
    user_logs = defaultdict(list)

    for sample_file in tqdm(sample_files, desc='Loading sample files'):
        has_clk = _detect_has_clk(sample_file)
        min_parts = 5 if has_clk else 4
        print(f'  {sample_file.name}: has_clk={has_clk}')

        with open(sample_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split(',')
                if len(parts) < min_parts:
                    continue

                logid = int(parts[0])
                userid = int(parts[1])
                adid = int(parts[2])

                if has_clk:
                    clk = int(parts[3])
                    timestamp = int(parts[4])
                    feat_start = 5
                else:
                    clk = 0
                    timestamp = int(parts[3])
                    feat_start = 4

                signs = []
                slots = []
                for pair in parts[feat_start:]:
                    if ':' in pair:
                        s, sl = pair.split(':', 1)
                        signs.append(int(s))
                        slots.append(int(sl))

                item_dict[logid] = {
                    'logid': logid,
                    'userid': userid,
                    'adid': adid,
                    'clk': clk,
                    'timestamp': timestamp,
                    'signs': np.array(signs, dtype=np.int64),
                    'slots': np.array(slots, dtype=np.int64),
                }
                user_logs[userid].append((timestamp, logid))

    user_seq = {}
    for userid, logs in user_logs.items():
        logs.sort(key=lambda x: x[0])
        user_seq[userid] = [logid for _, logid in logs]

    print(f'[INFO] loaded {len(item_dict)} records, {len(user_seq)} users')
    return item_dict, user_seq


def load_logids_from_file(file_path):
    """快速读取一个 sample 文件中的所有 logid"""
    logids = set()
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            comma = line.index(',')
            logids.add(int(line[:comma]))
    return logids


class CTRUserDataset(Dataset):
    """按用户组织的 CTR 数据集"""

    def __init__(self, item_dict, user_seq=None, max_feasign_per_slot=None, pred_logids=None):
        super().__init__()
        self.item_dict = item_dict
        self.user_seq = user_seq if user_seq else {}
        self.max_feasign_per_slot = max_feasign_per_slot
        self.pred_logids = pred_logids if pred_logids is not None else set()

        self.user_items = defaultdict(list)
        for logid, rec in item_dict.items():
            userid = rec['userid']
            feasign = defaultdict(list)
            for slot, sign in zip(rec['slots'].tolist(), rec['signs'].tolist()):
                feasign[slot].append(sign)
            if max_feasign_per_slot is not None:
                feasign = {slot: signs[:max_feasign_per_slot[slot]]
                           if max_feasign_per_slot.get(slot, -1) != -1 else signs
                           for slot, signs in feasign.items()}
            feasign = dict(feasign)
            label = rec['clk']
            self.user_items[userid].append((logid, feasign, label))

        self.user_ids = sorted(self.user_items.keys())
        self.num_users = len(self.user_ids)
        self.total_samples = len(item_dict)

        all_signs = set()
        for rec in item_dict.values():
            all_signs.update(rec['signs'].tolist())
        self.max_slot_id = 28
        self.max_sign_id = max(all_signs) if all_signs else 0

    def __len__(self):
        return self.num_users

    def __getitem__(self, index):
        userid = self.user_ids[index]
        items = self.user_items[userid]

        if self.user_seq and userid in self.user_seq:
            seq_order = {logid: i for i, logid in enumerate(self.user_seq[userid])}
            items.sort(key=lambda x: seq_order.get(x[0], x[0]))
        else:
            items.sort(key=lambda x: x[0])

        feasigns = []
        labels = []
        logids = []
        for logid, feasign, label in items:
            logids.append(logid)
            feasigns.append(feasign)
            labels.append(label)

        return {
            'userid': userid,
            'logids': logids,
            'feasigns': feasigns,
            'labels': labels,
            'pred_mask': [1 if logid in self.pred_logids else 0 for logid in logids],
        }


class CTRTestSeqDataset(CTRUserDataset):
    """Evaluation-compatible dataset wrapper.

    The evaluator constructs this class by name. Reuse CTRUserDataset while
    deriving the prediction mask from the ordered test logids.
    """

    def __init__(
        self,
        test_logids_ordered,
        item_dict,
        user_seq,
        max_feasign_per_slot=None,
        max_ctx_len=None,
    ):
        self.test_logids_ordered = list(test_logids_ordered)
        self.max_ctx_len = max_ctx_len
        super().__init__(
            item_dict=item_dict,
            user_seq=user_seq,
            max_feasign_per_slot=max_feasign_per_slot,
            pred_logids=set(self.test_logids_ordered),
        )


def make_attention_tile_meta(user_offsets, br=ATTENTION_MMA_BR):
    if torch.is_tensor(user_offsets):
        offsets = user_offsets.detach().cpu().tolist()
        device = user_offsets.device
    else:
        offsets = list(user_offsets)
        device = None

    meta = []
    for start, end in zip(offsets[:-1], offsets[1:]):
        start = int(start)
        end = int(end)
        for tile_start in range(start, end, br):
            tile_len = min(end - tile_start, br)
            meta.append((start, end, tile_start, tile_len))
    meta.reverse()
    if not meta:
        return torch.empty((0, 4), dtype=torch.int32, device=device)
    return torch.tensor(meta, dtype=torch.int32, device=device)


def ensure_attention_tile_meta(batch):
    changed = False
    if (
        isinstance(batch, dict)
        and "user_offsets" in batch
        and "attention_tile_meta_mma" not in batch
    ):
        batch["attention_tile_meta_mma"] = make_attention_tile_meta(batch["user_offsets"], br=ATTENTION_MMA_BR)
        changed = True
    return changed


def ensure_pred_positions(batch):
    if (
        isinstance(batch, dict)
        and "pred_mask" in batch
        and "pred_positions" not in batch
    ):
        pred_mask = batch["pred_mask"].view(-1).bool()
        batch["pred_positions"] = pred_mask.nonzero(as_tuple=False).view(-1).to(torch.long)
        return True
    return False


def pin_batch_memory(batch):
    if isinstance(batch, dict):
        return {k: pin_batch_memory(v) for k, v in batch.items()}
    if isinstance(batch, tuple):
        return tuple(pin_batch_memory(x) for x in batch)
    if isinstance(batch, list):
        return [pin_batch_memory(x) for x in batch]
    if torch.is_tensor(batch):
        if batch.is_cuda or batch.is_pinned():
            return batch
        return batch.pin_memory()
    return batch


def pin_all_batches_memory(all_batches):
    if not torch.cuda.is_available():
        return all_batches, False

    print("[INFO] pinning CPU batch tensors for non_blocking H2D copies")
    try:
        return [
            pin_batch_memory(batch)
            for batch in tqdm(all_batches, desc="Pin CPU batches")
        ], True
    except RuntimeError as exc:
        raise RuntimeError(f"pin_memory failed; optimized inference requires pinned CPU batches: {exc}") from exc


def make_collate_fn(max_slot_id):
    def collate_user_batch(batch):
        all_userids = []
        all_logids = []
        all_labels = []
        all_pred_masks = []
        all_feasigns = []
        user_offsets = [0]

        for item in batch:
            for i, logid in enumerate(item['logids']):
                all_userids.append(item['userid'])
                all_logids.append(logid)
                all_labels.append(item['labels'][i])
                all_pred_masks.append(item['pred_mask'][i])
                all_feasigns.append(item['feasigns'][i])
            user_offsets.append(len(all_labels))

        slot_data = {}
        for slot in range(1, max_slot_id + 1):
            values = []
            offsets = [0]
            for feasign in all_feasigns:
                if slot in feasign:
                    values.extend(feasign[slot])
                offsets.append(len(values))
            slot_data[slot] = (
                torch.tensor(values, dtype=torch.long),
                torch.tensor(offsets, dtype=torch.long),
            )

        user_offsets_tensor = torch.tensor(user_offsets, dtype=torch.long)
        pred_mask_tensor = torch.tensor(all_pred_masks, dtype=torch.bool)
        result = {
            'userid': torch.tensor(all_userids, dtype=torch.long),
            'logid': torch.tensor(all_logids, dtype=torch.long),
            'label': torch.tensor(all_labels, dtype=torch.float32),
            'pred_mask': pred_mask_tensor,
            'pred_positions': pred_mask_tensor.nonzero(as_tuple=False).view(-1).to(torch.long),
            'user_offsets': user_offsets_tensor,
            'attention_tile_meta_mma': make_attention_tile_meta(user_offsets_tensor, br=ATTENTION_MMA_BR),
        }
        result.update(slot_data)
        return result

    return collate_user_batch


# ============================================================
# 模型定义（来自 main.py）
# ============================================================

def move_batch_to_device(batch, device):
    dev = torch.device(device)
    if isinstance(batch, dict):
        ensure_attention_tile_meta(batch)
        ensure_pred_positions(batch)
        if CUDA_GRAPH_MAIN_BATCH_FASTPATH and dev.type == "cuda":
            pred_positions = batch["pred_positions"].view(-1).to(torch.long)
            moved = dict(batch)
            moved["_graph_n_original_rows"] = int(batch["logid"].numel())
            moved["_graph_pred_positions"] = pred_positions.to(dev, non_blocking=True)
            moved["logid"] = batch["logid"].index_select(0, pred_positions).to(dev, non_blocking=True)
            moved["pred_mask"] = torch.ones((pred_positions.numel(),), device=dev, dtype=torch.bool)
            return moved
        return {k: move_batch_to_device(v, device) for k, v in batch.items()}
    elif isinstance(batch, tuple):
        return tuple(move_batch_to_device(x, device) for x in batch)
    elif isinstance(batch, list):
        return [move_batch_to_device(x, device) for x in batch]
    elif torch.is_tensor(batch):
        return batch.to(dev, non_blocking=(dev.type == "cuda"))
    else:
        return batch


def record_batch_stream(batch, stream):
    if isinstance(batch, dict):
        for value in batch.values():
            record_batch_stream(value, stream)
    elif isinstance(batch, (list, tuple)):
        for value in batch:
            record_batch_stream(value, stream)
    elif torch.is_tensor(batch) and batch.is_cuda:
        batch.record_stream(stream)


def prefetch_batch_to_device(batch, device, copy_stream):
    with torch.cuda.stream(copy_stream):
        return move_batch_to_device(batch, device)


def start_inference_profile_range(device):
    dev = torch.device(device)
    if not PROFILE_INFERENCE_RANGE or dev.type != "cuda":
        return False

    torch.cuda.synchronize(dev)
    print("[INFO] starting CUDA profiler capture range: inference")
    torch.cuda.profiler.start()
    torch.cuda.nvtx.range_push("inference")
    return True


def stop_inference_profile_range(device, active):
    if not active:
        return

    dev = torch.device(device)
    torch.cuda.synchronize(dev)
    torch.cuda.nvtx.range_pop()
    torch.cuda.profiler.stop()
    print("[INFO] stopped CUDA profiler capture range: inference")


def predict_batch_via_forward(model, batch):
    logits, _ = model(batch)
    logits = logits.squeeze(-1)
    probs = torch.sigmoid(logits.float())
    pred_mask = batch["pred_mask"].bool()
    return batch["logid"][pred_mask], probs[pred_mask]


class RepEncoder(nn.Module):
    def __init__(self, vocab_size, emb_dim, padding_idx=0, slot_num=0, d_model=0):
        super().__init__()
        self.emb = nn.Embedding(num_embeddings=vocab_size, embedding_dim=emb_dim, padding_idx=padding_idx)
        self.emb_dim = emb_dim
        self.slot_num = slot_num
        self.input_norm = nn.LayerNorm(slot_num * emb_dim)
        self.linear = nn.Linear(in_features=slot_num * emb_dim, out_features=d_model)

    def forward(self, batch):
        if not (
            self.emb.weight.is_cuda
            and self.emb.weight.dtype == torch.float16
            and self.emb_dim == 512
            and self.slot_num == 28
        ):
            raise RuntimeError("RepEncoder requires custom CUDA embedding bag with CUDA fp16 weight, emb_dim=512, slot_num=28")

        slot_values = []
        slot_offsets = []
        for i in range(self.slot_num):
            values, offsets = batch[i + 1]
            if (
                not values.is_cuda
                or not offsets.is_cuda
                or values.dtype != torch.long
                or offsets.dtype != torch.long
            ):
                raise RuntimeError("custom CUDA embedding bag requires CUDA int64 values/offsets for every slot")
            slot_values.append(values.contiguous())
            slot_offsets.append(offsets.contiguous())

        ext = _get_embedding_bag_ext()
        if (
            "_slot_value_ptrs" in batch
            and "_slot_offset_ptrs" in batch
            and "_graph_active_rows" in batch
        ):
            fused_embs = ext.embedding_bag_28slot_fused_with_ptrs_active(
                self.emb.weight.contiguous(),
                batch["_slot_value_ptrs"].contiguous(),
                batch["_slot_offset_ptrs"].contiguous(),
                int(batch.get("_graph_n_rows", slot_offsets[0].numel() - 1)),
                batch["_graph_active_rows"].contiguous(),
            )
        elif "_slot_value_ptrs" in batch and "_slot_offset_ptrs" in batch:
            fused_embs = ext.embedding_bag_28slot_fused_with_ptrs(
                self.emb.weight.contiguous(),
                batch["_slot_value_ptrs"].contiguous(),
                batch["_slot_offset_ptrs"].contiguous(),
                int(batch.get("_graph_n_rows", slot_offsets[0].numel() - 1)),
            )
        else:
            fused_embs = ext.embedding_bag_28slot_fused(
                self.emb.weight.contiguous(),
                slot_values,
                slot_offsets,
            )
        if USE_CUSTOM_CUDA_REP_NORM:
            if not (
                self.input_norm.elementwise_affine
                and self.input_norm.weight is not None
                and self.input_norm.bias is not None
                and self.input_norm.weight.is_cuda
                and self.input_norm.bias.is_cuda
                and self.input_norm.weight.dtype == torch.float16
                and self.input_norm.bias.dtype == torch.float16
            ):
                raise RuntimeError("RepEncoder input_norm requires CUDA fp16 affine LayerNorm parameters")

            norm_emb = _get_layernorm_ext().layernorm_14336(
                fused_embs.contiguous(),
                self.input_norm.weight.contiguous(),
                self.input_norm.bias.contiguous(),
                self.input_norm.eps,
            )
        else:
            norm_emb = self.input_norm(fused_embs)
        rep_emb = self.linear(norm_emb)
        return rep_emb


def scaled_dot_product(q, k, v, extension):
    custom_attention_candidate = (
        USE_CUSTOM_CUDA_ATTENTION
        and extension is not None
        and "user_offsets" in extension
        and q.is_cuda
        and q.dim() == 4
        and q.size(0) == 1
        and q.size(-1) == 64
    )
    if custom_attention_candidate:
        if q.dtype != torch.float16 or k.dtype != torch.float16 or v.dtype != torch.float16:
            raise RuntimeError("custom CUDA attention is half-only; q/k/v must be float16")

        ext = _get_attention_ext()
        user_offsets = extension["user_offsets"].contiguous()
        tile_meta_mma = extension.get("attention_tile_meta_mma")
        if tile_meta_mma is None:
            raise RuntimeError("custom CUDA attention requires attention_tile_meta_mma")
        if not hasattr(ext, "varlen_causal_attention_mma_qk_pv_padded_shared_kv_meta"):
            raise RuntimeError("custom CUDA attention extension is missing shared-kv tile-meta kernel")
        return ext.varlen_causal_attention_mma_qk_pv_padded_shared_kv_meta(
            q.contiguous(),
            k.contiguous(),
            v.contiguous(),
            user_offsets,
            tile_meta_mma.contiguous(),
        )

    d = q.size(-1)
    scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(d)
    if extension is not None and "mask" in extension:
        mask = extension["mask"]
        scores = scores.masked_fill(mask == 0, float("-inf"))
    attn = torch.softmax(scores, dim=-1)
    out = torch.matmul(attn, v)
    return out


def scaled_dot_product_interleaved_qkv(qkv, extension):
    custom_attention_candidate = (
        USE_CUSTOM_CUDA_ATTENTION
        and USE_INTERLEAVED_QKV_ATTENTION
        and extension is not None
        and "user_offsets" in extension
        and qkv.is_cuda
        and qkv.dim() == 4
        and qkv.size(0) == 1
        and qkv.size(-1) == 3 * 64
    )
    if not custom_attention_candidate:
        return None
    if qkv.dtype != torch.float16:
        raise RuntimeError("custom CUDA interleaved attention is half-only; qkv must be float16")

    tile_meta_mma = extension.get("attention_tile_meta_mma")
    if tile_meta_mma is None:
        raise RuntimeError("custom CUDA interleaved attention requires attention_tile_meta_mma")
    attention_kernel, _ = _get_interleaved_attention_kernel()
    return attention_kernel(
        qkv.contiguous(),
        extension["user_offsets"].contiguous(),
        tile_meta_mma.contiguous(),
        USE_INTERLEAVED_QKV_ATTENTION_TOKEN_MAJOR_OUT,
    )


class Expert(nn.Module):
    def __init__(self, d_model, dim_ff):
        super().__init__()
        self.fc1 = nn.Linear(d_model, dim_ff)
        self.fc2 = nn.Linear(dim_ff, d_model)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))


def _w4a16_quantize_weight(weight, group_size):
    if weight.dim() != 2:
        raise RuntimeError(f"W4A16 weight must be 2D, got shape={tuple(weight.shape)}")

    out_features, in_features = weight.shape
    if in_features % group_size != 0:
        raise RuntimeError(
            f"W4A16_GROUP_SIZE={group_size} must divide in_features={in_features}"
        )

    weight_float = weight.detach().float()
    groups = weight_float.view(out_features, in_features // group_size, group_size)
    zero = groups.amin(dim=2, keepdim=True)
    max_val = groups.amax(dim=2, keepdim=True)
    scale = (max_val - zero) / 15.0
    nonzero_scale = scale > 0
    safe_scale = torch.where(nonzero_scale, scale, torch.ones_like(scale))
    quant = torch.clamp(torch.round((groups - zero) / safe_scale), 0.0, 15.0)
    return (
        quant.view(out_features, in_features).to(dtype=torch.int16).contiguous(),
        scale.squeeze(2).contiguous(),
        zero.squeeze(2).contiguous(),
    )


def _w4a16_dequantize_qweight(quant, scale, zero, dtype):
    if quant.dim() != 2 or scale.dim() != 2 or zero.dim() != 2:
        raise RuntimeError("W4A16 dequant expects quant [N,K], scale [N,G], zero [N,G]")

    out_features, in_features = quant.shape
    if scale.shape != zero.shape or scale.size(0) != out_features:
        raise RuntimeError(
            f"W4A16 scale/zero shape mismatch: scale={tuple(scale.shape)}, "
            f"zero={tuple(zero.shape)}, quant={tuple(quant.shape)}"
        )

    group_count = scale.size(1)
    if in_features % group_count != 0:
        raise RuntimeError(
            f"W4A16 in_features={in_features} must be divisible by group_count={group_count}"
        )

    group_size = in_features // group_count
    quant_float = quant.float().view(out_features, group_count, group_size)
    dequant = quant_float * scale.float().unsqueeze(2) + zero.float().unsqueeze(2)
    return dequant.view(out_features, in_features).to(dtype=dtype).contiguous()


def _w4a16_pack_qweight(quant):
    if quant.dim() != 2:
        raise RuntimeError(f"W4A16 pack expects quant [N,K], got shape={tuple(quant.shape)}")

    out_features, in_features = quant.shape
    if in_features % 4 != 0:
        raise RuntimeError(f"W4A16 pack requires K divisible by 4, got K={in_features}")

    q = quant.to(torch.int32).view(out_features, in_features // 4, 4)
    packed = (
        q[:, :, 0]
        | torch.bitwise_left_shift(q[:, :, 1], 4)
        | torch.bitwise_left_shift(q[:, :, 2], 8)
        | torch.bitwise_left_shift(q[:, :, 3], 12)
    )
    packed = torch.where(packed >= 32768, packed - 65536, packed)
    return packed.to(torch.int16).contiguous()


def _w4a16_unpack_qweight(packed, in_features):
    if packed.dim() != 2:
        raise RuntimeError(f"W4A16 unpack expects packed [N,K/4], got shape={tuple(packed.shape)}")
    if packed.size(1) * 4 != in_features:
        raise RuntimeError(
            f"W4A16 packed shape {tuple(packed.shape)} does not match in_features={in_features}"
        )

    packed_int = packed.to(torch.int32)
    packed_uint = torch.where(packed_int < 0, packed_int + 65536, packed_int)
    q0 = torch.bitwise_and(packed_uint, 0x000F)
    q1 = torch.bitwise_and(torch.bitwise_right_shift(packed_uint, 4), 0x000F)
    q2 = torch.bitwise_and(torch.bitwise_right_shift(packed_uint, 8), 0x000F)
    q3 = torch.bitwise_and(torch.bitwise_right_shift(packed_uint, 12), 0x000F)
    return torch.stack((q0, q1, q2, q3), dim=2).reshape(
        packed.size(0),
        in_features,
    ).to(torch.int16).contiguous()


def _w4a16_prepare_weight(weight, group_size):
    quant, scale, zero = _w4a16_quantize_weight(weight, group_size)
    dequant = _w4a16_dequantize_qweight(quant, scale, zero, weight.dtype)
    packed = _w4a16_pack_qweight(quant)
    return dequant, packed, scale, zero


def _w4a16_linear_reference(x, weight_dequant, bias):
    return F.linear(x, weight_dequant.to(dtype=x.dtype), bias)


def _simple_w4a4_pack_weight_uniform(weight, scale):
    if weight.dim() != 3 or weight.size(0) != 8 or weight.size(2) % 8 != 0:
        raise RuntimeError(
            "simple W4A4 expects weight [8,out,in] with in divisible by 8, "
            f"got {tuple(weight.shape)}"
        )
    if scale <= 0.0:
        raise RuntimeError(f"simple W4A4 weight scale must be positive, got {scale}")

    q = torch.round(weight.float() / scale).clamp_(-8, 7).to(torch.int32)
    q = q & 0xF
    packed = torch.zeros(
        (weight.size(0), weight.size(1), weight.size(2) // 8),
        dtype=torch.int32,
        device=weight.device,
    )
    for idx in range(8):
        packed |= q[:, :, idx::8] << (4 * idx)
    return packed.contiguous()


def _is_w4a16_cuda_skeleton_unavailable(exc):
    message = str(exc)
    return (
        "smoe_forward_w4a16 CUDA kernel is not implemented yet" in message
        or "smoe_forward_w4a16_with_residual CUDA kernel is not implemented yet" in message
        or "routed_smoe_ext must export smoe_forward_w4a16" in message
        or "routed_smoe_ext must export smoe_forward_w4a16_frag" in message
    )


class TopKGate(nn.Module):
    def __init__(self, d_model, num_experts, k=2, noisy_gating=True):
        super().__init__()
        self.w_g = nn.Linear(d_model, num_experts)
        self.num_experts = num_experts
        self.k = k
        self.noisy_gating = noisy_gating

    def forward(self, x):
        # x: [B,S,D]
        if self.training:
            raise RuntimeError("TopKGate optimized path is inference-only")
        if not (
            x.is_cuda
            and x.dtype == torch.float16
            and self.w_g.weight.is_cuda
            and self.w_g.weight.dtype == torch.float16
            and self.w_g.bias is not None
            and self.w_g.bias.is_cuda
            and self.w_g.bias.dtype == torch.float16
            and self.num_experts == 8
            and self.k == 2
        ):
            raise RuntimeError("TopKGate requires CUDA fp16 Linear(512->8) and top-2 custom CUDA softmax")

        logits = self.w_g(x)  # [B,S,E]
        if logits.size(-1) != 8:
            raise RuntimeError(f"custom CUDA gate top2 softmax requires last dim 8, got {logits.size(-1)}")
        topk_idx, topk_score = _get_gate_topk_ext().top2_softmax_8(logits.contiguous())
        return topk_idx, topk_score, None

class SMoE(nn.Module):
    def __init__(self, d_model, dim_ff, num_experts, k=2):
        super().__init__()
        self.num_experts = num_experts
        self.k = k

        self.experts = nn.ModuleList([
            Expert(d_model, dim_ff) for _ in range(num_experts)
        ])

        self.gate = TopKGate(d_model, num_experts, k=k)

    def prepare_dense_all(self):
        w1_tn = torch.stack(
            [expert.fc1.weight.detach().contiguous() for expert in self.experts],
            dim=0,
        )
        b1 = torch.stack(
            [expert.fc1.bias.detach() for expert in self.experts],
            dim=0,
        )
        w2_tn = torch.stack(
            [expert.fc2.weight.detach().contiguous() for expert in self.experts],
            dim=0,
        )
        b2 = torch.stack(
            [expert.fc2.bias.detach() for expert in self.experts],
            dim=0,
        )

        self.register_buffer("_dense_all_w1_tn", w1_tn, persistent=False)
        self.register_buffer("_dense_all_b1", b1, persistent=False)
        self.register_buffer("_dense_all_w2_tn", w2_tn, persistent=False)
        self.register_buffer("_dense_all_b2", b2, persistent=False)

    def prepare_simple_w4a4_weights(self):
        if (
            hasattr(self, "_simple_w4a4_w2_pack")
            and hasattr(self, "_simple_w4a4_b2")
            and hasattr(self, "_simple_w4a4_weight_scale")
            and hasattr(self, "_simple_w4a4_weight_scale_value")
            and (not USE_SIMPLE_W4A4_FC1_SMOE or hasattr(self, "_simple_w4a4_w1_pack"))
        ):
            return

        if not hasattr(self, "_dense_all_w1_tn") or not hasattr(self, "_dense_all_w2_tn"):
            self.prepare_dense_all()

        if SIMPLE_W4A4_WEIGHT_SCALE > 0.0:
            weight_scale = SIMPLE_W4A4_WEIGHT_SCALE
        elif USE_SIMPLE_W4A4_FC1_SMOE:
            weight_scale = float(
                torch.maximum(
                    self._dense_all_w1_tn.float().abs().max(),
                    self._dense_all_w2_tn.float().abs().max(),
                )
                .mul(2.0 / 15.0)
                .clamp_min(1e-6)
                .item()
            )
        else:
            weight_scale = float(
                (self._dense_all_w2_tn.float().abs().max() * (2.0 / 15.0))
                .clamp_min(1e-6)
                .item()
            )
        w2_pack = _simple_w4a4_pack_weight_uniform(self._dense_all_w2_tn, weight_scale)

        if USE_SIMPLE_W4A4_FC1_SMOE:
            w1_pack = _simple_w4a4_pack_weight_uniform(self._dense_all_w1_tn, weight_scale)
            self.register_buffer("_simple_w4a4_w1_pack", w1_pack, persistent=False)
            self.register_buffer("_simple_w4a4_b1", self._dense_all_b1.detach().contiguous(), persistent=False)
        self.register_buffer("_simple_w4a4_w2_pack", w2_pack, persistent=False)
        self.register_buffer("_simple_w4a4_b2", self._dense_all_b2.detach().contiguous(), persistent=False)
        self.register_buffer(
            "_simple_w4a4_weight_scale",
            torch.tensor(weight_scale, device=self._dense_all_w2_tn.device, dtype=torch.float32),
            persistent=False,
        )
        self._simple_w4a4_weight_scale_value = weight_scale

    def prepare_w4a16_weights(self):
        if (
            hasattr(self, "_w4_w1_qdq")
            and hasattr(self, "_w4_w1_pack")
            and hasattr(self, "_w4_w1_scale_h")
            and hasattr(self, "_w4_w2_qdq")
            and hasattr(self, "_w4_w2_pack")
            and hasattr(self, "_w4_w2_scale_h")
        ):
            return

        w1_qdq = []
        w1_pack = []
        w1_scale = []
        w1_zero = []
        b1 = []
        w2_qdq = []
        w2_pack = []
        w2_scale = []
        w2_zero = []
        b2 = []
        for expert in self.experts:
            qdq1, pack1, scale1, zero1 = _w4a16_prepare_weight(
                expert.fc1.weight,
                W4A16_GROUP_SIZE,
            )
            qdq2, pack2, scale2, zero2 = _w4a16_prepare_weight(
                expert.fc2.weight,
                W4A16_GROUP_SIZE,
            )
            w1_qdq.append(qdq1)
            w1_pack.append(pack1)
            w1_scale.append(scale1)
            w1_zero.append(zero1)
            b1.append(expert.fc1.bias.detach().contiguous())
            w2_qdq.append(qdq2)
            w2_pack.append(pack2)
            w2_scale.append(scale2)
            w2_zero.append(zero2)
            b2.append(expert.fc2.bias.detach().contiguous())

        self.register_buffer("_w4_w1_qdq", torch.stack(w1_qdq, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w1_pack", torch.stack(w1_pack, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w1_scale", torch.stack(w1_scale, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w1_zero", torch.stack(w1_zero, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w1_scale_h", self._w4_w1_scale.to(torch.float16).contiguous(), persistent=False)
        self.register_buffer("_w4_w1_zero_h", self._w4_w1_zero.to(torch.float16).contiguous(), persistent=False)
        self.register_buffer("_w4_b1", torch.stack(b1, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w2_qdq", torch.stack(w2_qdq, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w2_pack", torch.stack(w2_pack, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w2_scale", torch.stack(w2_scale, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w2_zero", torch.stack(w2_zero, dim=0).contiguous(), persistent=False)
        self.register_buffer("_w4_w2_scale_h", self._w4_w2_scale.to(torch.float16).contiguous(), persistent=False)
        self.register_buffer("_w4_w2_zero_h", self._w4_w2_zero.to(torch.float16).contiguous(), persistent=False)
        self.register_buffer("_w4_b2", torch.stack(b2, dim=0).contiguous(), persistent=False)

    def _w4a16_cuda_scale_buffers(self, use_half_scale):
        if use_half_scale:
            return (
                self._w4_w1_scale_h,
                self._w4_w1_zero_h,
                self._w4_w2_scale_h,
                self._w4_w2_zero_h,
            )
        return (
            self._w4_w1_scale,
            self._w4_w1_zero,
            self._w4_w2_scale,
            self._w4_w2_zero,
        )

    def _use_w4a16_cuda_half_scale(self, fn_name):
        return (
            USE_HALF_SCALE_W4A16_SMOE
            and (
                fn_name.startswith("smoe_forward_w4a16_frag")
                or fn_name.startswith("smoe_forward_w4a16_lop3")
            )
        )

    def _forward_routed_sparse_cuda(self, x, topk_idx, topk_score):
        B, S, D = x.shape
        x_flat = x.reshape(-1, D).contiguous()
        n_tokens = x_flat.shape[0]

        ext = _get_routed_smoe_ext()
        if USE_CUTLASS_SMOE:
            fn_name = "smoe_forward_cutlass_fc2"
        elif USE_M64_SMOE:
            fn_name = "smoe_forward_m64"
        else:
            fn_name = "smoe_forward"
        if not hasattr(ext, fn_name):
            raise RuntimeError(f"routed_smoe_ext must export {fn_name}")
        out = getattr(ext, fn_name)(
            x_flat,
            self._dense_all_w1_tn.contiguous(),
            self._dense_all_b1.contiguous(),
            self._dense_all_w2_tn.contiguous(),
            self._dense_all_b2.contiguous(),
            topk_idx.reshape(n_tokens, self.k).contiguous(),
            topk_score.reshape(n_tokens, self.k).contiguous(),
        )
        return out.reshape(B, S, D)

    def _forward_routed_sparse_cuda_with_residual(self, x, residual, topk_idx, topk_score):
        B, S, D = x.shape
        x_flat = x.reshape(-1, D).contiguous()
        residual_flat = residual.reshape(-1, D).contiguous()
        n_tokens = x_flat.shape[0]

        ext = _get_routed_smoe_ext()
        if USE_CUTLASS_SMOE:
            fn_name = "smoe_forward_cutlass_fc2_with_residual"
        elif USE_M64_SMOE:
            fn_name = "smoe_forward_m64_with_residual"
        else:
            fn_name = "smoe_forward_with_residual"
        if not hasattr(ext, fn_name):
            raise RuntimeError(f"routed_smoe_ext must export {fn_name}")
        out = getattr(ext, fn_name)(
            x_flat,
            residual_flat,
            self._dense_all_w1_tn.contiguous(),
            self._dense_all_b1.contiguous(),
            self._dense_all_w2_tn.contiguous(),
            self._dense_all_b2.contiguous(),
            topk_idx.reshape(n_tokens, self.k).contiguous(),
            topk_score.reshape(n_tokens, self.k).contiguous(),
        )
        return out.reshape(B, S, D)

    def _forward_simple_w4a4_cuda(self, x, topk_idx, topk_score):
        self.prepare_simple_w4a4_weights()

        B, S, D = x.shape
        x_flat = x.reshape(-1, D).contiguous()
        n_tokens = x_flat.shape[0]

        ext = _get_routed_smoe_ext()
        fn_name = "smoe_forward_simple_w4a4" if USE_SIMPLE_W4A4_FC1_SMOE else "smoe_forward_simple_w4a4_fc2"
        if not hasattr(ext, fn_name):
            raise RuntimeError(f"routed_smoe_ext must export {fn_name}")
        if USE_SIMPLE_W4A4_FC1_SMOE:
            out = getattr(ext, fn_name)(
                x_flat,
                self._simple_w4a4_w1_pack.contiguous(),
                self._simple_w4a4_b1.contiguous(),
                self._simple_w4a4_w2_pack.contiguous(),
                self._simple_w4a4_b2.contiguous(),
                topk_idx.reshape(n_tokens, self.k).contiguous(),
                topk_score.reshape(n_tokens, self.k).contiguous(),
                float(SIMPLE_W4A4_FC1_ACT_SCALE),
                float(self._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC1_OUTPUT_SCALE),
                float(SIMPLE_W4A4_ACT_SCALE),
                float(self._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC2_OUTPUT_SCALE),
            )
        else:
            out = getattr(ext, fn_name)(
                x_flat,
                self._dense_all_w1_tn.contiguous(),
                self._dense_all_b1.contiguous(),
                self._simple_w4a4_w2_pack.contiguous(),
                self._simple_w4a4_b2.contiguous(),
                topk_idx.reshape(n_tokens, self.k).contiguous(),
                topk_score.reshape(n_tokens, self.k).contiguous(),
                float(SIMPLE_W4A4_ACT_SCALE),
                float(self._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC2_OUTPUT_SCALE),
            )
        return out.reshape(B, S, D)

    def _forward_simple_w4a4_cuda_with_residual(self, x, residual, topk_idx, topk_score):
        self.prepare_simple_w4a4_weights()

        B, S, D = x.shape
        x_flat = x.reshape(-1, D).contiguous()
        residual_flat = residual.reshape(-1, D).contiguous()
        n_tokens = x_flat.shape[0]

        ext = _get_routed_smoe_ext()
        fn_name = (
            "smoe_forward_simple_w4a4_with_residual"
            if USE_SIMPLE_W4A4_FC1_SMOE
            else "smoe_forward_simple_w4a4_fc2_with_residual"
        )
        if not hasattr(ext, fn_name):
            raise RuntimeError(f"routed_smoe_ext must export {fn_name}")
        if USE_SIMPLE_W4A4_FC1_SMOE:
            out = getattr(ext, fn_name)(
                x_flat,
                residual_flat,
                self._simple_w4a4_w1_pack.contiguous(),
                self._simple_w4a4_b1.contiguous(),
                self._simple_w4a4_w2_pack.contiguous(),
                self._simple_w4a4_b2.contiguous(),
                topk_idx.reshape(n_tokens, self.k).contiguous(),
                topk_score.reshape(n_tokens, self.k).contiguous(),
                float(SIMPLE_W4A4_FC1_ACT_SCALE),
                float(self._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC1_OUTPUT_SCALE),
                float(SIMPLE_W4A4_ACT_SCALE),
                float(self._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC2_OUTPUT_SCALE),
            )
        else:
            out = getattr(ext, fn_name)(
                x_flat,
                residual_flat,
                self._dense_all_w1_tn.contiguous(),
                self._dense_all_b1.contiguous(),
                self._simple_w4a4_w2_pack.contiguous(),
                self._simple_w4a4_b2.contiguous(),
                topk_idx.reshape(n_tokens, self.k).contiguous(),
                topk_score.reshape(n_tokens, self.k).contiguous(),
                float(SIMPLE_W4A4_ACT_SCALE),
                float(self._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC2_OUTPUT_SCALE),
            )
        return out.reshape(B, S, D)

    def _forward_w4a16_cuda(self, x, topk_idx, topk_score):
        self.prepare_w4a16_weights()

        B, S, D = x.shape
        x_flat = x.reshape(-1, D).contiguous()
        n_tokens = x_flat.shape[0]

        ext = _get_routed_smoe_ext()
        if USE_SIMT_FC2_W4A16_SMOE:
            fn_name = "smoe_forward_w4a16_simt_fc2"
        elif USE_LOP3_DEQUANT_W4A16_SMOE:
            fn_name = "smoe_forward_w4a16_lop3"
        elif USE_FRAG_DEQUANT_W4A16_SMOE:
            fn_name = "smoe_forward_w4a16_frag"
        else:
            fn_name = "smoe_forward_w4a16"
        if not hasattr(ext, fn_name):
            raise RuntimeError(f"routed_smoe_ext must export {fn_name}")
        w1_scale, w1_zero, w2_scale, w2_zero = self._w4a16_cuda_scale_buffers(
            self._use_w4a16_cuda_half_scale(fn_name)
        )

        out = getattr(ext, fn_name)(
            x_flat,
            self._w4_w1_pack.contiguous(),
            w1_scale.contiguous(),
            w1_zero.contiguous(),
            self._w4_b1.contiguous(),
            self._w4_w2_pack.contiguous(),
            w2_scale.contiguous(),
            w2_zero.contiguous(),
            self._w4_b2.contiguous(),
            topk_idx.reshape(n_tokens, self.k).contiguous(),
            topk_score.reshape(n_tokens, self.k).contiguous(),
            W4A16_GROUP_SIZE,
        )
        return out.reshape(B, S, D)

    def _forward_w4a16_cuda_with_residual(self, x, residual, topk_idx, topk_score):
        self.prepare_w4a16_weights()

        B, S, D = x.shape
        x_flat = x.reshape(-1, D).contiguous()
        residual_flat = residual.reshape(-1, D).contiguous()
        n_tokens = x_flat.shape[0]

        ext = _get_routed_smoe_ext()
        if USE_SIMT_FC2_W4A16_SMOE:
            fn_name = "smoe_forward_w4a16_simt_fc2_with_residual"
        elif USE_LOP3_DEQUANT_W4A16_SMOE:
            fn_name = "smoe_forward_w4a16_lop3_with_residual"
        elif USE_FRAG_DEQUANT_W4A16_SMOE:
            fn_name = "smoe_forward_w4a16_frag_with_residual"
        else:
            fn_name = "smoe_forward_w4a16_with_residual"
        if not hasattr(ext, fn_name):
            raise RuntimeError(f"routed_smoe_ext must export {fn_name}")
        w1_scale, w1_zero, w2_scale, w2_zero = self._w4a16_cuda_scale_buffers(
            self._use_w4a16_cuda_half_scale(fn_name)
        )

        out = getattr(ext, fn_name)(
            x_flat,
            residual_flat,
            self._w4_w1_pack.contiguous(),
            w1_scale.contiguous(),
            w1_zero.contiguous(),
            self._w4_b1.contiguous(),
            self._w4_w2_pack.contiguous(),
            w2_scale.contiguous(),
            w2_zero.contiguous(),
            self._w4_b2.contiguous(),
            topk_idx.reshape(n_tokens, self.k).contiguous(),
            topk_score.reshape(n_tokens, self.k).contiguous(),
            W4A16_GROUP_SIZE,
        )
        return out.reshape(B, S, D)

    def _forward_w4a16_reference(self, x, topk_idx, topk_score):
        self.prepare_w4a16_weights()

        B, S, D = x.shape
        x_flat = x.reshape(-1, D)
        idx_flat = topk_idx.reshape(-1, self.k)
        score_flat = topk_score.reshape(-1, self.k)
        out_flat = torch.zeros(
            (x_flat.size(0), D),
            device=x.device,
            dtype=torch.float32,
        )

        for expert_idx in range(self.num_experts):
            token_idx, route_idx = (idx_flat == expert_idx).nonzero(as_tuple=True)
            if token_idx.numel() == 0:
                continue

            selected_x = x_flat.index_select(0, token_idx)
            hidden = _w4a16_linear_reference(
                selected_x,
                self._w4_w1_qdq[expert_idx],
                self._w4_b1[expert_idx],
            )
            hidden = F.relu(hidden)
            expert_out = _w4a16_linear_reference(
                hidden,
                self._w4_w2_qdq[expert_idx],
                self._w4_b2[expert_idx],
            )
            route_weight = score_flat[token_idx, route_idx].float().unsqueeze(-1)
            out_flat.index_add_(0, token_idx, expert_out.float() * route_weight)

        return out_flat.reshape(B, S, D).to(dtype=x.dtype)

    def _forward_w4a16_reference_with_residual(self, x, residual, topk_idx, topk_score):
        self.prepare_w4a16_weights()

        B, S, D = x.shape
        x_flat = x.reshape(-1, D)
        residual_flat = residual.reshape(-1, D)
        idx_flat = topk_idx.reshape(-1, self.k)
        score_flat = topk_score.reshape(-1, self.k)
        out_flat = residual_flat.float().clone()

        for expert_idx in range(self.num_experts):
            token_idx, route_idx = (idx_flat == expert_idx).nonzero(as_tuple=True)
            if token_idx.numel() == 0:
                continue

            selected_x = x_flat.index_select(0, token_idx)
            hidden = _w4a16_linear_reference(
                selected_x,
                self._w4_w1_qdq[expert_idx],
                self._w4_b1[expert_idx],
            )
            hidden = F.relu(hidden)
            expert_out = _w4a16_linear_reference(
                hidden,
                self._w4_w2_qdq[expert_idx],
                self._w4_b2[expert_idx],
            )
            route_weight = score_flat[token_idx, route_idx].float().unsqueeze(-1)
            out_flat.index_add_(0, token_idx, expert_out.float() * route_weight)

        return out_flat.reshape(B, S, D).to(dtype=x.dtype)

    def forward(self, x):
        # x: [B,S,D]
        B, S, D = x.shape

        if not (
            not self.training
            and x.is_cuda
            and x.dtype == torch.float16
            and self.num_experts == 8
            and self.k == 2
            and D == 512
            and hasattr(self, "_dense_all_w1_tn")
            and hasattr(self, "_dense_all_w2_tn")
        ):
            raise RuntimeError("SMoE requires custom CUDA routed sparse path with CUDA fp16 [*,512] input")

        topk_idx, topk_score, _ = self.gate(x)
        if USE_SIMPLE_W4A4_SMOE:
            self.prepare_simple_w4a4_weights()
            if not hasattr(self, "_printed_simple_w4a4_smoe"):
                print(
                    "[INFO] SMoE using simple CUDA W4A4 fc2 path "
                    f"(fc1={USE_SIMPLE_W4A4_FC1_SMOE}, "
                    f"fc1_act_scale={SIMPLE_W4A4_FC1_ACT_SCALE}, "
                    f"fc1_output_scale={SIMPLE_W4A4_FC1_OUTPUT_SCALE}, "
                    f"fc2_act_scale={SIMPLE_W4A4_ACT_SCALE}, "
                    f"weight_scale={float(self._simple_w4a4_weight_scale_value):.8e}, "
                    f"fc2_output_scale={SIMPLE_W4A4_FC2_OUTPUT_SCALE})"
                )
                self._printed_simple_w4a4_smoe = True
            out = self._forward_simple_w4a4_cuda(x, topk_idx, topk_score)
        elif USE_W4A16_SMOE:
            if USE_CUDA_W4A16_SMOE and not getattr(self, "_disable_w4a16_cuda", False):
                try:
                    if not hasattr(self, "_printed_w4a16_cuda_smoe"):
                        print(
                            "[INFO] SMoE attempting CUDA W4A16 path "
                            f"(group_size={W4A16_GROUP_SIZE}, "
                            f"frag_dequant={USE_FRAG_DEQUANT_W4A16_SMOE}, "
                            f"lop3_dequant={USE_LOP3_DEQUANT_W4A16_SMOE}, "
                            f"simt_fc2={USE_SIMT_FC2_W4A16_SMOE}, "
                            f"half_scale={USE_HALF_SCALE_W4A16_SMOE})"
                        )
                        self._printed_w4a16_cuda_smoe = True
                    out = self._forward_w4a16_cuda(x, topk_idx, topk_score)
                    return out, x.new_zeros(())
                except RuntimeError as exc:
                    if REQUIRE_CUDA_W4A16_SMOE or not _is_w4a16_cuda_skeleton_unavailable(exc):
                        raise
                    if not hasattr(self, "_printed_w4a16_cuda_fallback"):
                        print(
                            "[INFO] CUDA W4A16 SMoE path unavailable; "
                            "falling back to Python W4A16 reference"
                        )
                        self._printed_w4a16_cuda_fallback = True
                    self._disable_w4a16_cuda = True
            if not hasattr(self, "_printed_w4a16_smoe"):
                print(
                    "[INFO] SMoE using Python W4A16 reference path "
                    f"(group_size={W4A16_GROUP_SIZE})"
                )
                self._printed_w4a16_smoe = True
            out = self._forward_w4a16_reference(x, topk_idx, topk_score)
        else:
            if not hasattr(self, "_printed_routed_sparse"):
                print("[INFO] SMoE using custom CUDA routed sparse path")
                self._printed_routed_sparse = True
            out = self._forward_routed_sparse_cuda(x, topk_idx, topk_score)
        return out, x.new_zeros(())

    def forward_with_residual(self, x, residual):
        B, S, D = x.shape

        if not (
            not self.training
            and x.is_cuda
            and residual.is_cuda
            and x.dtype == torch.float16
            and residual.dtype == torch.float16
            and self.num_experts == 8
            and self.k == 2
            and D == 512
            and hasattr(self, "_dense_all_w1_tn")
            and hasattr(self, "_dense_all_w2_tn")
        ):
            raise RuntimeError("SMoE requires custom CUDA routed sparse residual path with CUDA fp16 [*,512] input")

        topk_idx, topk_score, _ = self.gate(x)
        if USE_SIMPLE_W4A4_SMOE:
            self.prepare_simple_w4a4_weights()
            if not hasattr(self, "_printed_simple_w4a4_smoe_residual"):
                print(
                    "[INFO] SMoE using simple CUDA W4A4 fc2 path with residual add "
                    f"(fc1={USE_SIMPLE_W4A4_FC1_SMOE}, "
                    f"fc1_act_scale={SIMPLE_W4A4_FC1_ACT_SCALE}, "
                    f"fc1_output_scale={SIMPLE_W4A4_FC1_OUTPUT_SCALE}, "
                    f"fc2_act_scale={SIMPLE_W4A4_ACT_SCALE}, "
                    f"weight_scale={float(self._simple_w4a4_weight_scale_value):.8e}, "
                    f"fc2_output_scale={SIMPLE_W4A4_FC2_OUTPUT_SCALE})"
                )
                self._printed_simple_w4a4_smoe_residual = True
            out = self._forward_simple_w4a4_cuda_with_residual(x, residual, topk_idx, topk_score)
            return out, x.new_zeros(())

        if USE_W4A16_SMOE:
            if USE_CUDA_W4A16_SMOE and not getattr(self, "_disable_w4a16_cuda", False):
                try:
                    if not hasattr(self, "_printed_w4a16_cuda_smoe_residual"):
                        print(
                            "[INFO] SMoE attempting CUDA W4A16 path with residual add "
                            f"(group_size={W4A16_GROUP_SIZE}, "
                            f"frag_dequant={USE_FRAG_DEQUANT_W4A16_SMOE}, "
                            f"lop3_dequant={USE_LOP3_DEQUANT_W4A16_SMOE}, "
                            f"simt_fc2={USE_SIMT_FC2_W4A16_SMOE}, "
                            f"half_scale={USE_HALF_SCALE_W4A16_SMOE})"
                        )
                        self._printed_w4a16_cuda_smoe_residual = True
                    out = self._forward_w4a16_cuda_with_residual(x, residual, topk_idx, topk_score)
                    return out, x.new_zeros(())
                except RuntimeError as exc:
                    if REQUIRE_CUDA_W4A16_SMOE or not _is_w4a16_cuda_skeleton_unavailable(exc):
                        raise
                    if not hasattr(self, "_printed_w4a16_cuda_fallback_residual"):
                        print(
                            "[INFO] CUDA W4A16 SMoE residual path unavailable; "
                            "falling back to Python W4A16 reference"
                        )
                        self._printed_w4a16_cuda_fallback_residual = True
                    self._disable_w4a16_cuda = True
            if not hasattr(self, "_printed_w4a16_smoe_residual"):
                print(
                    "[INFO] SMoE using Python W4A16 reference path with residual add "
                    f"(group_size={W4A16_GROUP_SIZE})"
                )
                self._printed_w4a16_smoe_residual = True
            out = self._forward_w4a16_reference_with_residual(x, residual, topk_idx, topk_score)
            return out, x.new_zeros(())

        ext = _get_routed_smoe_ext()
        if not hasattr(ext, "smoe_forward_with_residual"):
            raise RuntimeError("routed_smoe_ext must export smoe_forward_with_residual")

        if not hasattr(self, "_printed_routed_sparse_residual"):
            print("[INFO] SMoE using custom CUDA routed sparse path with residual add")
            self._printed_routed_sparse_residual = True
        out = self._forward_routed_sparse_cuda_with_residual(
            x,
            residual,
            topk_idx,
            topk_score,
        )
        return out, x.new_zeros(())


class CustomLayerNorm512(nn.Module):
    """LayerNorm(512) replacement backed by CUDA/norm_kernels.cu."""

    def __init__(self, normalized_shape=512, eps=1e-5, elementwise_affine=True):
        super().__init__()
        if isinstance(normalized_shape, int):
            normalized_shape = (normalized_shape,)
        else:
            normalized_shape = tuple(normalized_shape)

        if normalized_shape != (512,):
            raise ValueError(f"CustomLayerNorm512 only supports normalized_shape=(512,), got {normalized_shape}")

        self.normalized_shape = normalized_shape
        self.eps = eps
        self.elementwise_affine = elementwise_affine

        if elementwise_affine:
            self.weight = nn.Parameter(torch.ones(512))
            self.bias = nn.Parameter(torch.zeros(512))
        else:
            self.register_parameter("weight", None)
            self.register_parameter("bias", None)

    def forward(self, x):
        if (
            USE_CUSTOM_CUDA_NORM
            and x.is_cuda
            and self.elementwise_affine
            and self.weight is not None
            and self.bias is not None
        ):
            if x.dtype != torch.float16 or self.weight.dtype != torch.float16 or self.bias.dtype != torch.float16:
                raise RuntimeError("custom CUDA LayerNorm is half-only; x/weight/bias must be float16")
            return _get_layernorm_ext().layernorm_512(
                x.contiguous(),
                self.weight.contiguous(),
                self.bias.contiguous(),
                self.eps,
            )

        return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)

    def add_layernorm(self, residual, x):
        return self.add_layernorm_with_residual(residual, x)[1]

    def add_layernorm_with_residual(self, residual, x):
        if (
            USE_CUSTOM_CUDA_NORM
            and residual.is_cuda
            and x.is_cuda
            and self.elementwise_affine
            and self.weight is not None
            and self.bias is not None
        ):
            if (
                residual.dtype != torch.float16
                or x.dtype != torch.float16
                or self.weight.dtype != torch.float16
                or self.bias.dtype != torch.float16
            ):
                raise RuntimeError("custom CUDA AddLayerNorm is half-only; residual/x/weight/bias must be float16")
            residual_out, norm_out = _get_layernorm_ext().add_layernorm_512_with_residual(
                residual.contiguous(),
                x.contiguous(),
                self.weight.contiguous(),
                self.bias.contiguous(),
                self.eps,
            )
            return residual_out, norm_out

        residual_out = residual + x
        norm_out = F.layer_norm(residual_out, self.normalized_shape, self.weight, self.bias, self.eps)
        return residual_out, norm_out


class TransformerEncoder(nn.Module):
    def __init__(self, d_model, n_heads, num_layers, dim_ff, act="relu",
                 attention_fn=scaled_dot_product):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.num_layers = num_layers
        assert d_model % n_heads == 0

        self.qkv_proj = nn.ModuleList([nn.Linear(d_model, 3 * d_model) for _ in range(num_layers)])
        self.out_proj = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(num_layers)])
        self.ffn1 = nn.ModuleList([nn.Linear(d_model, dim_ff) for _ in range(num_layers)])
        self.ffn2 = nn.ModuleList([nn.Linear(dim_ff, d_model) for _ in range(num_layers)])
        norm_cls = CustomLayerNorm512 if USE_CUSTOM_CUDA_NORM and d_model == 512 else nn.LayerNorm
        self.norm1 = nn.ModuleList([norm_cls(d_model) for _ in range(num_layers)])
        self.norm2 = nn.ModuleList([norm_cls(d_model) for _ in range(num_layers)])
        self.act = getattr(F, act)
        self.attention_fn = attention_fn
        self.moe = nn.ModuleList([
            SMoE(d_model, dim_ff, num_experts=8, k=2)
            for _ in range(num_layers)
        ])

    def prepare_dense_all_smoe(self):
        for moe in self.moe:
            moe.prepare_dense_all()

    def prepare_w4a16_smoe(self):
        for moe in self.moe:
            moe.prepare_w4a16_weights()

    def prepare_simple_w4a4_smoe(self):
        for moe in self.moe:
            moe.prepare_simple_w4a4_weights()

    def forward(self, x, extension):
        x = x.unsqueeze(0)
        B, S, D = x.shape

        moe_loss_total = 0.0
        for i in range(self.num_layers):
            residual = x
            x = self.norm1[i](x)
            qkv = self.qkv_proj[i](x)
            qkv = qkv.view(B, S, self.n_heads, 3 * self.head_dim)
            interleaved_attn_out = scaled_dot_product_interleaved_qkv(qkv, extension)
            if interleaved_attn_out is not None:
                if USE_INTERLEAVED_QKV_ATTENTION_TOKEN_MAJOR_OUT:
                    attn_out = interleaved_attn_out.reshape(B, S, D)
                else:
                    attn_out = interleaved_attn_out.permute(0, 2, 1, 3).reshape(B, S, D)
            else:
                qkv = qkv.permute(0, 2, 1, 3)
                q, k, v = torch.split(qkv, self.head_dim, dim=-1)
                attn_out = self.attention_fn(q, k, v, extension)
                attn_out = attn_out.permute(0, 2, 1, 3).reshape(B, S, D)
            attn_proj = self.out_proj[i](attn_out)
            if hasattr(self.norm2[i], "add_layernorm_with_residual"):
                residual, x = self.norm2[i].add_layernorm_with_residual(residual, attn_proj)
            else:
                residual = residual + attn_proj
                x = self.norm2[i](residual)

            x, moe_loss = self.moe[i].forward_with_residual(x, residual)

            moe_loss_total = moe_loss_total + moe_loss

        return x, moe_loss_total


class CTRModel(nn.Module):
    def __init__(self, rep_encoder, seq_encoder, d_model):
        super().__init__()
        self.rep_encoder = rep_encoder
        self.seq_encoder = seq_encoder
        self.d_model = d_model
        self.linear = nn.Linear(d_model, 1)

    def get_sequence_causal_mask(self, seq_info):
        # seq_info = tensor([0, 2, 5, 6])
        lengths = seq_info[1:] - seq_info[:-1]
        lengths = lengths.view(-1)
        # lengths = [2, 3, 1]
        indices = torch.cumsum(torch.ones_like(lengths), dim=0) - 1
        # 等价于 indices = torch.arange(len(lengths), device=lengths.device)
        # indices = [0, 1, 2]
        result = torch.repeat_interleave(indices, lengths)
        # result = [0, 0, 1, 1, 1, 2]
        a = result.view(1, -1) - result.view(-1, 1)
        # a = [
        #     [0-0, 0-0, 1-0, 1-0, 1-0, 2-0],
        #     [0-0, 0-0, 1-0, 1-0, 1-0, 2-0],
        #     [0-1, 0-1, 1-1, 1-1, 1-1, 2-1],
        #     ...
        #     ]
        # a == 0
        # 表示两个位置属于同一个用户
        out_mask = torch.tril((a == 0).to(torch.int32)).bool()
        return out_mask
        # [
        # [T, F, F, F, F, F],
        # [T, T, F, F, F, F],
        # [F, F, T, F, F, F],
        # [F, F, T, T, F, F],
        # [F, F, T, T, T, F],
        # [F, F, F, F, F, T],
        # ]

    def encode(self, batch):
        seq_input = self.rep_encoder(batch)
        seq_mask = None if USE_CUSTOM_CUDA_ATTENTION else self.get_sequence_causal_mask(batch["user_offsets"])
        extension = {"user_offsets": batch["user_offsets"]}
        if "attention_tile_meta_mma" in batch:
            extension["attention_tile_meta_mma"] = batch["attention_tile_meta_mma"]
        if seq_mask is not None:
            extension["mask"] = seq_mask.unsqueeze(0).unsqueeze(0)
        encoder_output, moe_loss = self.seq_encoder(
            x=seq_input,
            extension=extension,
        )
        encoder_output_dim = encoder_output.shape[-1]
        encoder_output = encoder_output.reshape(1, -1, encoder_output_dim).squeeze(0)
        return encoder_output, moe_loss

    def forward(self, batch):
        encoder_output, moe_loss = self.encode(batch)
        if (
            self.linear.weight.is_cuda
            and self.linear.weight.dtype == torch.float16
            and self.linear.bias is not None
            and self.linear.bias.is_cuda
            and self.linear.bias.dtype == torch.float16
            and encoder_output.is_cuda
            and encoder_output.dtype == torch.float16
            and encoder_output.dim() == 2
            and encoder_output.size(-1) == 512
        ):
            pred_logits = _get_output_ext().head_logits_all(
                encoder_output.contiguous(),
                self.linear.weight.contiguous(),
                self.linear.bias.contiguous(),
            )
        else:
            pred = self.linear(encoder_output)
            pred_logits = torch.clamp(pred, min=-15.0, max=15.0)
        return pred_logits, moe_loss

    def predict_batch(self, batch):
        if not (
            self.linear.weight.is_cuda
            and self.linear.weight.dtype == torch.float16
            and self.linear.bias is not None
            and self.linear.bias.is_cuda
            and self.linear.bias.dtype == torch.float16
            and "logid" in batch
            and "pred_positions" in batch
            and batch["logid"].is_cuda
            and batch["logid"].dtype == torch.long
            and batch["pred_positions"].is_cuda
            and batch["pred_positions"].dtype == torch.long
        ):
            raise RuntimeError("custom CUDA output path requires CUDA fp16 final head and CUDA int64 logid/pred_positions")

        encoder_output, _ = self.encode(batch)
        if not (
            encoder_output.is_cuda
            and encoder_output.dtype == torch.float16
            and encoder_output.dim() == 2
            and encoder_output.size(-1) == 512
        ):
            raise RuntimeError("custom CUDA output path requires encoder_output shape [N,512] in CUDA fp16")

        return _get_output_ext().head_sigmoid_gather_positions(
            encoder_output.contiguous(),
            self.linear.weight.contiguous(),
            self.linear.bias.contiguous(),
            batch["logid"].contiguous(),
            batch["pred_positions"].contiguous(),
        )


def _warmup_custom_layernorm(device, dtype=torch.float16):
    if not USE_CUSTOM_CUDA_NORM and not USE_CUSTOM_CUDA_REP_NORM:
        return

    dev = torch.device(device)
    if dev.type != "cuda" or dtype != torch.float16:
        return

    ext = _get_layernorm_ext()
    with torch.no_grad():
        if USE_CUSTOM_CUDA_NORM:
            x = torch.randn((1, 512), device=dev, dtype=dtype)
            residual = torch.randn((1, 512), device=dev, dtype=dtype)
            weight = torch.ones((512,), device=dev, dtype=dtype)
            bias = torch.zeros((512,), device=dev, dtype=dtype)
            ext.layernorm_512(x, weight, bias, 1e-5)
            ext.add_layernorm_512(residual, x, weight, bias, 1e-5)
            ext.add_layernorm_512_with_residual(residual, x, weight, bias, 1e-5)

        if USE_CUSTOM_CUDA_REP_NORM:
            rep_x = torch.randn((1, 28 * 512), device=dev, dtype=dtype)
            rep_weight = torch.ones((28 * 512,), device=dev, dtype=dtype)
            rep_bias = torch.zeros((28 * 512,), device=dev, dtype=dtype)
            ext.layernorm_14336(rep_x, rep_weight, rep_bias, 1e-5)
    torch.cuda.synchronize(dev)


def _warmup_custom_attention(device, dtype=torch.float16):
    if not USE_CUSTOM_CUDA_ATTENTION:
        return

    dev = torch.device(device)
    if dev.type != "cuda":
        return

    with torch.no_grad():
        q = torch.randn((1, 8, 8, 64), device=dev, dtype=dtype)
        k = torch.randn_like(q)
        v = torch.randn_like(q)
        qkv = torch.randn((1, 8, 8, 3 * 64), device=dev, dtype=dtype)
        offsets = torch.tensor([0, 3, 8], device=dev, dtype=torch.long)
        tile_meta_mma = make_attention_tile_meta(offsets, br=ATTENTION_MMA_BR)
        if USE_INTERLEAVED_QKV_ATTENTION:
            attention_kernel, _ = _get_interleaved_attention_kernel()
            attention_kernel(qkv, offsets, tile_meta_mma, USE_INTERLEAVED_QKV_ATTENTION_TOKEN_MAJOR_OUT)
        else:
            attention_kernel, _ = _get_attention_kernel()
            attention_kernel(q, k, v, offsets, tile_meta_mma)
    torch.cuda.synchronize(dev)


def _warmup_custom_embedding_bag(model, device, dtype=torch.float16):
    dev = torch.device(device)
    if dev.type != "cuda" or dtype != torch.float16:
        return

    rep_encoder = model.rep_encoder
    if rep_encoder.emb_dim != 512 or rep_encoder.slot_num != 28:
        return

    ext = _get_embedding_bag_ext()
    with torch.no_grad():
        values = [
            torch.tensor([1, 2], device=dev, dtype=torch.long)
            for _ in range(rep_encoder.slot_num)
        ]
        offsets = [
            torch.tensor([0, 1, 2], device=dev, dtype=torch.long)
            for _ in range(rep_encoder.slot_num)
        ]
        ext.embedding_bag_28slot_fused(
            rep_encoder.emb.weight.contiguous(),
            values,
            offsets,
        )
    torch.cuda.synchronize(dev)


def _warmup_custom_gate_topk(device, dtype=torch.float16):
    dev = torch.device(device)
    if dev.type != "cuda" or dtype != torch.float16:
        return

    ext = _get_gate_topk_ext()
    with torch.no_grad():
        logits = torch.randn((16, 8), device=dev, dtype=dtype)
        ext.top2_softmax_8(logits)
    torch.cuda.synchronize(dev)


def _warmup_custom_output(model, device, dtype=torch.float16):
    dev = torch.device(device)
    if dev.type != "cuda" or dtype != torch.float16:
        return

    ext = _get_output_ext()
    with torch.no_grad():
        n_tokens = 16
        encoder_output = torch.randn((n_tokens, 512), device=dev, dtype=dtype)
        logids = torch.arange(n_tokens, device=dev, dtype=torch.long)
        pred_positions = torch.tensor([0, 3, 7, 15], device=dev, dtype=torch.long)
        ext.head_logits_all(
            encoder_output,
            model.linear.weight.contiguous(),
            model.linear.bias.contiguous(),
        )
        ext.head_sigmoid_gather_positions(
            encoder_output,
            model.linear.weight.contiguous(),
            model.linear.bias.contiguous(),
            logids,
            pred_positions,
        )
    torch.cuda.synchronize(dev)


def _warmup_custom_routed_smoe(model, device, dtype=torch.float16):
    if USE_SIMPLE_W4A4_SMOE or USE_W4A16_SMOE:
        return

    dev = torch.device(device)
    if dev.type != "cuda" or dtype != torch.float16:
        return

    moe = model.seq_encoder.moe[0]
    if not (
        hasattr(moe, "_dense_all_w1_tn")
        and hasattr(moe, "_dense_all_b1")
        and hasattr(moe, "_dense_all_w2_tn")
        and hasattr(moe, "_dense_all_b2")
    ):
        return

    ext = _get_routed_smoe_ext()
    with torch.no_grad():
        n_tokens = 128
        x = torch.randn((n_tokens, 512), device=dev, dtype=dtype)
        residual = torch.randn_like(x)
        topk_idx = torch.empty((n_tokens, 2), device=dev, dtype=torch.long)
        topk_idx[:, 0] = 0
        topk_idx[:, 1] = 1
        topk_score = torch.full((n_tokens, 2), 0.5, device=dev, dtype=dtype)
        if USE_CUTLASS_SMOE:
            forward_name = "smoe_forward_cutlass_fc2"
            forward_with_residual_name = "smoe_forward_cutlass_fc2_with_residual"
        elif USE_M64_SMOE:
            forward_name = "smoe_forward_m64"
            forward_with_residual_name = "smoe_forward_m64_with_residual"
        else:
            forward_name = "smoe_forward"
            forward_with_residual_name = "smoe_forward_with_residual"
        if hasattr(ext, forward_with_residual_name):
            getattr(ext, forward_with_residual_name)(
                x,
                residual,
                moe._dense_all_w1_tn.contiguous(),
                moe._dense_all_b1.contiguous(),
                moe._dense_all_w2_tn.contiguous(),
                moe._dense_all_b2.contiguous(),
                topk_idx,
                topk_score,
            )
        else:
            if not hasattr(ext, forward_name):
                raise RuntimeError(f"routed_smoe_ext must export {forward_name}")
            getattr(ext, forward_name)(
                x,
                moe._dense_all_w1_tn.contiguous(),
                moe._dense_all_b1.contiguous(),
                moe._dense_all_w2_tn.contiguous(),
                moe._dense_all_b2.contiguous(),
                topk_idx,
                topk_score,
            )
    torch.cuda.synchronize(dev)


def _warmup_custom_simple_w4a4_smoe(model, device, dtype=torch.float16):
    if not USE_SIMPLE_W4A4_SMOE:
        return

    dev = torch.device(device)
    if dev.type != "cuda" or dtype != torch.float16:
        return

    moe = model.seq_encoder.moe[0]
    if not (
        hasattr(moe, "_dense_all_w1_tn")
        and hasattr(moe, "_dense_all_b1")
        and hasattr(moe, "_simple_w4a4_w2_pack")
        and hasattr(moe, "_simple_w4a4_b2")
        and hasattr(moe, "_simple_w4a4_weight_scale_value")
    ):
        return

    ext = _get_routed_smoe_ext()
    if USE_SIMPLE_W4A4_FC1_SMOE:
        if not (hasattr(moe, "_simple_w4a4_w1_pack") and hasattr(moe, "_simple_w4a4_b1")):
            return
        required_symbols = ("smoe_forward_simple_w4a4", "smoe_forward_simple_w4a4_with_residual")
    else:
        required_symbols = ("smoe_forward_simple_w4a4_fc2", "smoe_forward_simple_w4a4_fc2_with_residual")
    missing = [name for name in required_symbols if not hasattr(ext, name)]
    if missing:
        raise RuntimeError("routed_smoe_ext missing simple W4A4 exports: " + ", ".join(missing))

    with torch.no_grad():
        n_tokens = 128
        x = torch.randn((n_tokens, 512), device=dev, dtype=dtype)
        residual = torch.randn_like(x)
        topk_idx = torch.empty((n_tokens, 2), device=dev, dtype=torch.long)
        topk_idx[:, 0] = 0
        topk_idx[:, 1] = 1
        topk_score = torch.full((n_tokens, 2), 0.5, device=dev, dtype=dtype)
        if USE_SIMPLE_W4A4_FC1_SMOE:
            ext.smoe_forward_simple_w4a4_with_residual(
                x,
                residual,
                moe._simple_w4a4_w1_pack.contiguous(),
                moe._simple_w4a4_b1.contiguous(),
                moe._simple_w4a4_w2_pack.contiguous(),
                moe._simple_w4a4_b2.contiguous(),
                topk_idx,
                topk_score,
                float(SIMPLE_W4A4_FC1_ACT_SCALE),
                float(moe._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC1_OUTPUT_SCALE),
                float(SIMPLE_W4A4_ACT_SCALE),
                float(moe._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC2_OUTPUT_SCALE),
            )
        else:
            ext.smoe_forward_simple_w4a4_fc2_with_residual(
                x,
                residual,
                moe._dense_all_w1_tn.contiguous(),
                moe._dense_all_b1.contiguous(),
                moe._simple_w4a4_w2_pack.contiguous(),
                moe._simple_w4a4_b2.contiguous(),
                topk_idx,
                topk_score,
                float(SIMPLE_W4A4_ACT_SCALE),
                float(moe._simple_w4a4_weight_scale_value),
                float(SIMPLE_W4A4_FC2_OUTPUT_SCALE),
            )
    torch.cuda.synchronize(dev)
    print(
        "[INFO] Loaded SMoE simple W4A4 fc2 extension "
        f"(fc1={USE_SIMPLE_W4A4_FC1_SMOE}, "
        f"fc1_act_scale={SIMPLE_W4A4_FC1_ACT_SCALE}, "
        f"fc1_output_scale={SIMPLE_W4A4_FC1_OUTPUT_SCALE}, "
        f"fc2_act_scale={SIMPLE_W4A4_ACT_SCALE}, "
        f"fc2_output_scale={SIMPLE_W4A4_FC2_OUTPUT_SCALE})"
    )


def _warmup_custom_w4a16_smoe(device, dtype=torch.float16):
    if USE_SIMPLE_W4A4_SMOE or not (USE_W4A16_SMOE and USE_CUDA_W4A16_SMOE):
        return

    dev = torch.device(device)
    if dev.type != "cuda" or dtype != torch.float16:
        return

    ext = _get_routed_smoe_ext()
    if USE_SIMT_FC2_W4A16_SMOE:
        required_symbols = ("smoe_forward_w4a16_simt_fc2", "smoe_forward_w4a16_simt_fc2_with_residual")
    elif USE_LOP3_DEQUANT_W4A16_SMOE:
        required_symbols = ("smoe_forward_w4a16_lop3", "smoe_forward_w4a16_lop3_with_residual")
    elif USE_FRAG_DEQUANT_W4A16_SMOE:
        required_symbols = ("smoe_forward_w4a16_frag", "smoe_forward_w4a16_frag_with_residual")
    else:
        required_symbols = ("smoe_forward_w4a16", "smoe_forward_w4a16_with_residual")
    missing = [
        name
        for name in required_symbols
        if not hasattr(ext, name)
    ]
    if missing:
        message = "routed_smoe_ext missing W4A16 exports: " + ", ".join(missing)
        if REQUIRE_CUDA_W4A16_SMOE:
            raise RuntimeError(message)
        print(f"[WARNING] {message}; Python W4A16 reference fallback remains enabled")
    else:
        if USE_FRAG_DEQUANT_W4A16_SMOE:
            print("[INFO] Loaded SMoE CUDA W4A16 frag-dequant extension")
        else:
            print("[INFO] Loaded SMoE CUDA W4A16 extension")


def _check_w4a16_smoe_weights(model):
    if not (USE_W4A16_SMOE and CHECK_W4A16_SMOE):
        return

    moe = model.seq_encoder.moe[0]
    if not (
        hasattr(moe, "_w4_w1_qdq")
        and hasattr(moe, "_w4_w1_pack")
        and hasattr(moe, "_w4_w1_scale")
        and hasattr(moe, "_w4_w1_zero")
        and hasattr(moe, "_w4_w1_scale_h")
        and hasattr(moe, "_w4_w1_zero_h")
        and hasattr(moe, "_w4_w2_qdq")
        and hasattr(moe, "_w4_w2_pack")
        and hasattr(moe, "_w4_w2_scale")
        and hasattr(moe, "_w4_w2_zero")
        and hasattr(moe, "_w4_w2_scale_h")
        and hasattr(moe, "_w4_w2_zero_h")
    ):
        print("[WARNING] CHECK_W4A16_SMOE skipped because W4A16 buffers are missing")
        return

    with torch.no_grad():
        w1_ref = moe.experts[0].fc1.weight.detach().float()
        w2_ref = moe.experts[0].fc2.weight.detach().float()
        w1_diff = (moe._w4_w1_qdq[0].float() - w1_ref).abs()
        w2_diff = (moe._w4_w2_qdq[0].float() - w2_ref).abs()
        w1_unpack = _w4a16_unpack_qweight(
            moe._w4_w1_pack[0],
            moe._w4_w1_qdq.size(2),
        )
        w2_unpack = _w4a16_unpack_qweight(
            moe._w4_w2_pack[0],
            moe._w4_w2_qdq.size(2),
        )
        w1_pack_dequant = _w4a16_dequantize_qweight(
            w1_unpack,
            moe._w4_w1_scale[0],
            moe._w4_w1_zero[0],
            moe._w4_w1_qdq.dtype,
        )
        w2_pack_dequant = _w4a16_dequantize_qweight(
            w2_unpack,
            moe._w4_w2_scale[0],
            moe._w4_w2_zero[0],
            moe._w4_w2_qdq.dtype,
        )
        w1_pack_diff = (w1_pack_dequant.float() - moe._w4_w1_qdq[0].float()).abs()
        w2_pack_diff = (w2_pack_dequant.float() - moe._w4_w2_qdq[0].float()).abs()
        w1_scale_h_diff = (moe._w4_w1_scale_h.float() - moe._w4_w1_scale.float()).abs()
        w1_zero_h_diff = (moe._w4_w1_zero_h.float() - moe._w4_w1_zero.float()).abs()
        w2_scale_h_diff = (moe._w4_w2_scale_h.float() - moe._w4_w2_scale.float()).abs()
        w2_zero_h_diff = (moe._w4_w2_zero_h.float() - moe._w4_w2_zero.float()).abs()
        print(
            "[INFO] W4A16 SMoE weight check: "
            f"group_size={W4A16_GROUP_SIZE}, "
            f"w1_pack_shape={tuple(moe._w4_w1_pack.shape)}, "
            f"w2_pack_shape={tuple(moe._w4_w2_pack.shape)}, "
            f"fc1_max_abs_err={w1_diff.max().item():.6e}, "
            f"fc1_mean_abs_err={w1_diff.mean().item():.6e}, "
            f"fc2_max_abs_err={w2_diff.max().item():.6e}, "
            f"fc2_mean_abs_err={w2_diff.mean().item():.6e}, "
            f"fc1_pack_recon_max_abs_err={w1_pack_diff.max().item():.6e}, "
            f"fc2_pack_recon_max_abs_err={w2_pack_diff.max().item():.6e}, "
            f"fc1_scale_h_max_abs_err={w1_scale_h_diff.max().item():.6e}, "
            f"fc1_zero_h_max_abs_err={w1_zero_h_diff.max().item():.6e}, "
            f"fc2_scale_h_max_abs_err={w2_scale_h_diff.max().item():.6e}, "
            f"fc2_zero_h_max_abs_err={w2_zero_h_diff.max().item():.6e}"
        )


def _make_debug_w4a16_weight_pack(num_experts, out_features, in_features, group_size, device):
    if in_features % group_size != 0:
        raise RuntimeError(f"group_size={group_size} must divide in_features={in_features}")

    rows = torch.arange(
        num_experts * out_features,
        device=device,
        dtype=torch.int32,
    ).view(num_experts * out_features, 1)
    cols = torch.arange(in_features, device=device, dtype=torch.int32).view(1, in_features)
    quant = torch.bitwise_and(rows * 5 + cols, 15).to(torch.int16).contiguous()
    packed = _w4a16_pack_qweight(quant).view(
        num_experts,
        out_features,
        in_features // 4,
    ).contiguous()

    groups = in_features // group_size
    scale = torch.ones(
        (num_experts, out_features, groups),
        device=device,
        dtype=torch.float32,
    )
    row_zero = torch.arange(out_features, device=device, dtype=torch.float32).view(1, out_features, 1)
    zero = row_zero.expand(num_experts, out_features, groups).contiguous()
    return packed, scale, zero


def _half2_word_to_string(word):
    word_u32 = int(word) & 0xFFFFFFFF
    values = np.array([word_u32], dtype=np.uint32).view(np.float16).astype(np.float32)
    return f"0x{word_u32:08x}({values[0]:.1f},{values[1]:.1f})"


def _summarize_bfrag_dump(name, dump, limit):
    dump_cpu = dump.detach().cpu()
    pair_mismatch = (
        (dump_cpu[..., 0] != dump_cpu[..., 2])
        | (dump_cpu[..., 1] != dump_cpu[..., 3])
    )
    mismatch_idx = pair_mismatch.nonzero(as_tuple=False)
    total_pairs = pair_mismatch.numel()
    mismatch_count = int(mismatch_idx.size(0))
    print(
        f"[INFO] {name} B-fragment diagnostic: "
        f"dump_shape={tuple(dump_cpu.shape)}, "
        f"mismatched_pairs={mismatch_count}/{total_pairs}"
    )

    if mismatch_count == 0:
        print(f"[INFO] {name} current direct B-fragment mapping matches ldmatrix_x2")
        return

    print(f"[INFO] {name} first {min(limit, mismatch_count)} mismatches:")
    for row in mismatch_idx[:limit]:
        warp, lane, j = (int(row[0]), int(row[1]), int(row[2]))
        values = dump_cpu[warp, lane, j]
        warp_n = warp >> 1
        print(
            "  "
            f"warp={warp} warp_n={warp_n} lane={lane} j={j} "
            f"ref0={_half2_word_to_string(values[0])} "
            f"ref1={_half2_word_to_string(values[1])} "
            f"direct0={_half2_word_to_string(values[2])} "
            f"direct1={_half2_word_to_string(values[3])}"
        )


def _run_debug_w4a16_bfrag(args):
    if not torch.cuda.is_available():
        raise RuntimeError("--debug-w4a16-bfrag requires CUDA")

    dev = torch.device("cuda:0")
    ext = _get_routed_smoe_ext()
    required_symbols = ("debug_w4a16_bfrag_fc1", "debug_w4a16_bfrag_fc2")
    missing = [name for name in required_symbols if not hasattr(ext, name)]
    if missing:
        raise RuntimeError("routed_smoe_ext missing debug exports: " + ", ".join(missing))

    layer_specs = []
    if args.debug_w4a16_bfrag_layer in ("fc1", "both"):
        layer_specs.append(("fc1", 1024, 512, ext.debug_w4a16_bfrag_fc1))
    if args.debug_w4a16_bfrag_layer in ("fc2", "both"):
        layer_specs.append(("fc2", 512, 1024, ext.debug_w4a16_bfrag_fc2))

    print(
        "[INFO] running W4A16 B-fragment diagnostic "
        f"(group_size={W4A16_GROUP_SIZE}, "
        f"expert={args.debug_w4a16_bfrag_expert}, "
        f"n_tile_base={args.debug_w4a16_bfrag_n_tile}, "
        f"k_base={args.debug_w4a16_bfrag_k_base})"
    )
    print("[INFO] dump layout: [warp_id, lane, j, ref0/ref1/direct0/direct1]")

    with torch.no_grad():
        for name, out_features, in_features, debug_fn in layer_specs:
            packed, scale, zero = _make_debug_w4a16_weight_pack(
                num_experts=8,
                out_features=out_features,
                in_features=in_features,
                group_size=W4A16_GROUP_SIZE,
                device=dev,
            )
            if USE_HALF_SCALE_W4A16_SMOE:
                scale = scale.half().contiguous()
                zero = zero.half().contiguous()
            dump = debug_fn(
                packed,
                scale,
                zero,
                W4A16_GROUP_SIZE,
                args.debug_w4a16_bfrag_expert,
                args.debug_w4a16_bfrag_n_tile,
                args.debug_w4a16_bfrag_k_base,
            )
            torch.cuda.synchronize(dev)
            _summarize_bfrag_dump(name, dump, args.debug_w4a16_bfrag_limit)
    return None


def _summarize_forward_diff(name, actual, expected):
    diff = (actual.detach().float() - expected.detach().float()).abs()
    rmse = torch.sqrt(torch.mean(diff * diff))
    print(
        f"[INFO] {name}: "
        f"max_abs_err={diff.max().item():.6e}, "
        f"mean_abs_err={diff.mean().item():.6e}, "
        f"rmse={rmse.item():.6e}"
    )


def _run_debug_w4a16_forward(args):
    if not torch.cuda.is_available():
        raise RuntimeError("--debug-w4a16-forward requires CUDA")

    if args.debug_w4a16_forward_tokens <= 0:
        raise RuntimeError("--debug-w4a16-forward-tokens must be positive")

    dev = torch.device("cuda:0")
    torch.manual_seed(args.debug_w4a16_forward_seed)
    torch.cuda.manual_seed_all(args.debug_w4a16_forward_seed)

    smoe = SMoE(512, 1024, 8, k=2).to(dev).half().eval()
    smoe.prepare_w4a16_weights()
    ext = _get_routed_smoe_ext()

    n_tokens = args.debug_w4a16_forward_tokens
    with torch.no_grad():
        torch.manual_seed(args.debug_w4a16_forward_seed + 1)
        torch.cuda.manual_seed_all(args.debug_w4a16_forward_seed + 1)
        x = torch.randn((1, n_tokens, 512), device=dev, dtype=torch.float16) * 0.125
        residual = torch.randn((1, n_tokens, 512), device=dev, dtype=torch.float16) * 0.0625

        token = torch.arange(n_tokens, device=dev, dtype=torch.int64)
        top0 = token % 8
        top1 = (token * 3 + 1) % 8
        topk_idx = torch.stack((top0, top1), dim=1).view(1, n_tokens, 2).to(torch.int32)
        score0 = torch.full((n_tokens,), 0.625, device=dev, dtype=torch.float16)
        score1 = torch.full((n_tokens,), 0.375, device=dev, dtype=torch.float16)
        topk_score = torch.stack((score0, score1), dim=1).view(1, n_tokens, 2).contiguous()

        ref = smoe._forward_w4a16_reference(x, topk_idx, topk_score)
        ref_residual = smoe._forward_w4a16_reference_with_residual(
            x,
            residual,
            topk_idx,
            topk_score,
        )
        torch.cuda.synchronize(dev)

        x_flat = x.reshape(n_tokens, 512).contiguous()
        residual_flat = residual.reshape(n_tokens, 512).contiguous()
        idx_flat = topk_idx.reshape(n_tokens, 2).contiguous()
        score_flat = topk_score.reshape(n_tokens, 2).contiguous()

        def make_common_args(fn_name):
            w1_scale, w1_zero, w2_scale, w2_zero = smoe._w4a16_cuda_scale_buffers(
                smoe._use_w4a16_cuda_half_scale(fn_name)
            )
            return (
                smoe._w4_w1_pack.contiguous(),
                w1_scale.contiguous(),
                w1_zero.contiguous(),
                smoe._w4_b1.contiguous(),
                smoe._w4_w2_pack.contiguous(),
                w2_scale.contiguous(),
                w2_zero.contiguous(),
                smoe._w4_b2.contiguous(),
                idx_flat,
                score_flat,
                W4A16_GROUP_SIZE,
            )

        variants = (
            ("shared", "smoe_forward_w4a16", "smoe_forward_w4a16_with_residual"),
            ("frag", "smoe_forward_w4a16_frag", "smoe_forward_w4a16_frag_with_residual"),
        )

        print(
            "[INFO] running W4A16 forward diagnostic "
            f"(tokens={n_tokens}, group_size={W4A16_GROUP_SIZE}, "
            f"seed={args.debug_w4a16_forward_seed})"
        )
        print("[INFO] reference: Python W4A16 qdq route/reduce path")
        for label, fn_name, fn_residual_name in variants:
            if not hasattr(ext, fn_name):
                print(f"[WARNING] skipping {label}: missing {fn_name}")
                continue

            common_args = make_common_args(fn_name)
            out = getattr(ext, fn_name)(x_flat, *common_args).reshape(1, n_tokens, 512)
            torch.cuda.synchronize(dev)
            _summarize_forward_diff(f"{label} forward vs reference", out, ref)

            if not hasattr(ext, fn_residual_name):
                print(f"[WARNING] skipping {label} residual: missing {fn_residual_name}")
                continue
            common_residual_args = make_common_args(fn_residual_name)
            out_residual = getattr(ext, fn_residual_name)(
                x_flat,
                residual_flat,
                *common_residual_args,
            ).reshape(1, n_tokens, 512)
            torch.cuda.synchronize(dev)
            _summarize_forward_diff(f"{label} residual vs reference", out_residual, ref_residual)

    return None


def _check_custom_layernorm(model, device):
    if not CHECK_CUSTOM_CUDA_NORM or not USE_CUSTOM_CUDA_NORM:
        return

    dev = torch.device(device)
    if dev.type != "cuda":
        print("[WARNING] CHECK_CUSTOM_CUDA_NORM skipped because device is not CUDA")
        return

    norm = model.seq_encoder.norm1[0]
    if not isinstance(norm, CustomLayerNorm512):
        print(f"[WARNING] CHECK_CUSTOM_CUDA_NORM skipped because norm1[0] is {type(norm)}")
        return

    with torch.no_grad():
        dtype = norm.weight.dtype
        x = torch.randn((1, 1024, 512), device=dev, dtype=dtype)
        custom = norm(x)
        reference = F.layer_norm(x, (512,), norm.weight, norm.bias, norm.eps)
        diff = (custom.float() - reference.float()).abs()
        print(
            "[INFO] custom LayerNorm check: "
            f"max_abs_err={diff.max().item():.6e}, "
            f"mean_abs_err={diff.mean().item():.6e}"
        )

        residual = torch.randn_like(x)
        custom_add = norm.add_layernorm(residual, x)
        reference_add = F.layer_norm(residual + x, (512,), norm.weight, norm.bias, norm.eps)
        add_diff = (custom_add.float() - reference_add.float()).abs()
        print(
            "[INFO] custom AddLayerNorm check: "
            f"max_abs_err={add_diff.max().item():.6e}, "
            f"mean_abs_err={add_diff.mean().item():.6e}"
        )

        custom_residual, custom_norm = norm.add_layernorm_with_residual(residual, x)
        reference_residual = residual + x
        residual_diff = (custom_residual.float() - reference_residual.float()).abs()
        norm_diff = (custom_norm.float() - reference_add.float()).abs()
        print(
            "[INFO] custom AddLayerNormWithResidual check: "
            f"residual_max_abs_err={residual_diff.max().item():.6e}, "
            f"norm_max_abs_err={norm_diff.max().item():.6e}"
        )


def _resolve_ckpt_path(ckpt_path=None):
    candidates = []

    if ckpt_path is not None:
        candidates.append(Path(ckpt_path))

    env_ckpt = os.environ.get("CKPT_PATH")
    if env_ckpt:
        candidates.append(Path(env_ckpt))

    candidates.extend([
        SCRIPT_DIR / "ckpt.pt",
        SCRIPT_DIR / "code" / "ckpt.pt",
        Path.cwd() / "ckpt.pt",
        Path.cwd() / "code" / "ckpt.pt",
        Path.home() / "code" / "ckpt.pt",
    ])

    seen = set()
    unique_candidates = []
    for path in candidates:
        path = path.expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        else:
            path = path.resolve()

        if path in seen:
            continue
        seen.add(path)
        unique_candidates.append(path)

        if path.exists():
            return path, unique_candidates

    return unique_candidates[0], unique_candidates


# ============================================================
# 模型加载入口
# ============================================================

def load_model(ckpt_path=None, device='cuda:0'):
    """加载模型并返回，供 evaluation.py 调用。

    Args:
        ckpt_path: checkpoint 文件路径，默认使用 infer.py 同目录下的 ckpt.pt
        device: 推理设备（默认 'cuda:0'）

    Returns:
        (model, device) 元组
    """
    global CUDA_GRAPH_MAIN_BATCH_FASTPATH
    CUDA_GRAPH_MAIN_BATCH_FASTPATH = False

    emb_dim = 512
    slot_num = 28
    vocab_size = 5000000
    d_model = 512
    n_heads = 8
    num_layers = 8
    dim_ff = 1024

    rep_encoder = RepEncoder(
        vocab_size=vocab_size,
        emb_dim=emb_dim,
        padding_idx=0,
        slot_num=slot_num,
        d_model=d_model,
    )
    seq_encoder = TransformerEncoder(
        d_model=d_model,
        n_heads=n_heads,
        num_layers=num_layers,
        dim_ff=dim_ff,
        act="relu",
    )
    model = CTRModel(rep_encoder, seq_encoder, d_model=d_model)

    dev = torch.device(device if torch.cuda.is_available() else "cpu")
    if dev.type != "cuda":
        raise RuntimeError("optimized inference requires a CUDA device")

    # 加载 checkpoint
    # 若需要加载自定义修改的权重，请修改 479-488行逻辑，强制使用你文件夹中的权重
    # 测评系统默认使用原始官方权重
    ckpt_path, ckpt_candidates = _resolve_ckpt_path(ckpt_path)
    if ckpt_path.exists():
        ckpt = torch.load(ckpt_path, map_location='cpu', weights_only=False)
        model.load_state_dict(ckpt['model_state_dict'])
        print(f"[INFO] Loaded checkpoint from {ckpt_path} (epoch={ckpt.get('epoch', '?')})")
    else:
        print(f"[WARNING] Checkpoint {ckpt_path} not found, using random weights")
        print("[WARNING] Checked checkpoint candidates:")
        for candidate in ckpt_candidates:
            print(f"  - {candidate}")

    model.to(dev)
    model.half()
    print("[INFO] Converted model to float16")
    model.seq_encoder.prepare_dense_all_smoe()
    print("[INFO] Prepared SMoE stacked expert weights")
    if USE_SIMPLE_W4A4_SMOE:
        model.seq_encoder.prepare_simple_w4a4_smoe()
        print(
            "[INFO] Prepared SMoE simple W4A4 fc2 packed weights "
            f"(fc1={USE_SIMPLE_W4A4_FC1_SMOE}, "
            f"fc1_act_scale={SIMPLE_W4A4_FC1_ACT_SCALE}, "
            f"fc1_output_scale={SIMPLE_W4A4_FC1_OUTPUT_SCALE}, "
            f"fc2_act_scale={SIMPLE_W4A4_ACT_SCALE}, "
            f"fc2_output_scale={SIMPLE_W4A4_FC2_OUTPUT_SCALE})"
        )
    elif USE_W4A16_SMOE:
        model.seq_encoder.prepare_w4a16_smoe()
        print(
            "[INFO] Prepared SMoE W4A16 qdq and packed expert weights "
            f"(group_size={W4A16_GROUP_SIZE})"
        )
    model.eval()
    model_dtype = next(model.parameters()).dtype
    _warmup_custom_embedding_bag(model, dev, dtype=model_dtype)
    _warmup_custom_gate_topk(dev, dtype=model_dtype)
    _warmup_custom_output(model, dev, dtype=model_dtype)
    _warmup_custom_layernorm(dev, dtype=model_dtype)
    _warmup_custom_attention(dev, dtype=model_dtype)
    _warmup_custom_routed_smoe(model, dev, dtype=model_dtype)
    _warmup_custom_simple_w4a4_smoe(model, dev, dtype=model_dtype)
    _warmup_custom_w4a16_smoe(dev, dtype=model_dtype)
    _check_w4a16_smoe_weights(model)
    _check_custom_layernorm(model, dev)
    print(f"[INFO] Model ready. Device: {dev}")
    if USE_CUSTOM_CUDA_NORM:
        print("[INFO] Using custom CUDA LayerNorm(512) for TransformerEncoder norm1/norm2")
    else:
        print("[INFO] Using PyTorch LayerNorm for TransformerEncoder norm1/norm2")
    if USE_CUSTOM_CUDA_REP_NORM:
        rep_norm_kernel = "vec8" if USE_REP_LAYERNORM_14336_VEC8 else "scalar"
        print(f"[INFO] Using custom CUDA LayerNorm(14336) for RepEncoder input_norm ({rep_norm_kernel})")
    else:
        print("[INFO] Using PyTorch LayerNorm for RepEncoder input_norm")
    if model_dtype != torch.float16:
        raise RuntimeError(f"optimized inference requires model dtype float16, got {model_dtype}")
    print("[INFO] Using custom CUDA fused 28-slot embedding bag")
    print("[INFO] Using custom CUDA gate top2 softmax")
    print("[INFO] Using custom CUDA full final head logits in CTRModel.forward")
    print("[INFO] Keeping custom CUDA final head + sigmoid gather for predict_batch")
    if USE_CUSTOM_CUDA_ATTENTION:
        if dev.type == "cuda":
            if USE_INTERLEAVED_QKV_ATTENTION:
                _, attention_kernel_name = _get_interleaved_attention_kernel()
            else:
                _, attention_kernel_name = _get_attention_kernel()
            print(f"[INFO] Using custom CUDA varlen causal attention ({attention_kernel_name})")
        else:
            print("[INFO] Using custom CUDA varlen causal attention")
    if USE_SIMPLE_W4A4_SMOE:
        print(
            "[INFO] Using SMoE simple CUDA W4A4 fc2 experiment "
            f"(fc1={USE_SIMPLE_W4A4_FC1_SMOE}, "
            f"fc1_act_scale={SIMPLE_W4A4_FC1_ACT_SCALE}, "
            f"fc1_output_scale={SIMPLE_W4A4_FC1_OUTPUT_SCALE}, "
            f"fc2_act_scale={SIMPLE_W4A4_ACT_SCALE}, "
            f"fc2_output_scale={SIMPLE_W4A4_FC2_OUTPUT_SCALE})"
        )
        print("[INFO] Using custom CUDA routed sparse SMoE residual-add fusion")
    elif USE_W4A16_SMOE:
        if USE_CUDA_W4A16_SMOE:
            fallback_msg = "disabled" if REQUIRE_CUDA_W4A16_SMOE else "enabled"
            if USE_SIMT_FC2_W4A16_SMOE:
                kernel_msg = "SIMT-fc2 kernel"
            elif USE_LOP3_DEQUANT_W4A16_SMOE:
                kernel_msg = "LOP3-dequant kernel"
            elif USE_FRAG_DEQUANT_W4A16_SMOE:
                kernel_msg = "frag-dequant kernel"
            else:
                kernel_msg = "first kernel"
            print(
                f"[INFO] Using SMoE CUDA W4A16 {kernel_msg} "
                f"(group_size={W4A16_GROUP_SIZE}, "
                f"half_scale={USE_HALF_SCALE_W4A16_SMOE}, "
                f"fallback={fallback_msg})"
            )
        else:
            print(
                "[INFO] Using SMoE Python W4A16 reference "
                f"(group_size={W4A16_GROUP_SIZE})"
            )
    else:
        if USE_CUTLASS_SMOE:
            print("[INFO] Using custom CUDA routed sparse SMoE CUTLASS fc2-only experiment")
        elif USE_M64_SMOE:
            print("[INFO] Using custom CUDA routed sparse SMoE M64 grouped GEMM experiment")
        else:
            print("[INFO] Using custom CUDA routed sparse SMoE")
        print("[INFO] Using custom CUDA routed sparse SMoE residual-add fusion")

    if USE_CUDA_GRAPH_INFER and dev.type == "cuda":
        graph_batches = _load_cached_batches_for_graph()
        if graph_batches:
            try:
                graph_runner = CudaGraphBatchRunner(
                    model,
                    dev,
                    graph_batches,
                    token_bucket=CUDA_GRAPH_TOKEN_BUCKET,
                )
                model = CudaGraphModelWrapper(model, graph_runner)
                model.eval()
                CUDA_GRAPH_MAIN_BATCH_FASTPATH = True
            except RuntimeError as exc:
                print(f"[WARNING] CUDA Graph setup failed in load_model, falling back to normal model forward: {exc}")

    return model, dev


# ============================================================
# 打分工具（与 evaluation.py 保持一致）
# ============================================================

def _read_predict(file_path):
    predictions = []
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                predictions.append(float(line))
    import numpy as np
    return np.array(predictions)


def _read_label(file_path):
    labels = []
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                parts = line.split(',')
                if len(parts) >= 4:
                    labels.append(float(parts[3]))
                else:
                    labels.append(float(line))
    import numpy as np
    return np.array(labels)


def _cal_score(predict_file, label_file, default_latency=0.0):
    import numpy as np
    from sklearn.metrics import roc_auc_score

    predictions = _read_predict(predict_file)
    labels = _read_label(label_file)

    unique_labels = np.unique(labels)
    if len(unique_labels) < 2:
        print('[WARNING] only one class present in labels, AUC is not defined, returning 0.5')
        auc = 0.5
    else:
        auc = roc_auc_score(labels, predictions)

    mean_pred = np.mean(predictions)
    mean_label = np.mean(labels)
    if mean_label == 0:
        pcoc = 1.0 if mean_pred == 0 else float('inf')
    else:
        pcoc = float(mean_pred / mean_label)

    latency = default_latency
    base_latency = 300
    score_latency = max(0.0, (base_latency - latency) / base_latency) if latency < base_latency else 0.0

    if pcoc < 0.85 or pcoc > 1.15:
        score_model = 0.0
    else:
        score_model = ((auc - 0.65) * 1000 + (0.15 - abs(pcoc - 1)) / 0.15 * 10) / 360

    score_all = score_latency * 70 + score_model * 30

    return {
        'auc': auc,
        'pcoc': pcoc,
        'latency': latency,
        'score_latency': score_latency,
        'score_model': score_model,
        'score_all': score_all,
    }


def _round_up(value, multiple):
    return ((int(value) + multiple - 1) // multiple) * multiple


def _batch_token_count(batch):
    if isinstance(batch, dict) and "_graph_n_original_rows" in batch:
        return int(batch["_graph_n_original_rows"])
    return int(batch["logid"].numel())


def _batch_user_count(batch):
    return int(batch["user_offsets"].numel() - 1)


def _ensure_cpu_attention_meta(batch):
    if "attention_tile_meta_mma" not in batch:
        batch["attention_tile_meta_mma"] = make_attention_tile_meta(
            batch["user_offsets"],
            br=ATTENTION_MMA_BR,
        )
    return batch["attention_tile_meta_mma"]


def _build_cuda_graph_specs(all_batches, token_bucket):
    specs = {}
    for batch in all_batches:
        ensure_pred_positions(batch)
        meta = _ensure_cpu_attention_meta(batch)
        tokens = _batch_token_count(batch)
        users = _batch_user_count(batch)
        token_cap = _round_up(tokens, token_bucket)
        key = (users, token_cap)
        spec = specs.get(key)
        if spec is None:
            spec = {
                "key": key,
                "users": users,
                "token_cap": token_cap,
                "count": 0,
                "slot_value_caps": [0] * 29,
                "meta_cap": 0,
            }
            specs[key] = spec
        spec["count"] += 1
        spec["meta_cap"] = max(spec["meta_cap"], int(meta.size(0)))
        for slot in range(1, 29):
            spec["slot_value_caps"][slot] = max(
                spec["slot_value_caps"][slot],
                int(batch[slot][0].numel()),
            )

    return [specs[key] for key in sorted(specs)]


class CudaGraphBatchRunner:
    def __init__(self, model, device, all_batches, token_bucket=512):
        self.model = model
        self.device = torch.device(device)
        self.token_bucket = int(token_bucket)
        self.runners = {}

        specs = _build_cuda_graph_specs(all_batches, self.token_bucket)
        if not specs:
            raise RuntimeError("no batches available for CUDA graph capture")

        print(
            "[INFO] CUDA Graph inference enabled: "
            f"token_bucket={self.token_bucket}, buckets={len(specs)}"
        )
        for spec in specs:
            self.runners[spec["key"]] = self._capture_runner(spec, all_batches)

    def _select_sample_batch(self, spec, all_batches):
        users, token_cap = spec["key"]
        for batch in all_batches:
            tokens = _batch_token_count(batch)
            if (
                _batch_user_count(batch) == users
                and _round_up(tokens, self.token_bucket) == token_cap
            ):
                return batch
        raise RuntimeError(f"missing sample batch for CUDA graph bucket {spec['key']}")

    def _make_static_batch(self, spec):
        token_cap = spec["token_cap"]
        users = spec["users"]
        static_batch = {
            "user_offsets": torch.empty((users + 1,), device=self.device, dtype=torch.long),
            "attention_tile_meta_mma": torch.empty(
                (max(1, spec["meta_cap"]), 4),
                device=self.device,
                dtype=torch.int32,
            ),
            "_graph_active_rows": torch.empty((1,), device=self.device, dtype=torch.long),
            "_graph_n_rows": token_cap,
        }

        for slot in range(1, 29):
            values_cap = max(1, int(spec["slot_value_caps"][slot]))
            static_batch[slot] = (
                torch.empty((values_cap,), device=self.device, dtype=torch.long),
                torch.empty((token_cap + 1,), device=self.device, dtype=torch.long),
            )

        static_batch["_slot_value_ptrs"] = torch.tensor(
            [static_batch[slot][0].data_ptr() for slot in range(1, 29)],
            device=self.device,
            dtype=torch.long,
        )
        static_batch["_slot_offset_ptrs"] = torch.tensor(
            [static_batch[slot][1].data_ptr() for slot in range(1, 29)],
            device=self.device,
            dtype=torch.long,
        )
        return static_batch

    def _copy_batch_to_static(self, runner, batch):
        static_batch = runner["batch"]
        tokens = _batch_token_count(batch)
        meta = _ensure_cpu_attention_meta(batch)

        static_batch["_graph_active_rows"].fill_(tokens)
        static_batch["user_offsets"].copy_(batch["user_offsets"], non_blocking=True)

        static_meta = static_batch["attention_tile_meta_mma"]
        static_meta.zero_()
        if meta.numel() > 0:
            static_meta[: meta.size(0)].copy_(meta, non_blocking=True)

        for slot in range(1, 29):
            src_values, src_offsets = batch[slot]
            dst_values, dst_offsets = static_batch[slot]
            if src_values.numel() > 0:
                dst_values[: src_values.numel()].copy_(src_values, non_blocking=True)
            dst_offsets[: src_offsets.numel()].copy_(src_offsets, non_blocking=True)

    def _capture_runner(self, spec, all_batches):
        static_batch = self._make_static_batch(spec)
        runner = {"spec": spec, "batch": static_batch}
        sample_batch = self._select_sample_batch(spec, all_batches)
        self._copy_batch_to_static(runner, sample_batch)
        torch.cuda.synchronize(self.device)

        with torch.no_grad():
            for _ in range(CUDA_GRAPH_WARMUP_ITERS):
                logits, _ = self.model(static_batch)
            torch.cuda.synchronize(self.device)

            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                static_logits, _ = self.model(static_batch)

            graph.replay()
            torch.cuda.synchronize(self.device)

        runner["graph"] = graph
        runner["logits"] = static_logits
        print(
            "[INFO] captured CUDA graph bucket "
            f"users={spec['users']}, token_cap={spec['token_cap']}, "
            f"count={spec['count']}, meta_cap={spec['meta_cap']}"
        )
        return runner

    def replay(self, batch):
        tokens = _batch_token_count(batch)
        users = _batch_user_count(batch)
        token_cap = _round_up(tokens, self.token_bucket)
        runner = self.runners[(users, token_cap)]
        self._copy_batch_to_static(runner, batch)
        runner["graph"].replay()
        return runner["logits"], tokens


class CudaGraphModelWrapper(nn.Module):
    def __init__(self, model, graph_runner):
        super().__init__()
        self.model = model
        self.graph_runner = graph_runner

    def forward(self, batch):
        logits, tokens = self.graph_runner.replay(batch)
        logits = logits[:tokens]
        pred_positions = batch.get("_graph_pred_positions") if isinstance(batch, dict) else None
        if pred_positions is not None:
            logits = logits.index_select(0, pred_positions)
        return logits, None

    def __getattr__(self, name):
        try:
            return super().__getattr__(name)
        except AttributeError:
            return getattr(self.model, name)


def _resolve_dataset_dir_for_judge():
    candidates = [
        SCRIPT_DIR / "dataset",
        SCRIPT_DIR / "code" / "dataset",
        Path.cwd() / "dataset",
        Path.cwd() / "code" / "dataset",
    ]
    for candidate in candidates:
        if (candidate / "cached_batches").exists() or (candidate / "test.csv").exists():
            return candidate
    return candidates[0]


def _load_cached_batches_for_graph():
    ref_dir = _resolve_dataset_dir_for_judge()
    batches_cache_dir = ref_dir / "cached_batches"
    shard_files = sorted(
        batches_cache_dir.glob("shard_*.pt"),
        key=lambda p: int(p.stem.split("_")[1]),
    )
    if not shard_files:
        print(f"[INFO] CUDA Graph preload skipped: no cached batch shards under {batches_cache_dir}")
        return None

    print(f"[INFO] preloading cached batch shards for CUDA Graph from {batches_cache_dir}")
    all_batches = []
    for sf in shard_files:
        shard_batches = torch.load(sf, weights_only=False)
        all_batches.extend(shard_batches)
        print(f"[INFO] preloaded {len(shard_batches)} batches from {sf.name}")
    print(f"[INFO] preloaded {len(all_batches)} cached batches for CUDA Graph capture")
    return all_batches


# ============================================================
# main：直接运行 infer.py 进行测试
# ============================================================

def main():
    import io
    import time
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--ckpt', type=str, default=None, help='checkpoint 文件路径，默认使用同目录下的 ckpt.pt')
    args = parser.parse_args()

    cur_path = Path(__file__).parent.absolute()
    ref_dir = cur_path / 'dataset'
    history_dir = ref_dir / 'history'
    input_file = ref_dir / 'test.csv'
    output_file = Path('predict.txt')
    label_file = ref_dir / 'label_data.txt'

    # ----- 数据加载，优先从缓存读取 -----
    MAX_SHARD_BYTES = 2 * 1024 * 1024 * 1024  # 2GB per shard
    batches_cache_dir = ref_dir / 'cached_batches'

    if batches_cache_dir.exists() and any(batches_cache_dir.glob('shard_*.pt')):
        print(f'[INFO] loading cached batch shards from {batches_cache_dir}')
        all_batches = []
        shard_files = sorted(batches_cache_dir.glob('shard_*.pt'),
                             key=lambda p: int(p.stem.split('_')[1]))
        for sf in shard_files:
            shard_batches = torch.load(sf, weights_only=False)
            all_batches.extend(shard_batches)
            print(f'[INFO] loaded {len(shard_batches)} batches from {sf.name}')
        print(f'[INFO] loaded {len(all_batches)} cached batches total from {len(shard_files)} shards')
    else:
        print('[INFO] start loading data from CSV')
        history_files = sorted(history_dir.glob('*.csv')) if history_dir.exists() else []
        all_files = history_files + [input_file]

        item_dict, user_seq = load_sample_files(sample_files_list=all_files)
        test_pred_logids = load_logids_from_file(input_file)
        print(f'[INFO] Test pred logids count: {len(test_pred_logids)}')

        max_feasign_per_slot = {1: 2}
        test_dataset = CTRUserDataset(
            item_dict, user_seq,
            max_feasign_per_slot=max_feasign_per_slot,
            pred_logids=test_pred_logids,
        )
        print(f'[INFO] num_users={test_dataset.num_users}, '
              f'total_samples={test_dataset.total_samples}, '
              f'pred_samples={len(test_pred_logids)}, '
              f'max_sign_id={test_dataset.max_sign_id}')

        test_loader = DataLoader(
            test_dataset,
            batch_size=50,
            shuffle=False,
            num_workers=0,
            collate_fn=make_collate_fn(test_dataset.max_slot_id),
        )

        # 收集 batches 并按分片缓存
        print('[INFO] collecting batches and saving sharded cache...')
        all_batches = [batch for batch in test_loader]

        batches_cache_dir.mkdir(parents=True, exist_ok=True)
        shard_idx = 0
        current_shard = []
        current_size = 0
        for batch in all_batches:
            buf = io.BytesIO()
            torch.save(batch, buf)
            batch_size_bytes = buf.tell()
            if current_shard and current_size + batch_size_bytes > MAX_SHARD_BYTES:
                shard_path = batches_cache_dir / f'shard_{shard_idx:04d}.pt'
                torch.save(current_shard, shard_path)
                print(f'[INFO] saved shard {shard_path.name}: {len(current_shard)} batches, '
                      f'~{current_size / 1024**3:.2f}GB')
                shard_idx += 1
                current_shard = []
                current_size = 0
            current_shard.append(batch)
            current_size += batch_size_bytes
        if current_shard:
            shard_path = batches_cache_dir / f'shard_{shard_idx:04d}.pt'
            torch.save(current_shard, shard_path)
            print(f'[INFO] saved shard {shard_path.name}: {len(current_shard)} batches, '
                  f'~{current_size / 1024**3:.2f}GB')
            shard_idx += 1
        print(f'[INFO] saved {len(all_batches)} batches to {shard_idx} shards in {batches_cache_dir}')

    print('[INFO] data loading done')

    # ----- 加载模型 -----
    model, dev = load_model(ckpt_path=args.ckpt)

    # ----- 推理 -----
    print('*' * 20 + ' start inference ' + '*' * 20)
    all_logids = []
    all_probs = []
    time_sum = 0.0
    t_start = time.time()

    with torch.no_grad():
        for batch in tqdm(all_batches, desc="Inference"):
            batch = move_batch_to_device(batch, dev)
            pred_mask = batch["pred_mask"].bool()

            logits, moe_loss = model(batch)
            logits = logits.squeeze(-1)
            probs = torch.sigmoid(logits)

            masked_logids = batch["logid"][pred_mask].cpu().tolist()
            masked_probs = probs[pred_mask].cpu().tolist()
            all_logids.extend(masked_logids)
            all_probs.extend(masked_probs)

    time_sum += time.time() - t_start
    print(f'[INFO] inference time: {round(time_sum, 4)}s')
    print('*' * 20 + ' end inference ' + '*' * 20)

    # ----- 按 test.csv 顺序写预测文件 -----
    logid_to_prob = dict(zip(all_logids, all_probs))
    test_logids_in_order = []
    with open(input_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                test_logids_in_order.append(int(line.split(',')[0]))
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, 'w') as f:
        for logid in test_logids_in_order:
            f.write(f"{logid_to_prob[logid]}\n")
    print(f'[INFO] predictions written to {output_file}, total: {len(test_logids_in_order)}')

    # ----- 打分 -----
    if label_file.exists():
        result = _cal_score(output_file, label_file, default_latency=time_sum)
        print(f'[INFO] AUC:            {result["auc"]:.6f}')
        print(f'[INFO] PCOC:           {result["pcoc"]:.6f}')
        print(f'[INFO] Latency:        {result["latency"]:.4f}s')
        print(f'[INFO] score_latency:  {result["score_latency"]:.6f}')
        print(f'[INFO] score_model:    {result["score_model"]:.6f}')
        print(f'[INFO] score_all:      {result["score_all"]:.6f}')
        return result
    else:
        print(f'[WARNING] label file {label_file} not found, skipping scoring')
        return None


if __name__ == '__main__':
    main()
